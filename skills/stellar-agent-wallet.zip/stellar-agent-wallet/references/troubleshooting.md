# Troubleshooting (wire and error codes)

Reference for the stable wire and error codes the Stellar Agent Wallet returns,
and the action an agent should take for each. The wallet places fixed controls
between every tool call and any network or signing action: a policy engine, an
out-of-band operator-approval step, single-use nonces, and a tamper-evident
audit log. Error codes are typed and stable; recover by code, not by message
text.

## The result envelope

Tool and command results use a uniform envelope:

```json
{ "ok": true,  "data": { /* result */ }, "request_id": "..." }
{ "ok": false, "error": { "code": "policy.deny.per_tx_cap_exceeded", "...": "..." }, "request_id": "..." }
```

- `ok` is `true` on success, `false` on any failure.
- `data` is present only when `ok` is `true`; `error` only when `ok` is `false`.
- `error.code` is the stable wire code. Branch on it.
- `request_id` correlates the call with the audit log. Quote it when asking the
  operator to investigate.

At the MCP boundary, account, strkey, and contract-id fields inside an error are
redacted to first-five-last-five characters, and transaction hashes to
first-eight-last-eight. The wallet never logs argument values, only argument key
names.

## Argument-format reminders (prevent most input errors)

- `chain_id` is the CAIP-2 id, `stellar:testnet` (default) or `stellar:mainnet`.
  Most MCP tools require it and it must match the active profile. (Exceptions:
  `stellar_x402_parse_receipt`, `stellar_toolset_list`, `stellar_toolset_invoke`
  take no `chain_id`; `stellar_sep43_get_address` and `stellar_sep43_get_network`
  treat it as optional, defaulting to the profile chain, still validated when
  supplied.)
- Amounts are decimal strings with an explicit unit, e.g. `"10 XLM"`,
  `"10.5 USDC"`. Never a JSON number; raw stroop strings are rejected.
- Asset is `"native"` / `"XLM"` for the native asset, or `"CODE:GISSUER"` for an
  issued asset.

## Policy-engine codes

The policy engine evaluates every call before any RPC or signing, returning
Allow, Deny, or RequireApproval. The Noop engine allows everything on testnet,
allows read-only on mainnet, and refuses destructive tools on mainnet. The V1
engine is first-match, default-deny over signed, typed criteria.

| Code | Meaning | Agent action |
|---|---|---|
| `policy.deny.<reason>` | A V1 criterion denied the call (`<reason>` is the typed reason: `per_tx_cap_exceeded`, `per_period_cap_exceeded`, `rate_limit_exceeded`, `counterparty_denied`, `minimum_reserve_breached`, `no_matching_rule`). The payload carries the redacted reason. | Do not retry as-is; the policy forbids this operation. Report the reason to the operator. Only the operator can change policy. |
| `policy.deny.unsizable_value_effect` | A value rule matched a tool whose value cannot be sized, including the raw signing tools. | Size the call through a supported verb, or ask the operator to set `allow_opaque_signing = true` on the matched rule if raw signing is intended. |
| `trustline.clawback_opt_in_required` | Trusting a clawback-enabled issuer requires a recorded operator opt-in. | Ask the operator to run the printed `stellar-agent approve --id <nonce> --profile <name>` opt-in, then re-invoke. |
| `policy.approval_required` | A two-phase signing verb reached its commit step without a valid operator approval, or the attestation was absent, invalid, or expired. This single code intentionally covers every approval-path failure mode (missing, expired, wrong-kind, hash mismatch, HMAC mismatch) so callers cannot probe which. | Ask the operator to run `stellar-agent approve --id <nonce> --profile <name>`, then re-submit the commit with the returned `approval_nonce` and `approval_attestation`. The nonce came from the simulate step. |
| `policy.approval_required_unsupported` | The policy returned RequireApproval for a single-shot sign tool (no simulate/commit split: SEP-43 sign verbs, `stellar_sep43_sign_and_submit_transaction`, SEP-53 `sign_message`, x402 `create_payment` / `authenticated_payment`). The wallet refuses fail-closed rather than sign without approval. | Cannot proceed via the agent. Ask the operator to either adjust policy so this operation does not require approval, or perform it through a two-phase tool (`stellar_pay`, `stellar_create_account`, `stellar_trustline`, `stellar_claim`, `stellar_rule_create` and their `*_commit`). |
| `policy.engine_required` | The active engine cannot decide the call. Fires for the Noop engine on a destructive tool on `stellar:mainnet`, and for V1 engine errors such as a missing or unverifiable policy document. | Do not retry on mainnet (writes are structurally refused in this alpha; use `stellar:testnet`). Otherwise the profile needs a valid V1 policy installed by the operator. |
| `policy.unexpected_decision` | Forward-compatibility catch-all for an engine decision the gate does not recognize. Fail-closed. | Treat as a hard refusal. Report to the operator; do not retry. |

Separately, every write or signing command refuses `stellar:mainnet` before any
RPC call or signing with `network.mainnet_write_forbidden`. Read-only commands
accept mainnet. Action: run write and signing operations on `stellar:testnet` in
this alpha.

## Network-binding codes (submit layer)

Before it sends, the submit layer asks the RPC endpoint which network it serves
and binds the submission to that answer, not to the declared network or
`chain_id`. It then verifies every signature on the envelope against the network
the endpoint reported. On the two-phase commit tools this runs before the
single-use nonce is burned, so a refusal here leaves the nonce usable.

| Code | Meaning | Agent action |
|---|---|---|
| `network.endpoint_network_mismatch` | The endpoint serves a different network than the one declared (an RPC URL and a `chain_id` / network passphrase that disagree). | Do not retry as-is. Report to the operator: the profile's `rpc_url` and its network do not name the same chain. |
| `network.endpoint_identity_unavailable` | The endpoint's network identity could not be established within the submission timeout. The probe is retried with bounded backoff and never falls back to the declared network. | Nothing was sent. Treat the endpoint as unusable and surface it to the operator; do not switch to a different endpoint on your own. |
| `network.envelope_signed_for_mainnet` | A signature on the envelope was made for mainnet, not for the network the endpoint serves. | Do not retry; the envelope cannot be relayed onto this chain. Re-run the simulate step for the intended network. |
| `network.envelope_signature_unverifiable` | A signature verifies under neither the endpoint's network nor mainnet, or no eligible ed25519 signer accounts for it (hash-x and pre-auth-tx signers contribute no ed25519 key). | Do not retry the same envelope. Re-run the simulate step and sign with a key the source account lists as a signer. |
| `network.envelope_unsigned` | The envelope carries no signature, or on a fee-bump the outer or the inner transaction carries none; typically a build-only envelope handed straight to a submit step. | Sign the envelope first, then submit. On a fee-bump, both the inner transaction and the fee source must sign. |
| `network.account_not_found` | A transaction-source or operation-source account on the envelope is absent from the ledger, so its signer set cannot be read. | Nothing was sent. Confirm the account exists and is funded on the target network. |

## Submission codes (unresolved outcomes)

Every value-moving verb records its transaction before it is sent: a submission
receipt, a spending-window reservation, and a `value_action_pending` audit row.
A submission whose outcome never comes back keeps that record, and the codes
below report one. Three of them carry an `error.details` object with the full
transaction hash the message redacts.

The rule for all of them is the same: **reconcile, never rebuild.** At most one
transaction per source account and sequence can ever apply, and the wallet
cannot tell whether the recorded one did. A second submission at that sequence
is refused until the first is settled, and a different fee does not get around
it.

| Code | Meaning | Agent action |
|---|---|---|
| `submission.tx_timeout` | The transaction was accepted for inclusion and was not confirmed within the submission timeout. It may still apply. `details` carries `tx_hash`, `timeout_seconds`, `outcome: "unknown"`, `reconcile_with`, and `envelope_hash` where the reporting surface holds the signed bytes. | Call `stellar_transaction_status` with `details.tx_hash` (CLI: `stellar-agent tx status <HASH>`). Do not re-simulate and do not rebuild. |
| `submission.tx_already_submitted` | A pending record already holds this transaction's source account and sequence. Nothing was sent. `details.tx_hash` names the transaction to reconcile. | Reconcile `details.tx_hash` first. Once it is settled, the sequence is free and a fresh simulate-and-commit proceeds. |
| `submission.hash_mismatch` | The endpoint reported a transaction hash that does not describe the transaction that was sent. `details` carries both hashes. | Reconcile `details.tx_hash`. Report the mismatch to the operator: the endpoint is not describing what it was handed. |
| `submission.record_unavailable` | The wallet could not durably record the submission, so nothing was sent. The condition is local: an unwritable receipt store, an unreadable spending-window file, or an audit log that cannot be appended. | Not agent-recoverable. Report to the operator; the submission is safe to retry once it is fixed. |
| `submission.tx_malformed` | The network refused the transaction outright (for example the fee was below the current floor). Nothing was queued and no value moved. | A fresh simulate-and-commit is the next step; the sequence is free. |
| `policy.approval_consumed` | The approval presented was already spent on a submission. | Check that transaction's status before asking for the action again. Do not re-present the same approval. |

What `stellar_transaction_status` reports, and what it means:

- `chain_status: "SUCCESS"`: the payment went through. Report it as done.
- `chain_status: "FAILED"`: the transaction applied and failed. Nothing moved.
- `chain_status: "NOT_FOUND"` with `record.status: "pending"`: nothing is
  settled. The transaction can still apply. Wait and call again.
- `chain_status: "NOT_FOUND"` with `record.status: "failed"`: the transaction
  can no longer apply. A fresh simulate-and-commit is the next step.
- `chain_status: "NOT_FOUND"` with `record.status: "ambiguous"`: the endpoint
  can no longer answer for it at all, and only the operator can resolve it, with
  `stellar-agent tx receipt clear <ENVELOPE_HASH> --acknowledge`.

Read `record.status`, not `record.reservation_open`. An action the policy engine
sized no value for takes no reservation at all, so `reservation_open` is `false`
for it from the start and says nothing about whether the submission settled.

An operator policy that lists tools explicitly must include
`stellar_transaction_status`, or a timed-out submission cannot be resolved
through the MCP server. The CLI verb is not policy-gated.

## Nonce codes (two-phase signing verbs)

A simulate step (`stellar_pay`, `stellar_create_account`, `stellar_trustline`,
`stellar_claim`, `stellar_rule_create`) mints a single-use nonce bound to the
exact envelope, tool, and chain. The
commit step (`*_commit`) verifies it. Nonces are single-use and TTL-bounded, and
the replay window is wiped on process restart.

| Code | Meaning | Agent action |
|---|---|---|
| `nonce.expired` | The nonce passed its expiry, or its HMAC tag does not match (these two are deliberately indistinguishable; the second covers a wrong envelope/tool/chain or a process restart since mint). | Re-run the simulate step to obtain a fresh nonce and envelope, then commit promptly. |
| `nonce.replayed` | The nonce was already consumed. Each nonce signs exactly once. | Re-simulate for a new nonce. Do not re-send the same commit. |
| `nonce.chain_mismatch` | The `chain_id` supplied to commit differs from the profile / the nonce's chain. | Re-issue with the profile's `chain_id` for both simulate and commit. |
| `nonce.invalid_envelope` | The envelope XDR is empty or cannot be hashed. | Pass the exact `envelope_xdr` returned by the simulate step; do not modify it. |
| `nonce.ttl_exceeded` | The requested TTL exceeds the profile maximum. | Request a shorter TTL within the profile bound. |
| `nonce.ttl_too_short` | The requested TTL is below the minimum floor. | Request a longer TTL at or above the floor. |
| `nonce.key_too_short` | The keyring nonce key has fewer than 32 bytes. | Operator must repair the keyring nonce key. Not agent-recoverable. |
| `nonce.input_too_long` | A length-prefixed field (`tool_name` or `chain_id`) exceeds the encoding bound. | Use a valid registered tool name and a valid CAIP-2 `chain_id`. |
| `nonce.serialise_failed` | Base64 encode/decode of the nonce failed. | Pass the nonce string exactly as returned by simulate. |
| `nonce.mint_failed` | The simulate step could not mint the single-use nonce, almost always because the profile's keyring nonce key is missing or unreadable. This fires at simulate time, before any commit, so an unpopulated keyring blocks the flow at the first write step, not at commit. | Not agent-recoverable: the operator must populate the profile's keyring nonce key. Report to the operator. |
| `tool.unknown` | The `tool_name` carried by the nonce is not in the registered catalog. | Use a registered tool name; do not hand-build nonces. |
| `nonce.unknown_error` | Forward-compatibility fallback for an unrecognized nonce error variant. | Treat as a hard failure; re-simulate. Report to the operator if it persists. |

Note: a wrong, edited, or stale envelope at commit surfaces as `nonce.expired`,
not a distinct code. The commit step also byte-compares the envelope against a
fresh rebuild before signing.

## Simulation cross-check

| Code | Meaning | Agent action |
|---|---|---|
| `simulation.divergence` | An independent-RPC cross-check (run for high-value operations and toolset-routed payments) failed: the second RPC rebuilt a different envelope, was unreachable, or timed out. Fail-closed; the wallet will not sign. | Re-simulate to obtain a fresh envelope and retry. If it persists, the two RPC endpoints disagree; report to the operator. |

## Toolset codes

`stellar_toolset_invoke` routes a toolset action to a registered tool through a
four-part capability gate. Signing tools are never reachable through a toolset
regardless of declared capabilities; the routed tool's own policy gate still
applies.

| Code | Meaning | Agent action |
|---|---|---|
| `toolset.first_invoke_approval_required` | The first time a toolset uses a signing-adjacent capability with no matching grant, a one-time gate fires and queues an approval. | Ask the operator to approve the queued entry with `stellar-agent approve --id <nonce> --profile <name>`. Once approved, a time-boxed grant suppresses only this re-prompt; the per-action payment approval still fires on every payment. |
| `toolset.unknown_action` | The action is not in the toolset's capability-to-tool matrix. | Call `stellar_toolset_list` to see the toolset's invocable actions; use one of those. |
| `toolset.capability_not_declared` | The toolset's manifest does not declare the capability needed to grant this action. | The toolset cannot perform this action. Report to the operator; do not retry. |
| `toolset.tool_not_allowed` | The resolved tool is excluded by the toolset's `allowed_tools` narrowing. | The toolset is configured not to use that tool. Report to the operator. |
| `toolset.not_installed` | The named toolset is not installed. | Verify the toolset name with `stellar_toolset_list`; install via the operator if missing. |
| `toolset.gated_missing_envelope` | A toolset sign-payment route was called without `args.envelope_xdr`. | Run `stellar_pay` (simulate) first and pass its `envelope_xdr` into the gated invoke. |
| `toolset.args_not_object` | `args` was not a JSON object. | Pass `args` as a JSON object. |
| `toolset.args_validation` / `toolset.args_deserialise` / `toolset.gated_args_deserialise` | The toolset arguments failed validation or deserialization. | Fix the argument shape to match the routed tool's schema and retry. |
| `toolset.route_missing` / `toolset.gated_route_missing` | No tool route resolved for the action. | Re-check the action name with `stellar_toolset_list`. |

## MCP server availability

| Code | Meaning | Agent action |
|---|---|---|
| `mcp.disabled_per_profile` | The active profile sets `mcp_disabled = true`, the operator kill-switch. The server refuses to start (exits non-zero); no tool calls are served. | The MCP surface is disabled for this profile. Ask the operator to select a profile with the MCP surface enabled, or clear the kill-switch. The `mcp-resource://profiles/<name>` resource reports `mcp_disabled`. |

Other startup failures (no supported platform keyring backend, an unloadable
profile, a duplicate tool registration) also cause the process to exit non-zero
before serving any request. These are operator-side environment problems, not
agent-recoverable at runtime.

## Keyring codes

| Code | Meaning | Agent action |
|---|---|---|
| `keyring.error` | A platform keyring read failed while loading the nonce key or an HMAC key on a two-phase verb. | Often the active profile names a keyring entry that holds no secret yet (the first-run testnet fallback profile uses placeholder coordinates). Only read-only tools that never touch the keyring still work: the simulate step already fails at nonce mint (`nonce.mint_failed`) when the nonce key is missing, so the flow stops there, before any commit. The operator must populate the keyring entry. Report to the operator. |
| `auth.keyring_interactive_session_required` | Windows Credential Manager requires an interactive logon session; the process is running non-interactively (service, SSH, scheduled task). | Not retryable in-place. The operator must either run from an interactive desktop session or opt into the headless keyring store (`STELLAR_AGENT_KEYRING_BACKEND=headless-dpapi` or `headless-env`, see profiles-and-keys.md). Report to the operator. |
| `io.audit_writer_setup` | The audit-log writer could not be set up (directory unwritable, or another writer process holds the `<log>.lock` sidecar). | Signing verbs refuse rather than run unaudited. Check for a second wallet process against the same profile, and that the data directory is writable. Report to the operator. |

A missing or empty **signer** keyring entry on a single-shot SEP-43 sign tool
surfaces as `sep43.wallet_unlock_failed` under the standard envelope, not a
`keyring.*` code. At the auth layer a missing keyring entry maps to
`auth.keyring_not_found`. In every case the operator must enroll the secret for
the active profile.

Keyring failures on the attestation key during a commit do not surface as a
keyring code: they are folded into the uniform `policy.approval_required` so the
approval path cannot be probed. Recovery is the same as for any
`policy.approval_required`.

## Audit-key code

| Code | Meaning | Agent action |
|---|---|---|
| `audit.tip_anchor_mismatch` | Acquiring the audit writer proved the profile's audit log no longer contains the chain tip its keyring-held anchor names. The log was restored from an older copy, truncated, or substituted, or it was replaced, truncated or overwritten while a long-lived process held the original open. The chain walk alone does not catch this: it verifies a prefix, which an older copy satisfies. A log that moved FORWARD past its anchor is not this code; that case is absorbed silently. The message says which of the shapes it was. When a row was refused mid-flight the anchor ends up one entry ahead of an otherwise clean log, which is a row the wallet owed and did not write. The MPP verbs answer with this code too, in place of `mpp.state_unavailable`. | Not agent-recoverable, and do NOT retry: the refusal is stable until an operator acts. Report it. The operator must establish why the log changed, then run `stellar-agent audit reanchor --profile <name> --acknowledge-rollback` (stopping the MCP server first, since it holds the audit writer's lock). |
| `audit.writer_locked` | A verb that needs the audit writer (`audit reanchor`, `profile rotate-audit-key`) found the writer's exclusive lock held by another process, normally a running `stellar-agent-mcp` server. | Not agent-recoverable. The operator must stop the MCP server, run the verb, and start the server again. |
| `audit.rotation_bridge_unusable` | Opening the audit log needs the rotation-handoff entry from the newest archive to seed the active file's chain, and that archive's last entry is not a handoff naming it: the archive was truncated, or a foreign file sits in the audit directory under a rotated-sibling name. | Not agent-recoverable. Report it; the operator inspects the audit directory per the recovery runbook. |
| `validation.acknowledgement_required` | `audit reanchor` was run without `--acknowledge-rollback`. It reported the anchor in force and the anchor it would write, and changed nothing. | Not an agent action at all. Accepting a rolled-back audit log is an operator judgement. |
| `audit.chain_key_unavailable` (detail begins `audit.writer_locked`, `audit.rotation_bridge_unusable`, `audit.chain_broken`, `audit.tip_anchor_unavailable`, `audit.io_error`, `audit.parse_error` or `audit.partial_rotation`) | The pre-flight refused on a condition about the audit LOG rather than about the chain-root key. The message names the condition; the sub-code at the head of the detail is what to match on. | Not agent-recoverable and do NOT rotate the audit key: none of these is fixed by minting or rotating one. Report the detail; the operator follows the recovery runbook section for that sub-code. |
| `audit.chain_key_unavailable` | A value-moving signing verb (`pay`, `claim`, `accounts create` sponsored mode, `trustline`, `trade`, `vault`, and their MCP equivalents) proved the profile's audit chain-root key is NOT acquirable, before touching the signer or submitting anything. This also covers the x402 payment tools and `stellar_sep43_sign_and_submit_transaction`. `profile init` mints the audit-log keyring coordinate only, no key material. This pre-flight fails closed only for a persisted profile. The zero-config synthesized profile `pay`/`claim`/`accounts create` fall back to when no profile was NAMED and no `default.toml` exists stays fail-open here. A profile named through `--profile` or `STELLAR_AGENT_PROFILE` whose file does not exist is refused with `profile.load_failed` instead. The SEP-43 sign-only pair (`signTransaction`, `signAuthEntry`) is not yet covered. | Not agent-recoverable. The operator must run `stellar-agent profile rotate-audit-key <name>`, then retry. |

This is distinct from `io.audit_writer_setup` above. That code covers smart-account
governance writes (rule changes, timelock, multicall) failing to open their
own audit writer (unwritable directory, lock contention). This is a narrower, unrelated check that does not depend on the profile's audit chain-root key.

## Profile-selection code

| Code | Meaning | Agent action |
|---|---|---|
| `profile.load_failed` | The profile the operator NAMED through `--profile` or `STELLAR_AGENT_PROFILE` could not be loaded. Most often no such file exists. On the value-moving verbs (`pay`, `claim`, `accounts create`, `trade`, `vault`; `trustline` uses `trustline.profile_load_failed`) a malformed TOML or an unsupported schema version produces this same code with a different cause in the message. Every other command reports those two as `validation.config_invalid` and an absent file as `validation.profile_not_found`, so do not treat this code as the only shape a load failure takes. `pay`, `claim`, and `accounts create` substitute the in-memory zero-config profile ONLY when no name was given at all. So a named profile is never silently replaced by it, including `--profile default` on a host with no `default.toml`. | Not agent-recoverable by retry. Report the name in the message to the operator. Either it is a typo (or a stale `STELLAR_AGENT_PROFILE`) and the correct name should be used. Or the profile has not been created yet and the operator must run `stellar-agent profile init --profile <name>`. Do not re-run without a name to make the error go away. That silently switches which policy engine governs the call. |
| `profile.name_mismatch` | The profile FILE that was loaded belongs to a different profile: its `policy_owner_key_id.service` names another profile, or carries no `stellar-agent-owner-` prefix at all. Both binaries refuse it: the MCP server at startup, the CLI at every command that loads a profile. The refusal applies because the signed policy file and the owner-key keyring entry resolve through the name the FILE carries. The approval store, audit log, and policy-window state key on the name that was ASKED for. Almost always a copied or renamed `<name>.toml`. Distinct from `validation.config_invalid`, which covers the profile CONFIGURATION being unusable: a name that is not a valid path component, a malformed TOML, an unsupported schema version, an out-of-range field. None of these conditions is covered by this code. Here the file parses and the name is valid; it simply belongs to another profile. | Not agent-recoverable by retry, and do NOT retry under a different profile name. Report the message to the operator: it names both profiles and quotes the offending field. Recovery is `stellar-agent profile init --profile <name>` for a genuinely new profile, or correcting `policy_owner_key_id.service` to `stellar-agent-owner-<name>`. `stellar-agent profile show <name>` still displays the file so the field can be read. |

## SEP-24 interactive POST contract

`stellar_sep24_interactive_url` performs the interactive deposit/withdraw
hand-off by `POST .../transactions/{op}/interactive` with a caller-supplied
SEP-10/45 JWT, and returns the interactive URL, transaction id, and a hand-off
note. The wallet never opens, scrapes, or follows the URL and transmits no KYC
field.

Wire-contract note for anyone building the request the wallet relays: the
interactive POST body must be sent as `application/json` (form-urlencoded is
rejected by Anchor Platform with HTTP 500), and every value must be a JSON
string, not a native JSON type:

- `amount` is a string (`"10"`, not `10`).
- `claimable_balance_supported` is the string `"true"` / `"false"`, not a
  boolean.

If the anchor returns HTTP 500 on a request that looks correct, suspect a
form-urlencoded body or a non-string field value.

## Recovery quick reference

MPP codes are closed and redacted. Input/selection failures include
`mpp.challenge_invalid`, `mpp.challenge_ambiguous`,
`mpp.challenge_mismatch`, `mpp.challenge_expired`, `mpp.unsupported_method`,
`mpp.unsupported_intent`, `mpp.unsupported_mode`, `mpp.network_forbidden`, and
`mpp.input_too_large`. Approval/state/signing failures include
`mpp.approval_required`, `mpp.approval_invalid`,
`mpp.authorization_not_found`, `mpp.authorization_replayed`,
`mpp.authorization_indeterminate`, `mpp.state_unavailable`,
`mpp.simulation_failed`, `mpp.signing_failed`, and
`mpp.credential_too_large`. Observation failures are `mpp.receipt_invalid`,
`mpp.receipt_conflict`, and `mpp.reconciliation_unavailable`.

`mpp.authorization_not_found` means no authorization matches the identifier
you supplied, including on a profile that has never prepared a charge. It is a
normal answer: correct the identifier or prepare a charge. Do not report it as
a wallet fault. `mpp.state_unavailable` means the durable state or a
prerequisite of it exists and cannot be used. Its store causes (unreadable or
unverifiable store, unreadable state key, unusable clock, capacity ceiling) are
operator problems that retrying will not clear. The exception is a concurrent update, whose message says the state changed during the update and asks for a retry. Its call causes (malformed
identifier, an input file that is not a bounded regular file) mean the call was
wrong. Correct it and retry. A malformed identifier answers this way on every
store state, so it never reveals whether a profile has MPP state.

The MPP verbs that write an audit row before returning (charge commit, record
receipt, reconcile, prune) answer an audit-log problem under its own `audit.*`
code rather than `mpp.state_unavailable`. The remedy is a different one: the MPP state file is intact and the audit log is what needs attention. Treat
`audit.chain_key_unavailable` and `audit.tip_anchor_mismatch` from an MPP verb
exactly as the rows above say.

`mpp state prune` on a profile with no MPP history succeeds with `pruned: 0`
once the profile's audit key is minted (`stellar-agent profile
rotate-audit-key <profile>`); like every audited verb it refuses without one,
here with `audit.chain_key_unavailable`.

For `mpp.approval_required`, wait for the operator and resume the exact stored
authorization. For replayed, indeterminate, withheld, signing, state, receipt,
or reconciliation ambiguity, do not retry commit or create another payment;
query authorization status and reconcile any known server transaction.

- Approval needed (`policy.approval_required`, `toolset.first_invoke_approval_required`):
  ask the operator to run `stellar-agent approve --id <nonce> --profile <name>`, then re-submit
  the commit with `approval_nonce` and `approval_attestation`.
- Approval not honorable on this tool (`policy.approval_required_unsupported`):
  operator must change policy or use a two-phase tool.
- Stale or used nonce (`nonce.expired`, `nonce.replayed`),
  cross-check failure (`simulation.divergence`): re-run the simulate step and
  commit promptly.
- Hard policy refusal (`policy.deny.*`, `policy.engine_required`,
  `network.mainnet_write_forbidden`): do not retry; only the operator can change
  policy or network posture.
- Network binding refusal (`network.endpoint_network_mismatch`,
  `network.endpoint_identity_unavailable`, `network.envelope_signed_for_mainnet`,
  `network.envelope_signature_unverifiable`, `network.envelope_unsigned`,
  `network.account_not_found`): nothing was sent. Do not resubmit the same
  envelope against the same endpoint; report the mismatch to the operator.
- Environment or key problems (`keyring.*`, `mcp.disabled_per_profile`,
  `audit.chain_key_unavailable`, other non-zero startup exits): operator-side;
  not agent-recoverable at runtime.
