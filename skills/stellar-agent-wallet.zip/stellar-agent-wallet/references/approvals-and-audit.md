# Approvals and audit

The guardrail loop that sits between an agent's tool call and any signing or
network action: the policy engine, the operator-approval spine, attestations,
and the hash-chained audit log. This file is self-contained; for the MCP tool
surface that drives the simulate/commit handshake see `./mcp-tools.md`.

## The model in one paragraph

Every tool/command invocation is evaluated by the active policy engine before
any RPC call or signature. The engine returns Allow, Deny, or RequireApproval.
A RequireApproval action does not execute on the agent's say-so: it is held in a
per-profile pending-approval store and returns an `approval_nonce`. The wallet
owner runs `stellar-agent approve --id <nonce> --profile <name>` out-of-band in a trusted
context, reads a wallet-controlled summary, and consents. The command records an
HMAC attestation bound to the profile name, CAIP-2 chain id, exact envelope, nonce, and
local user, and returns `approval_attestation`. The agent presents that blob to
the matching `*_commit` tool, which constant-time-verifies it before executing.
Every invocation and lifecycle event is appended to a hash-chained audit log
that `stellar-agent audit verify` checks for tampering.

## Conventions used across these surfaces

- Result envelope: `{ok, data, request_id}` on success, `{ok: false, error,
  request_id}` on failure, used by every command group including `profile`,
  `approve`, `audit`, `credentials`, and `toolsets`.
- Exit code: `0` on success, `1` on any error.
- Amounts are decimal strings with a unit (for example `"10 XLM"`), never JSON
  numbers. Asset is `native`/`XLM` or `CODE:GISSUER`.
- `chain_id` is the CAIP-2 id, `stellar:testnet` (default) or `stellar:mainnet`.
- The `profile`, `credentials`, `approve`, and `audit` groups operate only on
  local state (TOML files and platform-keyring entries). None submits a
  transaction, so the network flags and the mainnet-write gate do not apply to
  them.

## The policy engine

Each invocation is evaluated before it does anything. Three decisions:

| Decision | Meaning |
|---|---|
| Allow | The call proceeds. |
| Deny | The call is refused, carrying a typed reason with a stable wire code. |
| RequireApproval | The call is held pending an out-of-band operator approval. |

The engine that runs is selected per profile in `[policy]`. Two structural rules
apply on every surface: the default network is `stellar:testnet`. Every write or
signing command structurally refuses `stellar:mainnet`
(`network.mainnet_write_forbidden`), except MPP, which refuses with
`mpp.network_forbidden`. This covers `--network` commands and the profile-driven
write commands before any RPC call or signature. At the submit layer it covers
both a declared mainnet passphrase and a known mainnet RPC URL, each with no RPC
call at all. Meanwhile `stellar:mainnet` stays accepted for read-only commands.
The submit layer additionally asks the endpoint which network it serves and
binds the submission to that answer rather than to the declared network,
verifying every signature on the envelope against it; see
references/troubleshooting.md for those wire codes.

### Noop engine

The binding gate used when no full engine is configured. Behavior is fixed:

| Profile | Tool | Result |
|---|---|---|
| testnet | any | Allow |
| mainnet | read-only | Allow |
| mainnet | destructive | refused with `policy.engine_required` |

A destructive tool on a mainnet profile cannot pass the Noop engine. Newly
minted profiles default to the V1 engine.

### V1 engine

Evaluates a signed policy document against typed Criteria. The document carries
an ed25519 owner signature over its canonical form; an invalid signature, or a
signature from a key rotated after signing, is rejected.

Evaluation is first-match, default-deny:

1. Rules are walked in declaration order.
2. The first rule whose match (tool name plus chain-id filter) applies is selected.
3. That rule's criteria run in order; the first failing criterion produces a Deny.
4. If all criteria pass, the rule's decision is returned.
5. If no rule matches, the call is denied (`no_matching_rule`).

A Criterion is one typed check: per-transaction cap, per-period (windowed) cap,
rate limit, counterparty allowlist (by classic account, contract account, asset
issuer, or resolved home domain), minimum-reserve guard, multicall bundle-level
checks (inner-count cap, aggregate cap, rejection of
unrecognized inner shapes), quorum satisfaction, a home-domain-resolved guard,
and SEP-10 / SEP-45 session-active checks. Criteria needing external state
(reserves, identity, the counterparty cache, an active session) receive it as an
injected view at the dispatch site; when a required view is absent the criterion
fails closed.

At the MCP boundary, account, strkey, and contract-id fields inside a deny
reason are redacted to first-five-last-five before crossing the wire. The tool
registry is fail-closed at startup: a duplicate tool registration or an
unrecognized policy-engine kind is a fatal error, not a silent fallback.

## The simulate / approve / commit handshake

For a signing-adjacent action the agent uses a two-call pattern across the MCP
tools, with the operator's `approve` step in between:

```
1. agent  -> *_build / *_simulate tool
              returns { ..., approval_nonce } and records a pending entry
2. operator: stellar-agent approve --id <approval_nonce> --profile <name>
              reads wallet-controlled summary, consents,
              returns { ..., approval_attestation }
   (operator relays approval_attestation to the agent over a trusted channel)
3. agent  -> *_commit tool, with approval_attestation = <blob>
              commit verifier recomputes + constant-time-compares, then executes
```

Step 1 returns the nonce instead of executing. Step 3 presents the attestation
blob as the `approval_attestation` argument of the matching `*_commit` tool.
The attestation binds the specific envelope, so it authorises exactly one
transaction.

### What `approve --id <nonce> --profile <name>` returns

For a payment-style approval the response includes `approval_attestation`, the
HMAC blob (URL-safe base64, no padding) the agent must present to `*_commit`.
The field is omitted for approval kinds whose gate reads the recorded consent
from the store directly (toolset first-invoke grants, trustline clawback opt-ins).

The `approval_attested` row is written before the approval is persisted. `audit`
is `"written"` when the command wrote it to the log. It is `"queued"` when a
running MCP server or `approve serve` inbox held the audit writer and the row
went to the audit outbox. That process appends it to the log before any process
loads a signing key for the approved action. The command refuses and persists nothing
beside a process that does not drain the outbox (`audit.writer_locked`), and on
any other audit failure. After upgrading, restart a running MCP server and
`approve serve`: `approve --id` refuses beside an older one.

```json
{"ok":true,"data":{"approval_nonce":"ABCxyzNonce","attested":true,"process_uid":"501","expires_at_unix_ms":1717000000000,"approval_attestation":"q83vEjRWeJq83v...","audit":"written"},"request_id":"..."}
```

## The approval spine

When the policy engine returns RequireApproval, the action is held in the
approval spine: a per-profile pending-approval store plus a cryptographic
attestation minted at approve time.

### The pending-approval store

A per-profile TOML file at `<approval_dir>/<profile>.toml` holding a flat list
of pending entries:

- A single exclusive advisory lock on a sidecar lock file is held for the
  store's lifetime; a second opener is rejected immediately
  (`approval.writer_locked`).
- Writes are atomic (write-to-temp then rename, with a parent-directory fsync);
  the file is created owner-only.
- Nonces are validated on load; malformed nonces are rejected. The store has a
  hard cap on pending entries (expired entries pruned first) and a default entry
  TTL of 24 hours.

Entry kinds: `PaymentSimulated`, `ClaimSimulated`, `SignWithPasskey`,
`RegisterPasskey`, `ToolsetFirstInvokeGate`, `TrustlineClawbackOptIn`,
`RuleProposalSimulated` and `MppChargeSimulated`.
`Rejected` and `Consumed` record resolved requests and cannot be approved.

### What `approve` does

`stellar-agent approve --id <nonce> --profile <name>` loads the store and renders a
wallet-controlled summary of the pending action. The summary is produced by the
command from the stored, validated entry fields, never from anything the agent
supplied, so the agent cannot influence what the operator sees (it cannot inject
terminal-rendering content into the summary). The operator confirms at the
terminal; the command then records the consent. Recording is one-shot: a nonce
that is expired, of the wrong kind, or already attested is rejected. Approval is
bound to the local user: the process uid recorded at create time is re-derived
at approve time and must match, so a different local user cannot consent on the
holder's behalf.

Per kind:

| Kind | What `approve` records |
|---|---|
| `PaymentSimulated` / `ClaimSimulated` | Computes the HMAC attestation over the envelope SHA-256 and persists it; returns `approval_attestation`. Both kinds share the same attestation path. |
| `TrustlineClawbackOptIn` | Computes a domain-separated HMAC over `(network, code, issuer)` and stores it; the trustline gate recomputes and verifies it. No `approval_attestation` returned. |
| `ToolsetFirstInvokeGate` | Builds and persists a time-boxed toolset grant, then consumes (removes) the pending entry. Does not set an attestation blob on the entry. No `approval_attestation` returned. |
| `RuleProposalSimulated` | Computes the HMAC attestation over `proposal_sha256` (the domain-separated digest of the FULL resolved rule definition), not an envelope hash; persists it and returns `approval_attestation`. A DEDICATED gate verifies it at commit. The shared `PaymentSimulated`/`ClaimSimulated` gate rejects this kind outright. |
| `MppChargeSimulated` | Attests the prepared artifact hash under the profile and chain binding; returns `approval_attestation`. |
| `Consumed` | Already resolved; cannot be attested again. |

For every kind the consent row is written first and is fatal: when it cannot be
written, nothing is recorded. The store entry is re-read under its lock just
before the row. An entry another process attested, rejected, or consumed since
validation is refused with `approval.already_attested`, `approval.rejected`, or
`approval.consumed`, and no row is written.

The CLI summary and both inbox detail pages show the profile name, CAIP-2 chain id, endpoint authority, and enrolled signer.
An enrollment placeholder appears as `(not enrolled)`.
Payment and claim rows show the envelope's effective source; an operation source overrides the transaction source.
An undecodable envelope appears as `(undecodable envelope)`.
A claim whose stored summary source differs also shows `Source (stored summary)`.

### The attestation

The attestation is an HMAC-SHA256 tag, keyed by the profile's attestation key
(which lives only in the platform keyring), over a length-prefixed canonical
input:

```text
mac.update(b"stellar-agent-approval-attestation:v2")
mac.update(u32_be(len(profile_name)))   mac.update(profile_name)
mac.update(u32_be(len(chain_id)))       mac.update(chain_id)
mac.update(u32_be(len(approval_nonce))) mac.update(approval_nonce)
mac.update(envelope_sha256)
mac.update(u32_be(len(process_uid)))    mac.update(process_uid)
```

Lengths count UTF-8 bytes, encoded as big-endian `u32` with saturation at `u32::MAX`.
The 37-byte tag has no length prefix or NUL terminator; the digest is 32 bytes with no prefix.
The tag separates this HMAC from every other use of the key.
The profile name and CAIP-2 chain id make a blob unverifiable under another profile or chain.
A layout change bumps the tag; blobs under the previous tag do not verify.

The length prefixes prevent boundary-collision attacks. The `envelope_sha256`
slot binds the tag to the exact transaction envelope that will be signed. The
`process_uid` (numeric OS uid on Unix) gives cross-account-on-host non-replay: a
tag minted by one local user cannot be replayed by another.

The MCP commit-path verifier recomputes the tag and compares it in constant
time. It collapses the distinct internal outcomes (Expired, NotFound,
AlreadyAttested, forged) into the single wire code `policy.approval_required`,
so a caller cannot probe which state a nonce is in. The CLI `approve` path
surfaces distinguishable errors to the operator, who is the wallet owner.

The attestation proves the keyring holder ran `approve`, not that a human
clicked "yes" in an agent-controlled UI. An attacker who can write to the store
file can delete a pending entry (a denial-of-service nuisance forcing
re-approval) but cannot forge an attestation, because the HMAC key is in the
keyring, not the file. Rotating the attestation key invalidates all outstanding
pending approvals.

### `approve` command reference

`stellar-agent approve --id <NONCE> --profile <name>`: state-changing (records an attestation or
a grant in the on-disk store).

| Flag | Required | Default / resolution | Meaning |
|---|---|---|---|
| `--id <NONCE>` | yes (this form) | none | The approval nonce from the agent surface's simulate/build response. |
| `--profile <NAME>` | no | `--profile`, then `STELLAR_AGENT_PROFILE`, then `default` | Profile whose attestation key and store to use. |
| `--yes` | no | off | Non-interactive auto-approve. Bypasses the stdin prompt; the wallet-controlled summary is still printed for a visible record. For trusted automation and tests, not routine operator use. |

Interactively the command prints the summary and prompts `Approve? [y/N]:`;
only `y`/`yes` (case-insensitive) consents, everything else (including empty
input, `n`, EOF) denies. Exits `1` when the nonce is unknown, expired, already
attested, created by a different local user, denied at the prompt, or on I/O
error.

```bash
stellar-agent approve --id ABCxyzNonce --profile <name>
stellar-agent approve --id ABCxyzNonce --profile myprofile --yes
```

`stellar-agent approve gc`: state-changing. Evicts every pending entry whose
TTL has elapsed and reports the count. When `gc` is present, any `--id` is
ignored. Evicting zero entries is a success.

| Flag | Required | Meaning |
|---|---|---|
| `--profile <NAME>` | no | Profile whose store to garbage-collect (same resolution as above). |

```bash
stellar-agent approve gc --profile default
```
```json
{"ok":true,"data":{"profile":"default","evicted_count":3},"request_id":"..."}
```

## Operator approval surfaces

The agent's job is the same regardless of how the operator consents: present
the `approval_nonce` from the simulate/build response, wait for the operator
to produce an `approval_attestation`, then call the matching `*_commit` tool
with it. Three surfaces exist for the operator side of that handshake:

- **CLI, one at a time**: `stellar-agent approve --id <NONCE> --profile <name>` (see the command reference), or
  `stellar-agent approve list` to enumerate every pending entry first
  (read-only; `--include-expired` also shows expired ones).
- **Loopback web inbox**: `stellar-agent approve serve` binds a local HTTP
  server and opens a browser to the pending-approval queue, so the operator
  clicks Approve/Reject per entry without running `approve --id <nonce> --profile <name>` per nonce.
- **Remote approval**: `stellar-agent approve serve --remote
  --confirm-remote-exposure` binds a TLS-protected listener reachable from a
  device other than the wallet host, authenticated by a registered WebAuthn passkey. Use it when the agent runs on a headless machine. Every approve or
  reject additionally requires a fresh passkey assertion bound to the exact
  entry.

None of this changes what the agent does or what an attestation proves. See
"The attestation" above. Setup for remote approval (the profile's
`[remote_approval]` block, enrolling a passkey via `approve operator enroll`,
the trust model, DNS requirements) is out of scope here; see
`docs/remote-approval.md` in the wallet repository for the full operator
guide.

A remote approve or reject is recorded in the audit log under
`ApprovalAttestedRemote` / `ApprovalRejectedRemote` event kinds rather than
the loopback `ApprovalAttested` / `ApprovalRejected` ones. This is the distinguishing detail when reading the audit log directly. Both remote kinds also carry
`operator_credential_id_redacted`, a stable, non-reversible pseudonym for
which passkey credential consented (the first 8 hex characters of
`SHA-256(credential_id_b64url)`). Nothing else about the attestation or its
binding differs from a local approval.

## First-invoke gate vs. per-action payment approval

Toolset-routed payments use two distinct controls, and only one is suppressible.

- The first-invoke gate fires the first time a toolset uses a signing-adjacent
  capability with no matching grant. It queues a one-time `ToolsetFirstInvokeGate`
  entry. Once the operator approves it, a time-boxed toolset grant is persisted
  (default TTL 30 days) and matched on later invocations by toolset, capability,
  destination, asset, an amount range, plus its TTL. The grant suppresses only
  the first-invoke re-prompt.
- The per-action payment approval (`PaymentSimulated`) fires unconditionally on
  every toolset-routed payment, and its attestation binds the actual executed
  envelope. A forged or tampered grant can at most suppress a re-prompt; it
  cannot bypass the per-action approval, because that approval is forced
  regardless of any grant and is bound to the real transaction.

## The hash-chained audit log

A per-profile, append-only JSONL file recording every tool invocation and
lifecycle event. The writer is a per-profile singleton holding an exclusive
lock, appending with an fsync per line; a second opener is rejected. Files
rotate at a size bound with a fixed number of rotated files retained.

Each entry carries: a timestamp, the tool name, the chain id, the argument key
names (`arg_keys`), the envelope hash, the nonce id, the policy decision
(`allow` / `deny:<reason>` / `require_approval`), an optional decision reason, a
request id, the event kind, and the previous entry's hash. Argument values are
never logged; only their key names are. Strkeys in a decision reason are redacted to
first-five-last-five and transaction hashes to first-eight-last-eight; the
envelope hash is left intact (it is a SHA-256 digest carrying no user data).

Beyond tool invocations, the log records `value_action_submitted` on every
confirmed value-moving submit (carrying the gate-sized value legs) and
`keyring_key_written` on each key-writing profile command. It records
`x402_payment_authorized` before a signed x402 authorization leaves the wallet
in the RPC re-simulation. When that payment then fails, it records
`x402_authorization_withheld` with the same request id and a `failure_stage`
of `resimulation`, `response_processing`, or `encoding`. MPP adds
`mpp_charge_authorized`, `mpp_authorization_withheld`, `mpp_receipt_observed`,
and `mpp_settlement_reconciled`; these carry only hashes, redacted references,
the exact policy-sized legs, and closed status labels, never a credential,
challenge, receipt, XDR, or signature.

`MppChargeSimulated` is a dedicated short-lived approval kind. It binds the
authorization fingerprint, prepared artifact hash, profile, testnet, payer,
transport authority/target, amount, token, recipient, simulated fee, and
challenge expiry. Local and remote views redact payer/recipient. A policy change
from allow to require-approval promotes the stored authorization into this flow;
commit cannot sign until the matching attestation exists.

Each entry's hash is computed over its own canonical JSON (with the previous-hash
field treated as empty) concatenated with the previous entry's hash, chaining
every entry to the one before it. The first entry of the very first file chains
off a fixed zero block; the first entry of each later file chains off the prior
file's rotation-handoff entry. Each file also carries a `root_hmac` sidecar
signing the chain root with the profile's audit key.

### The tip anchor

The chain and the per-file `root_hmac` sidecars verify a PREFIX of the log, so
restoring an older copy of the active file, or truncating it, leaves a log that
still verifies. The tip anchor closes that: for each log PATH the keyring holds
the active file's entry count, last-entry hash, and byte offset.

The anchor, the re-anchor counter, and the audit binding live in the keyring,
outside the log file. Anyone who can restore the keyring's own storage together
with the log can restore an older state. With a headless keyring backend these
entries are kept in a file on the same host. Anyone who can write that file can
restore older entries or delete one, which needs no key material. A deleted
binding is recorded again from the profile file at the next keyed use. Under
`headless-dpapi` an owner entry still in the older form can be moved to another
coordinate until a V1 verb or `enroll-owner-key` rewrites it.

Every value-moving verb checks the anchor before signing, on every acquisition of
the audit writer. Five outcomes:

| Log versus anchor | Result |
|---|---|
| The file at the log path is not the one the process already has open | Refuses `audit.tip_anchor_mismatch`; the cached writer is dropped so the next call reads the path afresh |
| Exactly the anchored tip | Proceeds |
| Ahead of the anchor, anchored entry intact | Proceeds; the tail is absorbed and the anchor advances |
| Behind the anchor, or the anchored entry is not at the anchored offset | Refuses `audit.tip_anchor_mismatch` |
| No anchor, file has entries, chain verifies | Adopts the current tip and records `audit_tip_anchored { reason: adopted }` |
| No anchor, file empty | Proceeds; no anchor and no row until the first append |

The ahead-of-anchor case is ordinary, not an exception. Writers opened without
the audit key append without moving the anchor: the CLI startup advisory, and
the zero-config and read-only smart-account paths of a profile whose audit key
is not minted. Adoption needs
no operator action and is what happens on the first run after upgrading a wallet
whose audit log predates the anchor. An adoption writes its row only for a
non-empty file.

The anchor names a PATH, not a profile, so a changed `audit_log_path` or audit
key has an anchor coordinate of its own. The audit binding guards that change.

### The audit binding

For each persisted profile the keyring records the SHA-256 of its lexically
normalized `audit_log_path` and its audit-key coordinate, at service
`stellar-agent-auditbinding-<profile>`, account `default`. The first keyed use
records it from the profile file. Before the audit key loads, every keyed audit
writer compares the profile with the record:

| Record | Persisted profile | Synthesized zero-config profile |
|---|---|---|
| Absent | Records it and proceeds | Proceeds; records nothing |
| Equal | Proceeds | Proceeds |
| Different or unparseable | Refuses `audit.log_binding_changed` | Refuses `audit.log_binding_changed` |

The refusal names the profile and the remedy, never a path or coordinate. It
covers the value-moving verbs and tools, the read-only smart-account verbs,
`approve --id <nonce>`, `approve serve`, `audit verify --profile`, and `profile rotate-audit-key`, and
creates nothing at the path the profile names. A command whose audit row is
best effort skips the row and continues:
`credentials add-passkey`, `profile reset-window-state`, and the other `profile`
enroll and rotate verbs.
Not agent-recoverable: the operator establishes
why the profile changed, then runs `stellar-agent audit reanchor --profile
<NAME> --acknowledge-binding-change`. The zero-config profile has no profile
file, and `audit reanchor` loads only a profile file: restore the `default.toml`
that recorded the binding, or write one that names the log, then run the
reanchor.

The default `audit_log_path` derives from the OS data directory, which follows
`$HOME` and `$XDG_DATA_HOME`. Two profile files of one name in two data roots
that share one keyring bind different digests and refuse each other; set an
explicit `audit_log_path` there.

A rotation leaves the anchor on the outgoing file's handoff entry until the new
file's first append, so restoring the whole audit directory to an earlier
snapshot is refused rather than absorbed.

The anchor is written after the entry it covers is fsynced, so it is not
continuous in time. Three states, differing in kind:

- **Lagging**: between an entry's fsync and its anchor write, the anchor names
  the previous entry of this file. A rollback to that entry or later is
  absorbed; anything earlier is still refused. Retried on the next append.
- **Off, nothing anchored yet**: until the first keyed append on a log path (a
  new profile, a log written before the anchor existed). Adoption takes the file
  as it finds it. A changed `audit_log_path` is refused by the audit binding
  until it is acknowledged.
- **Off, freshly rotated file**: from a rotation until the first append into
  the new file is anchored. Any prefix of that file is accepted if it chains
  from the archive's handoff.

Entries already in an archive stay guarded in all three.

What it does NOT do is detect forgery. The entry-to-entry chain hash is unkeyed,
so an appended well-formed entry moves the tip forward and is accepted, exactly
as an honest append is. The anchor detects rollback, truncation, and
substitution, within the keyring scope stated above.

Recovery from a mismatch is `stellar-agent audit reanchor --profile <NAME>
--acknowledge-rollback`. Recovery from a changed binding is the same verb with
`--acknowledge-binding-change`. Not agent-recoverable: the operator has to
establish why the log or the profile changed before accepting it.

### Fail-closed on an unminted audit key

`profile init` mints the audit chain-root key's keyring coordinate only, no key
material. Every value-moving signing verb, CLI and MCP alike, loaded from a
persisted profile proves the audit writer is acquirable BEFORE the signing key
is touched or a transaction is submitted. If the key was never minted (run
`stellar-agent profile rotate-audit-key <name>`), the verb refuses
`audit.chain_key_unavailable` instead of signing unaudited. This applies on
both policy engines. It is distinct from the writer's post-confirm emission
(the `value_action_submitted` row above), which stays non-fatal: the
transaction has already committed by then, so refusing helps nobody.
Read-only tools and the build/simulate stages of two-phase verbs never reach
this pre-flight. The zero-config synthesized profile `pay`/`claim`/
`accounts create` fall back to when no profile was NAMED and no `default.toml`
exists stays fail-open for this specific check, matching its documented
no-profile-required posture; a profile named through `--profile` or
`STELLAR_AGENT_PROFILE` whose file does not exist is refused outright. The
SEP-43 sign-only pair (`signTransaction`, `signAuthEntry`) runs the same
pre-flight and records an `opaque_payload_signed` row when the signature is
produced.

### `audit verify` command reference

`stellar-agent audit verify <LOG_PATH>`: read-only. Walks the log oldest-first,
follows rotation manifests across rotated files, and verifies the hash chain end to end. Each entry's recorded previous-hash matches the recomputed prior-entry hash. Each file's first entry chains correctly across the rotation boundary. Each rotation handoff names the actual next file (defeating file-substitution).
When `--profile` is supplied it also verifies the chain-root HMAC sidecars;
without it, only the hash chain is checked and `hmac_verified` is `false`.

The tip anchor is checked only when `--profile` is supplied AND `<LOG_PATH>` is
the log that profile configures, since the anchor names a path. Every other case
reports `anchor.status` as `"not_checked"` with the reason and still verifies the
chain in full. The check applies the same rule the writer applies, including
proving the anchored entry is still at the anchored offset, so a longer
internally consistent log that does not contain it refuses rather than passing on
length alone. With `--profile` the profile's audit binding is read and never
written: a changed or unparseable binding exits `1` with
`audit.log_binding_changed`.

| Argument | Required | Meaning |
|---|---|---|
| `<LOG_PATH>` (positional) | yes | Path to the audit log file. |
| `--profile <NAME>` | no | Profile whose chain-root HMAC key verifies the sidecars. |
| `--output <FORMAT>` | no | Output format; `json` is the default and only stable format. |

Default log path by OS:

| OS | Path |
|---|---|
| Linux | `~/.local/share/stellar-agent/audit/<profile>.jsonl` |
| macOS | `~/Library/Application Support/Soneso.stellar-agent/audit/<profile>.jsonl` |
| Windows | `%LOCALAPPDATA%\Soneso\stellar-agent\data\audit\<profile>.jsonl` |

On Unix, the command refuses to verify a log whose parent directory is owned by
a different user (such a directory could be used to substitute files or
sidecars). Exits `0` when the chain is intact, `1` on any integrity violation, a
path-contract failure, or an I/O error. Verification failures use a closed set
of wire codes, for example `audit.chain_broken`, `audit.rotation_gap`,
`audit.hmac_mismatch`, `audit.tip_anchor_mismatch`, with line and file detail
kept out of the code.

`outbox_pending` counts the consent rows queued in the audit outbox beside the log (`<LOG_PATH>.outbox`) and not yet drained into it, read without taking the outbox lock. Queued rows sit outside the tip anchor until a draining writer appends them. A torn outbox adds an `outbox_torn_tail` warning and unparseable lines add `outbox_unparseable`. An unreadable outbox adds `outbox_unreadable` and omits `outbox_pending`, since no count is known. None of them changes the chain verdict.

```bash
stellar-agent audit verify ~/.local/share/stellar-agent/audit/default.jsonl --profile default
```
```json
{"ok":true,"data":{"entries_verified":42,"files_walked":2,"hmac_verified":true,"per_file":[],"warnings":[],"audit_writer_degraded":false,"anchor":{"status":"verified","reason":null},"outbox_pending":0},"request_id":"..."}
```

### `audit reanchor` command reference

`stellar-agent audit reanchor --profile <NAME>` with `--acknowledge-rollback`,
`--acknowledge-binding-change`, or both: the only way out of an
`audit.tip_anchor_mismatch` or `audit.log_binding_changed` refusal.
Operator-only; an agent must never run it on its own initiative, because it
accepts a log or a profile change that may have been tampered with.

| Argument | Required | Meaning |
|---|---|---|
| `--profile <NAME>` | yes | Profile whose configured log path identifies the anchor. |
| `--acknowledge-rollback` | per the matrix below | Accept the log's current tip as authoritative. |
| `--acknowledge-binding-change` | per the matrix below | Accept a log path or audit key that differs from the recorded binding. |

| Recorded binding | Current path's anchor | Flags required | Rows appended |
|---|---|---|---|
| Equal or absent | Any | `--acknowledge-rollback` | `rollback_acknowledged` |
| Changed or unreadable | Absent, or agrees with the log | `--acknowledge-binding-change` | `binding_changed` |
| Changed or unreadable | Disagrees with the log, or cannot be parsed | Both | `rollback_acknowledged`, then `binding_changed` |

A flag the matrix does not require is ignored. A missing flag changes nothing
and exits `1` with `validation.acknowledgement_required`, naming the flag. With
the required flags it replays the whole log and refuses a broken chain. It then
writes the current tip, bumps the current path's re-anchor counter once, and
appends the rows, each carrying that count. `rollback_acknowledged`
names the superseded anchor; `binding_changed` names the old path's anchor, or
none when the record was unreadable. The new binding is stored last, and an
absent binding is recorded after a rollback repair. It takes the audit writer's
exclusive lock, so a running MCP server must be stopped before a rollback
repair; with one running it refuses `audit.writer_locked`. A binding change needs
no stop: a server running the edited profile refuses before it opens the new
path, so it holds no lock there. A server still running the old profile refuses
after the acknowledgement until it restarts.

Queued consent rows follow the repair rows and are counted in `outbox_drained`. A drain refusal leaves the repair in force and exits `0`. It omits `outbox_drained`, since every queued row stays queued, and lists the refusal under `warnings`: `audit.outbox_unusable`, `audit.outbox_busy`, or the condition an append refused on, such as `audit.io_error`.

```json
{"ok":true,"data":{"profile":"default","previous_anchor":"42:18104","current_anchor":"39:16820","reanchor_count":1,"acknowledged":["rollback"],"recorded_binding":"equal","previous_binding_anchor":null,"outbox_drained":0},"request_id":"..."}
```

## The governance loop end to end

1. The agent surface evaluates an action against the policy engine. An action
   needing operator consent records a pending approval and returns its nonce
   instead of executing.
2. The wallet owner runs `approve --id <nonce> --profile <name>` in a trusted context, reads the
   wallet-controlled summary, and consents. The command writes an HMAC
   attestation (or a toolset grant) bound to the profile name, chain id, nonce,
   envelope digest, and local user.
3. The agent surface verifies the attestation and executes. Every invocation and
   lifecycle event is appended to the hash-chained audit log.
4. The operator periodically runs `audit verify` with `--profile` to confirm the
   hash chain, the chain-root HMAC sidecars, and the tip anchor are all intact.

## Key rotation that backs the loop

Rotation subcommands generate a fresh 32-byte secret from the OS CSPRNG and
atomically replace one keyring entry the profile names. The raw bytes never
leave the keyring, are never logged, and are never returned. Rotation is not
reversible; each one invalidates material minted under the old key. Each takes
the profile as either a positional `<NAME>` or a `--profile <NAME>` flag
(exactly one).

The policy-file owner key is not rotated here. It is enrolled with `profile enroll-owner-key` (public key stored) and used by `profile sign-policy`. The rotation subcommands below mint 32-byte HMAC keys.

| Subcommand | Key kind | Effect on outstanding material |
|---|---|---|
| `profile rotate-attestation-key <NAME>` | 32-byte HMAC | All pending approvals invalidated; re-run the simulate-and-approve round trip. |
| `profile rotate-audit-key <NAME>` | 32-byte HMAC | Re-signs every existing per-file chain-root sidecar with the new key; `audit verify --profile <p>` stays green across the rotation and the old key stops verifying; the response carries `sidecars_resigned`. Takes the audit writer's exclusive lock, so it refuses while an MCP server is running. |
| `profile rotate-nonce-key <NAME>` | 32-byte HMAC | All outstanding nonces minted with the old key are invalidated. |
| `profile rotate-counterparty-key <NAME>` | 32-byte HMAC | Invalidates every cached counterparty binding; the wallet re-fetches on the next counterparty-allowlist check. |

```bash
stellar-agent profile rotate-attestation-key default
```
```json
{"ok":true,"data":{"profile":"default","rotated":true,"key_kind":"hmac_32_bytes"},"request_id":"..."}
```
