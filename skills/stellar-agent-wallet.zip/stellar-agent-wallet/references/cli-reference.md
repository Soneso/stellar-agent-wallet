# CLI reference

`stellar-agent` is a self-custodial Stellar wallet for AI agents. It builds, signs, and submits transactions on testnet under a policy engine, an operator-approval spine, and a tamper-evident hash-chained audit log. This file documents the full command surface for an agent driving the CLI. For the MCP tool surface, see `./mcp-tools.md` (ships alongside this file).

## Mainnet profile selection

A mainnet profile loads only through `--profile <name>`. `STELLAR_AGENT_PROFILE` never selects one, and a mainnet `default.toml` needs `--profile default`. Keep the filename: its identity is bound to its keyring entries.

Unset the `STELLAR_AGENT_*` variable the refusal names. On every chain that covers `STELLAR_AGENT_CHAIN_ID`, `STELLAR_AGENT_AUDIT_LOG_PATH`, every `*_KEY_ID` variable, and every other key outside the overlay classes. On mainnet it also covers `STELLAR_AGENT_RPC_URL`, `STELLAR_AGENT_SECONDARY_RPC_URL`, `STELLAR_AGENT_ORACLE_PROVIDER_URL`, `STELLAR_AGENT_MCP_SIGNER_DEFAULT`, and the other testnet-only keys. Remove refused keys from programmatic overlays too, and set needed values in the profile file. Then run `stellar-agent profile show --profile <name>` to confirm the file's chain and endpoint. Correct the profile file if either value differs from the intended configuration.

| Wire code | Meaning |
|---|---|
| `profile.non_overlayable_field` | An overlay named a key outside its class, or set `mcp_disabled` to anything but `true`, including an equal value. Overlays may set `submit_timeout_seconds` on every chain, the testnet-only endpoint, signer, fee, threshold, and scan-bound keys on testnet, and `mcp_disabled = true`; every other key comes from the file. Remove that environment value, overlay, or flag, and set the value in the profile file. |
| `profile.network_flag_mismatch` | `--network` differs from the loaded chain. Remove the flag or select a profile on that chain. |
| `auth.enrolled_signer_unpinned` | Mainnet enrollment is a placeholder or malformed. Correct a malformed `mcp_signer_default.account`, then run `stellar-agent profile enroll-signer --profile <name>`. |
| `auth.enrolled_signer_mismatch` | The derived key differs from the enrolled identity. Use the enrolled seed, Ledger account, or keyring entry. |
| `profile.mainnet_requires_explicit_profile` | A mainnet profile was selected by the environment or the default source. Supply `--profile <name>`. |

## Invocation and global model

The binary is `stellar-agent` on `PATH`. When `stellar` is installed it is also reachable as a plugin: `stellar agent <command> ...`. Examples below use the direct form.

The top-level command accepts `-h`/`--help` and `-V`/`--version`. Network, profile, RPC URLs, and signer source are declared per subcommand. Run `stellar-agent --help` for the live subcommand list and `stellar-agent <command> --help` for a group's flags.

### Output envelope and exit codes

Every command prints one JSON object on stdout. Exit code `0` means success; exit code `1` means any error. The standard envelope is:

```json
{"ok": true, "data": { ... }, "request_id": "..."}
{"ok": false, "error": {"code": "...", "message": "..."}, "request_id": "..."}
```

The `credentials` and `toolsets` groups use this same envelope; a `credentials.*` or `toolsets.*` / `toolset.*` wire code identifies the specific refusal.

### Value formats

- Amounts are decimal strings with an explicit unit, e.g. `"10 XLM"`, `"10.5 USDC"`, `"5 XLM"`. Bare numbers and raw stroop strings are rejected on user-facing amount flags. The DeFi commands `vault` and `trade` take raw integer base-unit amounts (`i128`, through `--amount`, `--shares`, and related flags) with no unit.
- Assets are `native`, `XLM`, or `CODE:ISSUER_GSTRKEY` (e.g. `USDC:GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN`). Contract addresses are C-strkeys; classic accounts are G-strkeys; secret keys are S-strkeys.
- `--fee <STROOPS|auto[:pNN]>`: an integer sets explicit stroops; `auto` selects the p95 percentile from `getFeeStats`; `auto:pNN` selects an explicit percentile (`p50`, `p75`, `p95`, `p99`). Absent uses the profile default (100 stroops). Soroban resource fees are added by simulation. (`smart-account multicall` accepts only an integer `--fee`; `auto` is rejected there.)

### Shared flags

These recur with the same meaning across groups:

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Selects the per-environment TOML profile (binds CAIP-2 chain, RPC, keyring entry references, thresholds, policy engine). Holds no secrets. | resolves `--profile` → `STELLAR_AGENT_PROFILE` → `"default"` on every command that loads a profile (`fees stats` loads only with `--profile`; `accounts deploy-c` opens its writer only with that flag) |
| `--network <NETWORK>` | Optional assertion; must match the profile chain | profile chain |
| `--rpc-url <URL>` | Testnet override; refused on mainnet; credentials refused; gets the keyring credential only when it equals the profile's `rpc_url` | profile endpoint |
| `--secondary-rpc-url <URL>` | Testnet override; refused on mainnet; credentials refused; sends no keyring credential | profile secondary |
| `--timeout-seconds <SECONDS>` | Bounds submission and simulation | `60` |
| `--output <FORMAT>` | `json` (default) or `table`; not accepted on every command | `json` |

### Signer source

Signing commands take a mutually exclusive signer-source group (exactly one):

- The secret-env flag: the **name of an environment variable** holding the source-account S-strkey. The operator sets the variable as [Pass a secret seed](https://github.com/Soneso/stellar-agent-wallet/blob/main/docs/getting-started.md#pass-a-secret-seed) shows; pass the variable name, never the secret. Spelled `--secret-env` on `pay` / `accounts create`, `--deployer-secret-env` on `accounts deploy-c` and the `smart-account deploy-*` verbs (`deploy-webauthn-verifier`, `deploy-ed25519-verifier`, `deploy-spending-limit-policy`), `--signer-secret-env` on the `smart-account` commands.
- `--sign-with-ledger`: sign with a connected Ledger hardware device.
- `--account-index <INDEX>`: BIP-44 account index for the Ledger derivation path. Default `0`.

In the operator's terminal, run this line on its own, paste the source-account seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'WALLET_SK seed: ' && read -rs WALLET_SK && echo && export WALLET_SK
```

```bash
stellar-agent pay GDEST...WXYZ "10 XLM" --source GSRC...WXYZ --secret-env WALLET_SK
unset WALLET_SK
```

### Mainnet-write refusal

This is a testnet-first alpha. `mainnet` is accepted for read-only commands but every write or signing command structurally refuses `mainnet`, surfacing `network.mainnet_write_forbidden`. The `friendbot` command and `accounts create --fund-with-friendbot` use `network.friendbot_mainnet_forbidden`, and `mpp` uses `mpp.network_forbidden`. Commands that take `--network` refuse before any RPC call and before any signing key is touched. The profile-driven `vault deposit`, `vault withdraw`, `trade`, `trustline`, and `pool init` refuse a mainnet profile before signer access and any RPC call. At the submit layer, which every write goes through including the profile-driven ones, a declared mainnet passphrase and a known mainnet RPC URL are each refused with no RPC call at all.

### Submit-layer network binding

The submit layer does not take the declared network on trust. Before sending, it asks the endpoint which network it serves and which protocol it runs, on the client that sends. That answer is authoritative. `pay`, `claim`, sponsored `accounts create`, `trustline`, and `pool init` ask the same question earlier, on that same client, before the first read whose answer they sign or gate on. That read is the fee, the sequence, the claim entry, a policy view, or the reservation reconcile. An endpoint reporting mainnet is refused with `network.mainnet_write_forbidden`. One reporting a different network than declared is refused with `network.endpoint_network_mismatch`. One whose identity cannot be established within the timeout is refused with `network.endpoint_identity_unavailable`. One that answers the identity request with HTTP 401 or 403 is refused with `network.rpc_credential_refused`. The check is retried with bounded backoff inside the caller's timeout and never falls back to the declaration. An answer that does not parse, and a 401 or 403 answer, is not retried.

An endpoint refusal precedes every refusal that follows a read: a missing account or claim entry, a policy denial, the audit pre-flight, and the amount, asset, and fee checks. `pool init` runs its audit pre-flight before the check, and the full `pay` pipeline checks `--source` and `--fee` after the reconcile. A `claim` or `trustline` refused at the early check carries no preview. Each check gets a budget of its own: `--timeout-seconds` on `pay`, `claim`, `accounts create`, and `pool init`, and the profile's `submit_timeout_seconds` on `trustline`. `--build-only` checks before its reads. `--sign-only` checks before the account reads of an envelope it decodes and signs an envelope it cannot decode without any request.

This release supports protocol version 29. On testnet and other networks, a version outside that range is logged as a warning and the submission continues. On mainnet the same version is refused with `network.unsupported_protocol_version`; while mainnet writes are refused, a mainnet endpoint is refused with `network.mainnet_write_forbidden` before this rule applies.

It then verifies every decorated signature on the envelope against the network id the endpoint reported, using the ed25519 signer sets of the transaction source and every operation source (an account absent from the ledger is `network.account_not_found`). A signature that verifies only under the mainnet network id is `network.envelope_signed_for_mainnet`, one that verifies under neither is `network.envelope_signature_unverifiable`, and an envelope with no signature, or a fee-bump whose outer or inner transaction has none, is `network.envelope_unsigned`. Every signature must pass and each signature set must have at least one, so an envelope signed for one network cannot be submitted under another network's passphrase.

---

## accounts

Account-management group. Subcommands: `create`, `deploy-c`.

### `accounts create [NEW_G_STRKEY] [flags]`

Creates a new account in one of two mutually exclusive modes: sponsored `CreateAccount`, or Friendbot funding. Sponsored mode signs with the sponsor key; Friendbot mode signs nothing. `mainnet` parses but is structurally refused (sponsored: `network.mainnet_write_forbidden`; Friendbot: `network.friendbot_mainnet_forbidden`).

Argument groups (parser-enforced): mode (exactly one) `--sponsor` xor `--fund-with-friendbot`; account (exactly one) positional `<NEW_G_STRKEY>` xor `--generate`; signer (sponsored) `--secret-env` xor `--sign-with-ledger`.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<NEW_G_STRKEY>` (positional) | G-strkey of the account to create | — |
| `--generate` | Mint a fresh ed25519 keypair in-process; returns G- and S-strkey in JSON (`data.secret_key`, never in `table`, never logged) | `false` |
| `--sponsor <G_STRKEY>` | Sponsor/source for `CreateAccount` | — |
| `--starting-balance <AMOUNT>` | Starting balance with units, e.g. `"5 XLM"` (sponsored mode) | — |
| `--secret-env <VAR>` | Env-var name holding sponsor S-strkey | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger signer / BIP index | `false` / `0` |
| `--fund-with-friendbot` | Fund via Friendbot (testnet only) | `false` |
| `--friendbot-url <URL>` | Friendbot endpoint (Friendbot mode) | `https://friendbot.stellar.org` |
| `--network` / `--fee` / `--timeout-seconds` / `--rpc-url` / `--output` | shared (sponsored mode) | as above |

The sponsor public key must match the public key derived from the signer. `--generate` prints the new account's seed in `data.secret_key`; the command output holds the seed, so do not write it to a log or a shared terminal.

In the operator's terminal, run this line on its own, paste the sponsor seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'SPONSOR_SK seed: ' && read -rs SPONSOR_SK && echo && export SPONSOR_SK
```

```bash
stellar-agent accounts create --generate --sponsor GABC...WXYZ \
  --secret-env SPONSOR_SK --starting-balance "5 XLM"
unset SPONSOR_SK
```

Sponsored creation checks its selected fee against
`classic_max_fee_per_op_stroops` before the witness. The default is the command's
100 stroops; an explicit or automatic fee keeps its own source in a cap refusal.
One sponsor observation on the primary feeds policy, the witness, and the
envelope sequence. The submission separately reads the sponsor's signer set to
verify the signature binding. The starting balance determines whether the
witness is required, with a native floor of 1000 XLM.

The result includes `cross_check` with `passed`, `skipped`, or `not_required`.
Table output prints its witness line. Friendbot results omit the field.
Pending and submitted audit rows carry a passed witness.
A sponsored confirmation timeout reports `error.details.envelope_hash` from the
signed envelope, without returning the envelope. A failure before signing has
no envelope hash.

### `accounts deploy-c [flags]`

Deploys a new OpenZeppelin smart-account (C-account) contract via `CreateContractV2`; the genesis signer is installed through the contract `__constructor`. Signs source-account credentials with the deployer key (except `--dry-run`, which derives the C-strkey deterministically with no signing or RPC). `mainnet` parses but is structurally refused for writes.

Argument groups: deployer (exactly one) `--deployer-secret-env` xor `--sign-with-ledger`; salt (at most one) `--salt-hex` xor `--salt-random` (random when neither given); genesis signer source (exactly one) `--initial-signer` xor `--signer-webauthn` xor `--signer-ed25519` xor `--signer-external` (with `--signer-key-data`). `__constructor` takes a single-element signer vec, so exactly one genesis signer is ever installed.

| Flag | Meaning | Default |
|---|---|---|
| `--initial-signer <G_STRKEY>` | Delegated (native) genesis signer | — |
| `--signer-webauthn <CRED_NAME>` | Genesis signer = an already-registered passkey, resolved from the local passkeys registry; needs a WebAuthn verifier already deployed (`deploy-webauthn-verifier`) | — |
| `--signer-ed25519 <HEX_PUBKEY_64>` (optional `--verifier <C_STRKEY>` override) | Genesis signer = raw 32-byte ed25519 pubkey, verified by the Ed25519 verifier resolved from `--verifier` when supplied, else the verifier registry | — |
| `--signer-external <C_STRKEY>` + `--signer-key-data <HEX>` | Genesis signer = verified by this verifier contract with this key data | — |
| `--accept-no-delegated-fallback` | Required with any non-`--initial-signer` genesis source: acknowledges NO G-key fallback exists at genesis (`validation.passkey_only_rule_no_delegated_fallback` otherwise) | `false` |
| `--deployer-secret-env <VAR>` | Env-var name holding deployer S-strkey | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger deployer / BIP-44 index | `false` / `0` |
| `--salt-hex <HEX64>` | 32-byte salt as 64-char lowercase hex (re-deploy a known C-strkey) | — |
| `--salt-random` | Fresh random 32-byte salt | random default |
| `--profile <NAME>` | Profile whose audit writer receives deploy entries | none |
| `--network` / `--rpc-url` / `--fee` / `--timeout-seconds` / `--output` | shared | as above |
| `--dry-run` | Derive C-strkey only; no signing, no RPC | `false` |

A non-Delegated genesis signer cannot itself authorize any further rule mutation (`smart-account rules`/`signers` authorize only via a Delegated signer); follow up with `smart-account signers add` to attach a Delegated co-signer once a policy is attached to the target rule.

In the operator's terminal, run this line on its own, paste the deployer seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'DEPLOYER_SK seed: ' && read -rs DEPLOYER_SK && echo && export DEPLOYER_SK
```

```bash
stellar-agent accounts deploy-c --initial-signer GABC...WXYZ \
  --deployer-secret-env DEPLOYER_SK --salt-random
unset DEPLOYER_SK
```

---

## pay

`pay <DESTINATION> <AMOUNT> [ASSET] [flags]` — sends a classic payment, enforcing SEP-29 memo-required before signing. By default builds, signs, and submits atomically. `mainnet` parses but is structurally refused for writes. `--use-oz-relayer` is not implemented and declines.

Staged pipeline (mutually exclusive): `--build-only` emits unsigned envelope XDR and exits; `--sign-only <XDR>` signs a prebuilt envelope and emits signed XDR; `--submit-only <XDR>` submits a pre-signed envelope.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<DESTINATION>` (positional) | Destination G-strkey | — |
| `<AMOUNT>` (positional) | Amount with units, e.g. `"10 XLM"` | — |
| `[ASSET]` (positional) | `native`, `XLM`, or `CODE:ISSUER` | `native` |
| `--source <G_STRKEY>` | Source account; required for signing | — |
| `--memo-text <STRING>` | Memo text (UTF-8, up to 28 bytes) | — |
| `--memo-id <U64>` | Memo ID (u64 decimal) | — |
| `--memo-hash <64_HEX>` / `--memo-return <64_HEX>` | Memo hash / return hash (32 bytes) | — |
| `--secret-env <VAR>` | Env-var name holding source S-strkey | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger signer / BIP index | `false` / `0` |
| `--build-only` / `--sign-only <XDR>` / `--submit-only <XDR>` | Stage selection (at most one) | — |
| `--profile <NAME>` | Profile whose policy engine, keys, and audit writer to use | `STELLAR_AGENT_PROFILE`, else `default` |
| `--fee` / `--network` / `--timeout-seconds` / `--rpc-url` / `--output` | shared | as above |

Memo flags are a mutually exclusive group (at most one).

Under `policy.engine = "v1"` `pay` evaluates operator policy before signing. The staged `--sign-only` / `--submit-only` stages gate too: they decode the supplied envelope and match rules under the `stellar_pay_commit` tool name, and deny `policy.deny.unsizable_value_effect` on an envelope the decoder cannot size unless the matched rule sets `allow_opaque_signing = true`.

`--submit-only` runs the endpoint identity check before the policy gate and before the audit-key pre-flight, on the client that later reconciles, reads the gate's account views, and sends. An `--rpc-url` pointing at a different network than `--network` is therefore refused early. The check reads the endpoint's protocol version too and applies the same protocol rule as the submit layer, under its own `--timeout-seconds` deadline; the submission then starts a fresh one. It also requires an already-signed envelope: handing it the unsigned XDR that `--build-only` emitted is refused with `network.envelope_unsigned` before anything is sent. `claim --submit-only` behaves the same way.

After the policy gate every `pay` stage checks the per-operation fee against the
profile's `classic_max_fee_per_op_stroops`: the selected fee in the full
pipeline and `--build-only`, the decoded envelope fee in `--sign-only` and
`--submit-only`. A fee above the cap exits 1 with `fees.percentile_exceeds_cap`,
and the message names the fee's source and the remedy. A mainnet profile without
the cap refuses with `validation.mainnet_fee_cap_required`.

The full pipeline, `--sign-only`, and `--submit-only` then obtain the
cross-check witness before the audit pre-flight, the signer, and the send. The
oracle re-reads the source account, the destination, the SEP-29 flag when it was
read, and the source trustline of an issued send asset, valued on the source
debit leg. A disagreement exits 1 with `simulation.divergence`, or
`network.rpc_divergence` for the SEP-29 flag; an oracle fault refuses with
`network.witness_unavailable`. Sponsored create, trustline, and sending pool
initialization also use `simulation.divergence` and `network.witness_unavailable`.
A credential refusal keeps
`network.rpc_credential_refused`. The result carries `cross_check` (`passed`,
`skipped`, or `not_required`), and `--output table` prints a `Cross-check:`
line. `--build-only` has no witness and no `cross_check`. `--sign-only` and
`--submit-only` read the destination's SEP-29 flag when the decoded transaction
carries no memo and pays a plain G account. A destination that requires a memo
refuses with `validation.memo_required` before signing or sending.

Before the transaction is sent, `pay` records it as submitted with an unknown outcome: a submission receipt, a spending-window reservation, and a `value_action_pending` audit row. A submission whose confirmation does not arrive exits 1 with `submission.tx_timeout`, keeps that record, and carries the full transaction hash in `error.details`. Resolve it with `tx status <HASH>`, never by rebuilding and re-sending: a second submission for the same source account and sequence is refused with `submission.tx_already_submitted` while the first stands. The same applies to `claim`, `accounts create`, `trustline`, `trade` and `vault`.

In the operator's terminal, run this line on its own, paste the source-account seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'WALLET_SK seed: ' && read -rs WALLET_SK && echo && export WALLET_SK
```

```bash
stellar-agent pay GDEST...WXYZ "10 XLM" --source GSRC...WXYZ \
  --secret-env WALLET_SK --memo-text "invoice-42"
unset WALLET_SK
```

---

## mpp

Testnet-only sponsored MPP charge authorization for the profile's classic
G-account signer. The wallet returns a credential; it does not send the paid
request or submit the server-sponsored transaction.

```bash
stellar-agent mpp charge authorize --profile default --input-file challenge.json
stellar-agent mpp charge authorize --profile default --input-stdin < challenge.json
stellar-agent mpp charge authorize --profile default --approval-id <approval-id>
stellar-agent mpp authorization status --profile default --authorization-id <id>
stellar-agent mpp receipt record --profile default --authorization-id <id> \
  --transport http --receipt-file receipt.txt
stellar-agent mpp settlement reconcile --profile default --authorization-id <id> \
  --reference-file transaction-hash.txt
stellar-agent mpp state prune --profile default --reason-file reason.txt
```

Each input operation requires exactly one stdin/file source; files must be
bounded regular non-symlinks. `authorize` returns `mpp.approval_required` when
operator consent is needed. Approve the returned ID through the normal approval
surface, then resume with `--approval-id`; no challenge may be supplied on
resume. Credential output is one-shot and sensitive.

Receipt observation does not prove settlement. Reconcile requires the lowercase
transaction hash and verifies the exact envelope and payer authorization through
RPC. Prune is audited, requires a bounded reason, retains indeterminate records,
and removes only terminal markers older than 30 days.

---

## balances

`balances [flags]` — reads native XLM balance and trustlines via RPC `getLedgerEntries`. Read-only; no mainnet gate. `--account` is required; omitting it exits `1` with `validation.usage_error`.

| Flag | Meaning | Default |
|---|---|---|
| `--account <G_STRKEY>` (required) | Account to query | — |
| `--asset <CODE:ISSUER>` | Trustline asset; repeatable (untrusted assets omitted) | none |
| `--rpc-url` / `--output` | shared | as above |

```bash
stellar-agent balances --account GABC...WXYZ \
  --asset USDC:GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN
```

---

## trustline

`trustline [flags]` — creates or removes a classic trustline (`ChangeTrust`) behind an ordered trust gate (operator policy, denomination resolution with USDT hard-refusal plus a known-lookalike denylist and pinned-issuer checks, live issuer-flag fetch that fail-closes, clawback gate, typed preview). Builds, signs, submits, waits atomically — no staged pipeline. Network derives from the profile; there is no `--network` flag. USDT cannot be trusted.

After the preview gate proceeds, the command resolves and caps the fee, then
obtains an unvalued witness of the source and issuer flags before loading the
signer. Its default fee comes from `classic_fee_per_op_stroops`, or 100 when
unset. Cap refusals identify that profile default.
Only an absent issuer produces `trustline.gate_refused`; other issuer read
errors retain their own codes and scrubbed messages.
The JSON result includes `cross_check`; pending and submitted rows carry a
passed witness.
Fee-cap and witness refusals carry `error.details.preview` after preview approval.

| Flag | Meaning | Default |
|---|---|---|
| `--from <G_STRKEY>` (required) | Account that will hold the trustline | — |
| `--asset <ASSET>` (required) | `USDC` (bare, pin table), `CODE:ISSUER`, or a `C...` SAC address (deferred, typed error) | — |
| `--limit-stroops <I64>` | Explicit limit; `0` removes the trustline | unlimited (`i64::MAX`) |
| `--profile <NAME>` | Profile to load | `STELLAR_AGENT_PROFILE`, else `default` |
| `--fee` | shared | profile `classic_fee_per_op_stroops` |

One JSON envelope: once the clawback gate passes, the typed preview is in `data.preview` on success and in `error.details.preview` when a later step (fee, envelope build, signing, submission) fails.

The submission runs under the profile's `submit_timeout_seconds`, 60 seconds when the field is unset; there is no `--timeout-seconds` flag.

```bash
stellar-agent trustline --from GABC...WXYZ --asset USDC --profile default
```

---

## claim

`claim <BALANCE_ID> [flags]` — claims a Stellar `ClaimClaimableBalance` operation for a balance the agent already holds the id of. Enforces the claim guards (claimant membership, predicate satisfaction, non-native trustline state, native-XLM fee affordability) before signing. `mainnet` parses but is structurally refused for writes. Same three-stage pipeline as `pay`: `--build-only` emits unsigned envelope XDR and exits; `--sign-only <XDR>` signs a prebuilt envelope; `--submit-only <XDR>` submits a pre-signed envelope; the default runs all three atomically.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<BALANCE_ID>` (positional) | A `B...` strkey, canonical 72-hex id, or bare 64-hex hash | — |
| `--source <G_STRKEY>` (required) | Claiming account; also the transaction source | — |
| `--fee <STROOPS\|auto[:pNN]>` | Classic fee selector | profile default |
| `--secret-env <VAR>` | Env-var name holding source S-strkey | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger signer / BIP index | `false` / `0` |
| `--build-only` / `--sign-only <XDR>` / `--submit-only <XDR>` | Stage selection (at most one) | — |
| `--profile <NAME>` | Profile whose policy engine, keys, and audit writer to use | `STELLAR_AGENT_PROFILE`, else `default` |
| `--network <NETWORK>` | Optional assertion; must match the profile chain (a mainnet profile is structurally refused for writes) | profile chain |
| `--timeout-seconds` / `--rpc-url` / `--output` | shared | as above |

Under `policy.engine = "v1"` `claim` evaluates operator policy before signing. The staged `--sign-only` / `--submit-only` stages gate too: they decode the supplied envelope and match rules under the `stellar_claim_commit` tool name, and deny `policy.deny.unsizable_value_effect` on an envelope the decoder cannot size unless the matched rule sets `allow_opaque_signing = true`.

`claim` applies the same fee cap as `pay` in every stage. The full pipeline,
`--sign-only`, and `--submit-only` obtain an unvalued cross-check witness before
the audit pre-flight, the signer, and the send. The full pipeline compares the
source account, the complete claimable-balance record, and the trustline of an
issued asset. The staged stages compare the source account. The refusal codes
and the `cross_check` field are those of `pay`.

The build stage computes a typed preview (balance id, asset, amount, claimants, `is_claimant`, predicate verdict) before the guards run. The command prints one JSON envelope: the preview is in `data.preview` on success and in `error.details.preview` when a guard or any later step refuses, so the operator sees the balance disclosure either way. `--sign-only` and `--submit-only` build no preview.

In the operator's terminal, run this line on its own, paste the claiming account's seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'WALLET_SK seed: ' && read -rs WALLET_SK && echo && export WALLET_SK
```

```bash
stellar-agent claim BAAD...WXYZ --source GSRC...WXYZ --secret-env WALLET_SK
unset WALLET_SK
```

---

## friendbot

`friendbot [flags]`: funds a testnet or futurenet account via the Friendbot HTTP endpoint. No local signing. `--network` accepts `testnet`/`futurenet`/`mainnet` at the parser but `mainnet` is refused at dispatch (`network.friendbot_mainnet_forbidden`). The endpoint is allow-list validated (`friendbot.stellar.org`, `friendbot-futurenet.stellar.org`) unless `--friendbot-url-unchecked`. An account at or above the Friendbot starting balance (10,000 XLM on the SDF testnet) exits `1` with `network.friendbot_account_already_funded` and is usable as it is. An existing account below it receives the starting balance.

| Flag | Meaning | Default |
|---|---|---|
| `--account <G_STRKEY>` (required) | Account to fund | — |
| `--network <NETWORK>` | `testnet`, `futurenet`, or `mainnet` (mainnet refused at dispatch); reads no profile | `testnet` |
| `--friendbot-url <URL>` | Endpoint override; otherwise resolves to the SDF testnet URL regardless of `--network`, so `futurenet` needs an explicit override | `https://friendbot.stellar.org` |
| `--friendbot-url-unchecked` | Bypass URL allow-list (dev/test escape hatch) | `false` |
| `--output` | shared | `json` |

```bash
stellar-agent friendbot --account GABC...WXYZ --network testnet
```

---

## fees

Fee-statistics group. Subcommand: `stats`.

### `fees stats [flags]`

Fetches RPC fee statistics for classic fee selection. Read-only; no mainnet gate. With `--profile`, the profile loads first and mainnet refuses `--rpc-url`. Without it, use `--rpc-url`, else the testnet endpoint.

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Profile whose RPC URL to use | none |
| `--rpc-url <URL>` | Allowlisted testnet override; refused with a mainnet profile | profile endpoint, or testnet without `--profile` |
| `--output` | shared | `json` |

```bash
stellar-agent fees stats --output table
```

---

## counterparty

Manages the per-profile cache of `stellar.toml` bindings backing the counterparty allowlist policy. None of these sign a transaction; entries are HMAC-protected and skipped on read if verification fails. Subcommands: `list`, `refresh`, `evict`, `warm-up`, `rotate-hmac-key`.

| Subcommand | Form | Notes |
|---|---|---|
| `list` | `counterparty list [--profile NAME] [--json]` | Lists only live cached bindings (home domain, fetched/expiry timestamps). `--json` is a no-op; JSON is the only shape. Read-only. |
| `refresh` | `counterparty refresh <HOME_DOMAIN> [--profile NAME]` | Force-fetches `https://<domain>/.well-known/stellar.toml`, HMAC-protects, writes atomically. Domain must be strict ASCII, 1–32 chars (IDN/homoglyph rejected). |
| `evict` | `counterparty evict <HOME_DOMAIN> [--profile NAME]` | Deletes one cached binding; exits `0` even if already absent. |
| `warm-up` | `counterparty warm-up [--profile NAME]` | Refreshes domain candidates from allowlist criteria containing `HOME_DOMAIN`. Skips strkeys and `CODE:ISSUER` values; exits `1` if any remaining candidate fails. |
| `rotate-hmac-key` | `counterparty rotate-hmac-key [--profile NAME]` | Rotates the per-profile cache HMAC key; existing files then fail verification and need refresh. |

A `HOME_DOMAIN` binding is evidence for one hour from its fetch. An entry
whose fetch time lies more than five minutes in the future counts as expired.
Expired entries satisfy neither the `HOME_DOMAIN` kind of
`counterparty_allowlist` nor `home_domain_resolved`. A policy that relies on
the `HOME_DOMAIN` kind needs `counterparty warm-up` on a schedule shorter than
one hour. Warm-up refreshes only the domains named in `counterparty_allowlist`
criteria that contain `HOME_DOMAIN`. A policy that uses `home_domain_resolved`
keeps each domain it relies on live with a scheduled
`stellar-agent counterparty refresh <domain>` per domain.

`--profile` resolves `--profile` → `STELLAR_AGENT_PROFILE` → `default` for this group.

```bash
stellar-agent counterparty refresh circle.com --profile default
```

---

## smart-account

Invoke as `stellar-agent smart-account <verb>` or via the shorter `sa` alias. Administration of an on-chain OpenZeppelin smart-account: context rules, signer sets and thresholds, policy contracts, supporting infrastructure (verifier registry, multicall router registry, upgrade timelock), and multicall submission. All write verbs sign through the smart-account auth-entry digest path and take a signer source (exactly one of `--signer-secret-env <VAR>` or `--sign-with-ledger`, plus `--account-index <INDEX>`, default `0`). Most on-chain signing verbs structurally refuse `mainnet`. The `smart-account signers` verbs do not accept `--output`; the other verbs take the shared `--output` (`json` default, `table` where offered).

Every verb's exact flags, the mainnet-refusal matrix, signer-kind discriminators, WASM-hash pinning and override flags, and worked examples live in [`smart-accounts.md`](smart-accounts.md). Per-verb index:

| Verb | Purpose |
|---|---|
| `rules create` | Install a context rule; returns the minted `rule_id`. At least one signer required; `--signer-delegated` takes a G-strkey or a C-strkey. The confirmed rule is recorded as its signer-set baseline, or the command exits `sa.install_state_mismatch` / `sa.baseline_write_failed` with the rule on chain |
| `rules get` | Read one rule (read-only, mainnet OK) |
| `rules set-name` | Rename a rule |
| `rules set-valid-until` | Change a rule's expiry ledger |
| `rules delete` | Remove a rule |
| `rules verify-pins` | Verify pinned verifier/policy WASM hashes vs on-chain (drift; read-only, exit `1` on drift); names pinned and observed external-reference executables |
| `rules add-policy` | Attach a policy (`--kind raw`/`spending-limit`/`simple-threshold`/`weighted-threshold`); cap 5. Needs a matching version-2 baseline of the rule for any policy, compared under the rule's lock. On a pinned rule the new policy is probed and pinned (`--accept-mutable-verifier` / `--accept-unknown-verifier`). The simple-threshold policy records `SaThresholdChangedV2` |
| `rules remove-policy` | Detach a policy by id; needs a matching version-2 baseline of the rule for any policy, compared under the rule's lock; on a pinned rule its pin is dropped. The simple-threshold policy records its cleared threshold; removing one of two simple-threshold policies repairs the rule, and removing a third policy from such a rule refuses with `sa.threshold_policy_identification_failed` |
| `rules list` / `list-rules` | Enumerate active rules by on-chain scan (read-only, mainnet OK); each rule's `baseline` (`none`, `v1`, `v2`, `unreadable`, `unknown`) is its signer-set baseline in the audit log, and a rule reporting `none` refuses signing until `signers list --rule-id N` |
| `rules get-spending-limit` | Read an installed spending-limit policy's rolling-window budget (read-only; amounts are decimal strings) |
| `rules set-spending-limit` | Retune a spending-limit cap without resetting history. `--auth-rule-id` default 0: the retuned CallContract rule cannot authorize its own retune: name an admin-capable rule. Period is immutable |
| `signers list` | Read the on-chain signer set; baselines if none, otherwise reports `baseline` (`matched`, `diverged`, `not_comparable`) |
| `signers refresh` | Compare with the signer-set baseline and re-anchor it; run it once on a rule reporting `v1` (`sa.signer_set_baseline_legacy`); a changed set needs `--accept-divergence`. Pins a live verifier when the record pins none (`sa.pinned_verifier_absent`). Probes as `rules create` does (`--accept-mutable-verifier` / `--accept-unknown-verifier`). With no `External` signer, drops the sole verifier pin. Reports `verifier_pinned` |
| `signers add` | Add one signer (cap 15). `--signer-ed25519` is the recommended agent-key shape. On a pinned rule, writes `SaContextRulePinsUpdated` for an External signer, one pin per distinct hash and executable reference; `--accept-mutable-verifier` / `--accept-unknown-verifier` apply to a new verifier. A simulated return value that is not the new signer id refuses before signing (`sa.deployment_failed`). Completes a `migrate-verifier` pair from its `pending_add.recovery_command` |
| `signers remove` | Remove a signer; refuses if it would drop below threshold, and on a rule whose policies include no simple-threshold policy (`sa.threshold_policy_identification_failed`) |
| `signers set-threshold` | Change a simple-threshold policy's threshold (authorizer is `--rule-id`) |
| `signers set-weighted-threshold` | Change a weighted-threshold policy's threshold (use an admin `--auth-rule-id` when `--rule-id` is scoped) |
| `signers set-signer-weight` | Change one signer's weight in a weighted-threshold policy |
| `signers batch-add` | Add multiple signers in one transaction (cap 15). A rule without a simple-threshold policy accepts a batch. Pin-record update and override flags as `signers add` |
| `execute` | Submit one `CallContract` invocation authorized by a rule and signed by an External-Ed25519 rule signer (the delegation verb); `--auth-rule-id` has NO default; no MCP equivalent. Refuses before signing with `sa.signer_set_missing_baseline` when a rule has no signer-set baseline, and `sa.audit_log` on an audit-log integrity error. It refuses with `sa.verifier_hash_drift` / `sa.policy_hash_drift` when a rule's verifier or policy differs from its pin, and `sa.pin_check_unavailable` when the drift check cannot run. `sa.pinned_policy_absent` refuses a rule whose record holds policy pins while the rule has no policy on chain. `sa.pinned_verifier_absent` refuses a rule holding an `External` signer while its record pins no verifier. `sa.signer_set_diverged` refuses a rule whose signers differ from its baseline |
| `multicall` | Submit an atomic bundle of 1 to 50 invocations through the registered router; requires `--secondary-rpc-url` (flag or profile, else a typed error). Requires `policy.engine = "v1"`: the bundle is evaluated as `wallet_multicall` against the profile's signed policy, a Noop profile refuses with `policy.engine_required`, and a policy that cannot load refuses with `policy.engine_unavailable`. A policy refusal or a refused pre-submission check of a `--rule-id` other than `0` is `sa.multicall_failed` at phase `policy_gate` |
| `deploy-webauthn-verifier` | Deploy the OZ WebAuthn-verifier WASM; idempotent; testnet only |
| `deploy-ed25519-verifier` | Deploy the OZ Ed25519-verifier WASM (backs `--signer-ed25519`); testnet only |
| `deploy-spending-limit-policy` | Deploy the OZ spending-limit-policy WASM (per-network singleton); testnet only |
| `deploy-policy` | Deploy any of the three OZ policy contracts via one `--kind`; recommended; testnet only |
| `migrate-verifier` | Move all External signers from one verifier to another across rules; mainnet submit refused, mainnet dry-run allowed. Each remove/add pair runs under the rule's lock against its version-2 state and records `SaSignerRemovedV2`, `SaContextRulePinsUpdated` (pinned rule, names the destination), `SaSignerAddedV2`, `SaVerifierMigrated`; checks each migrating rule's policies before signing. A failure after a removal was sent returns `pending_add` and prints the `signers add` (or refresh then add) that completes the pair |
| `list-verifiers` | Enumerate the compile-time verifier allowlist and audit-status taxonomy (read-only, no network) |
| `register-multicall` / `unregister-multicall` | Edit the local multicall-router registry |
| `timelock schedule` / `cancel` / `execute` / `list-pending` | OpenZeppelin upgrade-timelock lifecycle; write verbs refuse `mainnet`, `list-pending` is read-only |

Flags for every verb: see [`smart-accounts.md`](smart-accounts.md).

---

## DeFi: vault, trade

`vault deposit`, `vault withdraw`, and `trade` are signing commands. Before signing, each loads the profile and refuses a mainnet profile with `network.mainnet_write_forbidden` before signer access and any RPC call. It then pins the target contract by WASM hash (two-RPC cross-check when `--secondary-rpc-url` is set), evaluates the operator policy engine, and signs and submits. A `Deny` refuses `policy.deny.<code>`; a `RequireApproval` refuses `policy.approval_required` (use the MCP server for two-phase approval; the CLI has no interactive approval path for these verbs); an unbuildable engine refuses `policy.engine_unavailable` (fail closed). These commands do not accept `--output`; they always emit JSON. Per-network contract pins constrain them as well. DeFi amounts are raw integer base units (no decimal/unit string).

Every venue's flags, trust gate, refusal codes, and examples live in [`defi.md`](defi.md). Per-verb index:

| Verb | Venue | Purpose |
|---|---|---|
| `vault deposit` | DeFindex | Deposit into a DeFindex vault; `--amounts-min` required; upgradable-vault refusal |
| `vault withdraw` | DeFindex | Redeem shares from a DeFindex vault; `--min-amounts-out` required |
| `trade` | Soroswap | Swap via the Soroswap router; price discovery is inside `trade` (no separate `quote`) |

Flags for every verb: see [`defi.md`](defi.md).

---

## pool

The channel pool is a set of channel accounts derived from a single pool master seed at `m/44'/148'/<index>'`, used to submit transactions concurrently (not a DeFi venue). The master seed lives only in the OS keyring; channel private keys are re-derived on demand. Subcommands: `init`, `list`, `status`. All accept `--profile` (resolves `--profile` → `STELLAR_AGENT_PROFILE` → `default`) and `--output` (`json` default or `table`).

| Verb | Purpose | Extra flags |
|---|---|---|
| `init` | Fund `N` channels via one CAP-33 sponsored-reserve sandwich; signing. Master seed written to keyring only after confirmation. Refuses if a master exists (message `pool.already_initialised:`, fail-closed on ambiguous probe) unless `--force` (which orphans prior channels). | `--size <N>` (required, `1..=19`); `--force` |
| `list` | List channels (BIP-44 index, public G-strkey, live sequence). Read-only; requires an initialised pool (else `internal.unexpected_state` with `pool.not_initialised:`). | — |
| `status` | Report `initialised`, `pool_size`, `free`, `in_flight`. Read-only, no network (reads persisted `PoolConfig`). `in_flight:0` is not "safe to flood" — it reflects a stateless process. | — |

Pool refusals surface as `error.code` `internal.unexpected_state` with the specific reason (e.g. `pool.size_out_of_range:`, `pool.already_initialised:`) in `error.message`.

```bash
stellar-agent pool init --size 5 --profile default
```

---

## profile

Creates, lists, shows, and migrates profiles, and rotates the keyring-backed keys a profile names. A profile is a per-environment TOML config (schema version 2) holding no secrets. Every subcommand except `list` accepts a `--profile <NAME>` flag: `init`, `enroll-signer`, `enroll-owner-key`, `enroll-rpc-credential`, and `sign-policy` take only that flag (resolves `--profile` → `STELLAR_AGENT_PROFILE` → `default`), while `show`, `migrate`, the `rotate-*` subcommands, and `reset-window-state` accept it as an exactly-one-of alternative to their positional `<NAME>` (supply one; both or neither is a usage error), with no default. `reset-mpp-state` requires `--acknowledge`; no other subcommand has a confirmation flag. All operate on local state, with no network and no mainnet gate (`init`'s `--network mainnet` guard is a configuration-time refusal, not the mainnet-write gate). Uses the `{ok, data, request_id}` envelope.

| Verb | Form | Notes |
|---|---|---|
| `init` | `profile init --profile default --network testnet` | Writes a profile; see below. |
| `list` | `profile list` | Read-only. Returns known profile names sorted as a JSON array. Takes no profile selector. |
| `show <NAME>` | `profile show default` | Read-only. URL fields (`rpc_url`, `secondary_rpc_url`, `oracle_provider_url`) show scheme, host, and port only. Resolved config; keyring refs appear as opaque `{service, account}`, secrets never read. Exits `1` with `validation.profile_not_found` when the profile does not exist. A mainnet file without `rpc_url` exits with `validation.mainnet_rpc_url_required`. An invalid provider attestation exits with `validation.provider_attestation_invalid`; correct the named field in the profile file. An endpoint URL that breaks the endpoint rule, an unsupported schema version, or another unreadable file exits with `validation.config_invalid`. |
| `migrate <NAME>` | `profile migrate default` | State-changing (atomic temp+rename). No-op if already current (`status:"no_op"`); else `status:"migrated"` with `from_version`/`to_version`/`path`. A refused migration exits `1`, writes nothing, and leaves the v1 file unchanged. A missing profile file: `validation.profile_not_found`. A v1 mainnet file without `rpc_url`: `validation.mainnet_rpc_url_required`, because mainnet has no default endpoint; add `rpc_url` to the v1 file and run the command again. An endpoint URL that breaks the endpoint rule, or a file that cannot be read: `validation.config_invalid`. |
| `enroll-signer` | `profile enroll-signer --profile default --secret-env WALLET_SK` | State-changing (keyring, and the profile TOML when the account is still a placeholder). Imports the operator's `S...` ed25519 seed from the named env var and stores it verbatim at the profile's `mcp_signer_default` coordinate (the signer every MCP fund-movement tool and keyring-signing CLI verb resolves). Classification uses the raw on-disk value: the literal placeholder `"default"` is pinned to the derived G-strkey (only that key is patched); a pinned G-strkey mismatch refuses; any other value refuses as malformed (`enroll_signer.account_malformed`). `--secret-env <VAR>` (required, the variable name), `--profile <NAME>` (resolves `--profile` → `STELLAR_AGENT_PROFILE` → `default`), `--expected-address <G_STRKEY>`, `--force`. |
| `enroll-rpc-credential` | `profile enroll-rpc-credential --profile default --role primary --header X-API-Key` | State-changing (keyring, and the profile TOML when the record names no reference). Stores an RPC provider key at the keyring entry the role's provider record names, or at the default `stellar-agent-rpc-<profile>` / `<role>`, and adds `credential` and `placement` to a record without them. Reads the key from a hidden prompt, or from standard input with `--stdin`; the key is never printed. The role's URL and record must exist; the loader's credential checks run on the record before anything is written. `--role <primary\|secondary\|oracle>` (required), `--header <NAME>` \| `--query <NAME>` \| `--path` (required when the record names no placement), `--stdin`, `--force`. Refusals: `enroll_rpc_credential.record_missing`, `.placement_required`, `.placement_mismatch`, `.entry_exists`, `.terminal_required`, `.input_unreadable`, `validation.provider_attestation_invalid`, `network.rpc_credential_refused`. See [Provider credentials](profiles-and-keys.md#provider-credentials). |
| `enroll-owner-key` | `profile enroll-owner-key --profile default --secret-env WALLET_OWNER_SK` | State-changing (keyring). Derives the owner ed25519 PUBLIC key from an operator `S...` seed and stores it at `policy_owner_key_id` (the key the V1 engine verifies against) as its G-strkey, a form no 32-byte symmetric-key loader accepts. Also rewrites every other profile's older-form (base64) owner entry. The seed is never stored. `--expected-address`, `--force`. |
| `sign-policy` | `profile sign-policy --profile default --secret-env WALLET_OWNER_SK` | State-changing (writes the policy file, atomic). Signs `<state_dir>/policies/<profile>.toml` (or `--file`) with the owner seed and writes the `[signature]` table. Refuses if the seed does not match the enrolled owner key. |

`profile init` writes a new profile TOML with per-profile keyring references.
The signer and nonce accounts start as `"default"` placeholders. It reports
enrollment next steps, mints no key material, and emits no audit row.

`--profile <NAME>` resolves through `STELLAR_AGENT_PROFILE`, then `default`.
`--network <testnet|mainnet>` defaults to `testnet`. `--rpc-url <URL>` is optional
on testnet and required on mainnet, which has no default endpoint.
`--engine <v1|noop>` defaults to `v1`. Mainnet profiles receive
`classic_max_fee_per_op_stroops = 10000`.

On V1, the MCP server starts once the owner key is enrolled and the
owner-signed policy loads. The rest of the
[V1 setup](profiles-and-keys.md#opt-in-to-v1) gates approvals and signing.
A testnet `noop` profile supports server startup and read access immediately.
Mint the audit key with `profile rotate-audit-key` before
`profile enroll-signer` so enrollment writes its audit row. Then run
`profile rotate-nonce-key` before MCP payment simulation.

The flag parser refuses a malformed or credential-bearing `--rpc-url` with
exit `1` and `validation.usage_error`. Later refusals also exit `1` and write
nothing. In order, these are an unsafe profile name
(`validation.config_invalid`), a missing mainnet endpoint
(`validation.mainnet_rpc_url_required`), and an existing profile
(`validation.profile_already_exists`). An endpoint that breaks the URL rule
then refuses with `validation.config_invalid`. The rule requires `http` or
`https`, and on mainnet `https` with no username or password. A failed write
exits `1` with an internal error.

`enroll-signer` reads the signer seed, and `enroll-owner-key` and `sign-policy` read the owner seed, from the environment of the shell that runs them. The operator supplies each seed as [Pass a secret seed](https://github.com/Soneso/stellar-agent-wallet/blob/main/docs/getting-started.md#pass-a-secret-seed) shows, only for those commands, and unsets it afterward. Of the policy owner key, the MCP server holds only the enrolled public key. It reads no seed from its environment.

### Key-rotation subcommands

Each generates a fresh 32-byte CSPRNG secret, atomically replaces one named keyring entry, and is not reversible. Each takes the profile as either a positional `<NAME>` or a `--profile <NAME>` flag (exactly one) and returns `profile` + `rotated`; some add `key_kind`.

The policy-file owner key is NOT rotated here — it is an ed25519 key enrolled with `enroll-owner-key` (public key stored) and used by `sign-policy` (seed supplied at sign time). All rotation subcommands below mint 32-byte HMAC keys.

| Subcommand | Keyring entry | Effect |
|---|---|---|
| `rotate-attestation-key` | approval-spine attestation HMAC (`attestation_key_id`) | Invalidates all pending approvals; the simulate-and-approve round trip must be re-run. `key_kind:"hmac_32_bytes"`. |
| `rotate-audit-key` | audit-log chain-root HMAC (`audit_log_hash_chain_key_id`) | Re-signs every existing per-file chain-root sidecar with the new key, so `audit verify --profile <NAME>` stays green and the old key stops verifying. Adds `key_kind:"hmac_32_bytes"` and `sidecars_resigned`. Takes the audit writer's exclusive lock, so it refuses while an MCP server holds the writer. A changed audit binding refuses with `audit.log_binding_changed` before the writer opens. |
| `rotate-nonce-key` | HMAC nonce key (`mcp_nonce_key_alias`) | Invalidates outstanding nonces. Returns only `profile` + `rotated`. |
| `rotate-counterparty-key` | `stellar.toml` cache-integrity HMAC (`counterparty_cache_key_id`) | Invalidates cached bindings. `counterparty refresh <domain>` rewrites one binding, and `counterparty warm-up` refreshes only the `HOME_DOMAIN` entries of the policy allowlist. Adds `key_kind:"hmac_32_bytes"` and `cache_invalidated:true`. |
| `rotate-policy-state-key` | policy-window-state HMAC (`policy_window_state_key_id`) | Re-signs the persisted window-state store under the new key, so accumulated `per_period_cap` / `rate_limit` history is preserved, not invalidated. Refused if the store does not verify under the current key (use `reset-window-state` instead). Adds `key_kind:"hmac_32_bytes"` and `sidecars_resigned`. |

```bash
stellar-agent profile rotate-attestation-key default
```

`profile reset-window-state` clears persisted policy-window history after
recovery from corruption or rollback. Stop the MCP server and repair the audit
log first. The command requires a usable keyed audit writer on every network,
including testnet. It acquires that writer before the window-store lock and
writes the reset row before minting a key, advancing the generation or replacing
the store. A reset whose row cannot be written does not happen.

The `policy_window_state_reset` row carries the profile's chain, reason and
`wiped` record. The JSON result carries the same record. A verified store reports
live confirmed and pending counts and totals, scope specificity, bucket and
window, plus generations before and after. Pending records count regardless of
age. At most eight buckets appear, with bounded identifiers and a truncation flag;
the entry count covers all live records. Missing or unverifiable stores report
no totals. A store is unverifiable when its file fails its HMAC, does not parse,
uses an unsupported format version, or holds an authentic older generation.
It is also unverifiable without a usable key: an absent key, a key that is not
valid base64, or a key that is not 32 bytes. The reset replaces such a key after
the row. A store file that exists but cannot be read refuses before the row.

A running MCP server holds the audit writer. Reset then refuses with
`audit.chain_key_unavailable` and the message sub-code `audit.writer_locked`.
An append failure also refuses with its audit code, leaving the window file,
key and generation untouched. A first-use key mint is recorded through the held
writer after the reset row, including when the later store write fails.

A failure after the row but before the generation write leaves the store
unchanged; the row's `generation_after` exceeds the keyring generation.
After the generation write but before the file write, the generation matches
the row while the old body remains. Its next load refuses a generation mismatch.
Rerun reset after repairing the audit log and stopping the MCP server.
The reset is complete when the next command that opens the window store loads
the empty store at `generation_after`. On a V1 profile, a value-moving command
and the MCP server's start open it. Generation equality alone does not establish
completion.
A blank `--reason` refuses with `validation.reason_empty` before anything changes.

A reset row without `wiped` retains its serialized form and verifies unchanged.
A row with `wiped` verifies with this release or later. An older binary drops
that field when computing the row hash. It refuses a log once a checked root
HMAC, successor row or tip anchor covers the new row. An uncovered tail can
still be read by that binary with `wiped` dropped. If it then appends a row,
this release refuses the extended log at that row.

The counterparty cache reads and mints its HMAC key at
`counterparty_cache_key_id`, the entry `profile rotate-counterparty-key` writes.
With an explicit reference, previously cached entries read as absent until
a refresh rewrites them. `counterparty refresh <domain>` rewrites the entry
for that domain. `counterparty warm-up` refreshes only the `HOME_DOMAIN`
entries of the policy allowlist.

---

## credentials

WebAuthn passkey lifecycle for a profile. The registry holds only public metadata (credential name, redacted credential ID, RP-ID, transports, registration timestamp); the private key never leaves the authenticator. `credential_id` is redacted to first-five-last-five base64url. Uses the standard `{ok, data|error, request_id}` envelope; failures carry a `credentials.*` wire code.

Two common flags: `--profile <NAME>` (resolves `--profile` → `STELLAR_AGENT_PROFILE` → `"default"`), `--rp-id <DOMAIN>` (default `localhost`; set the deployment domain for a self-hosted deployment; IP literals rejected; changing it after registration breaks existing passkeys).

Closed set of `error.code` values across the group: the verb-specific codes in the table below, plus `credentials.invalid_profile_name` (any subcommand, malformed `--profile`), plus these codes shared from the underlying `CredentialsError`: `credentials.not_found`, `.duplicate_name`, `.invalid_name`, `.io_error`, `.registry_parse_failed`, `.registry_serialise_failed`, `.state_dir_unavailable`, `.approval_store_error`, `.approval_store_unavailable`, `.bridge_start_failed`, `.bridge_shutdown_failed`, `.atomic_write_failed`, `.signing_failed`, `.missing_public_key`, `.malformed_public_key`, and a generic `.error` fallback. `add-passkey` additionally emits `.approval_store_dir_unavailable`, `.approval_store_open_failed`, and `.unknown_registration_outcome`. Switch on `error.code`, never on `error.message`.

| Verb | Form | Notes |
|---|---|---|
| `add-passkey <NAME>` | `credentials add-passkey laptop-key --rp-id wallet.example.com` | State-changing; opens the browser to the bridge registration URL and polls. `<NAME>`: 1–64 printable ASCII, no `/ \ :`. Extra flags: `--timeout-seconds` (default `300`), `--accept-rp-id-binding-risk`. First registration prompts `[y/N]` with an RP-ID binding warning unless the flag is set. On success `data` carries the registered credential's metadata; timeout, user cancellation, a missing approval-store entry, or a declined binding warning surface as `ok:false` with `credentials.registration_timeout` / `credentials.registration_user_canceled` / `credentials.registration_entry_missing` / `credentials.rp_id_binding_warning_declined`. |
| `list` | `credentials list` | Read-only. Lists registered passkeys for the profile+RP-ID under `data.credentials`. |
| `show <NAME>` | `credentials show laptop-key` | Read-only. Metadata incl. transports. Exits `1` with `credentials.not_found` when not found. |
| `delete <NAME>` | `credentials delete laptop-key --yes` | State-changing; prompts `[y/N]` (skip with `--yes`/`-y`). Does not remove the on-chain signer. Declining exits `1` with `credentials.delete_canceled`. |

---

## approve

The operator-side half of the approval spine. When a signing-adjacent action needs out-of-band approval, the agent surface records a pending approval and returns an approval nonce. The wallet owner runs `approve --id <NONCE> --profile <name>` in a separate trusted context to inspect a wallet-controlled summary and consent. The summary is rendered from stored fields, not from anything the agent supplied. Approval is bound to the local user (recorded process uid must match at approve time). Uses the `{ok, data, request_id}` envelope.

### `approve --id <NONCE> --profile <name>`

State-changing (records an HMAC attestation, or for a toolset first-invoke gate mints a toolset grant and consumes the entry).

| Flag | Meaning |
|---|---|
| `--id <NONCE>` (required in this form) | Approval nonce from the agent surface's simulate response |
| `--profile <NAME>` | Profile whose attestation key + pending-approval store to use (resolves `--profile` → env → `default`) |
| `--yes` | Non-interactive auto-approve; the summary is still printed |

Interactively prompts `Approve? [y/N]:`; anything other than `y`/`yes` denies. Exits `1` when the nonce is unknown, expired, already attested, created by a different local user, denied, or on I/O error. For payment-style approvals the response returns `approval_attestation` (the HMAC blob the agent must pass as the `approval_attestation` argument to the matching `*_commit` tool); omitted for kinds whose gate reads recorded consent directly (toolset first-invoke grants, trustline clawback opt-ins).

The `approval_attested` row is written before the approval is persisted. `audit` is `"written"`, or `"queued"` when a running MCP server or `approve serve` inbox holds the audit writer. That process appends the queued row to the log before any process loads a signing key for the approved action. The command exits `1` and persists nothing beside a process that does not drain the outbox (`audit.writer_locked`) and on any other audit failure. After upgrading, restart a running MCP server and `approve serve`: `approve --id` refuses beside an older one.

```bash
stellar-agent approve --id ABCxyzNonce --profile <name>
```

```json
{"ok":true,"data":{"approval_nonce":"ABCxyzNonce","attested":true,"process_uid":"501","expires_at_unix_ms":1717000000000,"approval_attestation":"q83vEjRWeJq83v...","audit":"written"},"request_id":"..."}
```

### `approve gc`

State-changing. Evicts every expired entry from the pending-approval store and reports the count (`evicted_count`). When `gc` is present, `--id` is ignored. Evicting zero is a success. `--profile <NAME>` selects the store.

```bash
stellar-agent approve gc --profile default
```

### `approve list`

Read-only. Enumerates pending approvals from the profile's store: opens it, renders a redacted snapshot, and exits. No keyring access, no network calls.

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Profile whose store to read | `STELLAR_AGENT_PROFILE`, else `default` |
| `--output <FORMAT>` | `json` (default) or `table` | `json` |
| `--include-expired` | Include already-expired entries instead of omitting them | `false` |

`data.expired_count` always reports the number of expired entries regardless of `--include-expired`, so the operator can tell whether `approve gc` is due even when expired entries are hidden.

```bash
stellar-agent approve list --profile default --output table
```

### `approve serve`

Binds a loopback-only HTTP server with a local web UI for the pending-approval queue. The operator can review and approve or reject entries in a browser. Runs until Ctrl-C.

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Profile whose store and attestation key to use | `STELLAR_AGENT_PROFILE`, else `default` |
| `--port <PORT>` | TCP port to bind on `127.0.0.1`; `0` picks an OS-assigned port | `0` |
| `--no-open` | Print the bootstrap URL instead of opening a browser | `false` |
| `--notify <on\|off>` | Best-effort OS toast notification when the queue grows | `on` |
| `--bell` | Emit a terminal bell alongside each queue-growth notice | `false` |
| `--include-expired` | Load the inbox with expired entries shown by default | `false` |

On start the server mints a single-use bootstrap token and prints a `http://127.0.0.1:<port>/bootstrap/<token>` URL; opening it exchanges the token for a session cookie and redirects to the inbox. Must run as the same OS user as the wallet's MCP server process — the attestation binds that user's id.

```bash
stellar-agent approve serve --profile default --port 7823
```

### `approve serve --remote`

Binds a TLS-protected, passkey-authenticated remote-approval surface instead of the loopback inbox, for approving from a device other than the wallet host. Refuses to start unless BOTH the profile has a `[remote_approval]` block with `enabled = true` AND `--confirm-remote-exposure` is also passed — the profile block alone is never sufficient consent. `--port` / `--no-open` / `--notify` / `--bell` / `--include-expired` are ignored in this mode.

| Flag | Meaning |
|---|---|
| `--remote` | Bind the remote surface instead of the loopback inbox |
| `--confirm-remote-exposure` | Required explicit consent, separate from the profile's `enabled` flag |

Every approve or reject on this surface requires a fresh WebAuthn passkey assertion bound to the exact pending entry, in addition to the session login. See `docs/remote-approval.md` in the wallet repository for the full setup guide (the `[remote_approval]` profile block, DNS/hosts-file requirements for `rp_id`, and the login/approve walkthrough).

```bash
stellar-agent approve serve --remote --confirm-remote-exposure --profile default
```

### `approve operator enroll`

Enrolls a WebAuthn passkey credential for the remote-approval surface. Runs entirely locally in both modes below — neither touches the network. Enrollment alone never authorizes the credential; its id must also be added to the profile's `[remote_approval] allowed_credentials` list.

A WebAuthn credential is bound to its `rp.id` at creation time, and a loopback origin can only claim `"localhost"` as an effective domain — that binding decides which mode applies:

- **`--interactive`** — for a loopback or SSH-tunnelled `approve serve --remote` listener. Starts a one-shot local server, prints (and by default opens) an enrollment page, and persists the credential automatically once the ceremony completes. The printed URL carries a single-use bootstrap token exchanged for an HttpOnly session cookie on first visit; serving the page and the credential-persisting POST both require that cookie, and the server binds `127.0.0.1` only. Always produces `rp_id: "localhost"`.
- **`--credential-id` / `--public-key` / `--rp-id` / `--label`** (all four together) — for a domain-configured remote listener. Imports the id and public key from a WebAuthn ceremony run elsewhere, normally the remote listener's own `GET /enroll` page (which has to be served from `https://<rp_id>` for the credential to bind to that domain, and displays a ready-to-run copy of this command).

| Flag | Meaning |
|---|---|
| `--profile <NAME>` | Profile whose operator-credential store to write |
| `--interactive` | Start the loopback ceremony (mutually exclusive with the three credential-import flags `--credential-id`/`--public-key`/`--rp-id`; `--label` still applies, as a page pre-fill) |
| `--no-open` | Print the enrollment URL instead of opening a browser (interactive mode only) |
| `--timeout-seconds <SECS>` | Interactive-ceremony timeout (default: 300) |
| `--credential-id <B64URL>` | Base64url WebAuthn credential id (16-64 raw bytes); import mode, requires the other three below |
| `--public-key <B64URL>` | Base64url-encoded 65-byte uncompressed SEC1 P-256 public key (`0x04 \|\| X \|\| Y`); import mode only |
| `--rp-id <HOSTNAME>` | Must match the profile's `[remote_approval] rp_id` exactly; import mode only |
| `--label <LABEL>` | Operator-chosen name for the credential (e.g. `"laptop"`); required in import mode, optional page pre-fill in interactive mode |
| `--sign-count <U32>` | Best-effort sign-counter seed read at enrollment time; import mode only (interactive mode extracts it automatically). Advisory only — never affects authorization |

```bash
# Local or SSH-tunnelled listener
stellar-agent approve operator enroll --interactive --label laptop

# Domain-configured remote listener: import a credential enrolled via its own /enroll page
stellar-agent approve operator enroll --credential-id <B64URL> \
  --public-key <B64URL> --rp-id wallet.example.internal --label laptop --sign-count <N>
```

---

## audit

Verifies the per-profile audit log, an append-only hash-chained JSONL record of transaction submissions, signed authorizations, approvals, and explicit key-management and lifecycle events, and repairs its tip anchor. MCP balance reads and payment simulations produce no automatic invocation row. Under V1, payment simulations can reconcile overdue reservations and write settlement audit rows. Argument values are never logged; only argument key names. The chain links each entry to the SHA-256 of the prior entry's canonical body. Uses the `{ok, data, request_id}` envelope.

The chain and the per-file chain-root signatures verify a PREFIX, so an older copy of the active log, or a truncated one, passes both. The tip anchor pins the END of the chain: the active file's entry count, last-entry hash, and byte offset, held in the platform keyring per log path.

### `audit verify <LOG_PATH>`

Read-only. Walks the log at `<LOG_PATH>`, following rotation manifests, and verifies the hash chain end to end. With `--profile`, also loads that profile's audit chain-root HMAC key and verifies the chain-root sidecars; without it, only the hash chain is checked and `hmac_verified` is `false`.

| Flag / arg | Meaning |
|---|---|
| `<LOG_PATH>` (positional, required) | Path to the audit log file. Default location by OS: Linux `~/.local/share/stellar-agent/audit/<profile>.jsonl`; macOS `~/Library/Application Support/Soneso.stellar-agent/audit/<profile>.jsonl`; Windows `%LOCALAPPDATA%\Soneso\stellar-agent\data\audit\<profile>.jsonl` |
| `--profile <NAME>` | Profile whose chain-root HMAC key verifies sidecars |
| `--output <FORMAT>` | `json` is the default and only stable format |

The tip anchor is checked only when `--profile` is supplied AND `<LOG_PATH>` is the log that profile configures, since the anchor names a path. Every other case reports `anchor.status` as `"not_checked"` with the reason and still verifies the chain in full. The check proves the anchored entry is still at the anchored offset, so a longer internally consistent log that does not contain it refuses rather than passing on length alone.

On Unix, refuses to verify a log whose parent directory is owned by a different user. Exits `0` when the chain is intact, `1` on any integrity violation (broken chain, rotation gap, HMAC mismatch, missing sidecar, unparseable line, tip-anchor mismatch), path-contract failure, or I/O error.

`outbox_pending` counts the consent rows queued in the audit outbox beside the log (`<LOG_PATH>.outbox`) and not yet drained into it, read without taking the outbox lock. Queued rows sit outside the tip anchor until a draining writer appends them. A torn outbox adds an `outbox_torn_tail` warning and unparseable lines add `outbox_unparseable`. An unreadable outbox adds `outbox_unreadable` and omits `outbox_pending`, since no count is known. None of them changes the chain verdict.

```bash
stellar-agent audit verify ~/.local/share/stellar-agent/audit/default.jsonl --profile default
```

```json
{"ok":true,"data":{"entries_verified":42,"files_walked":2,"hmac_verified":true,"per_file":[],"warnings":[],"audit_writer_degraded":false,"anchor":{"status":"verified","reason":null},"outbox_pending":0},"request_id":"..."}
```

### `audit reanchor --profile <NAME> --acknowledge-rollback`

State-changing (writes the keyring anchor, appends one or two audit rows, then drains the audit outbox; no network). The only way out of an `audit.tip_anchor_mismatch` or `audit.log_binding_changed` refusal. Operator-only: an agent must never run it on its own initiative, because it accepts a log or a profile change that may have been tampered with.

| Flag / arg | Meaning |
|---|---|
| `--profile <NAME>` (required) | Profile whose configured `audit_log_path` and audit keyring coordinate identify the anchor |
| `--acknowledge-rollback` (required to act on a rolled-back log) | Accept the log's current tip as authoritative |
| `--acknowledge-binding-change` (required to act on a changed binding) | Accept a log path or audit key that differs from the recorded audit binding |

| Recorded binding | Current path's anchor | Flags required | Rows appended |
|---|---|---|---|
| Equal or absent | Any | `--acknowledge-rollback` | `rollback_acknowledged` |
| Changed or unreadable | Absent, or agrees with the log | `--acknowledge-binding-change` | `binding_changed` |
| Changed or unreadable | Disagrees with the log, or cannot be parsed | Both | `rollback_acknowledged`, then `binding_changed` |

A flag the matrix does not require is ignored. A missing flag changes nothing and exits `1` with `validation.acknowledgement_required`, naming the flag. With the required flags it replays the whole log, so a broken chain is refused rather than blessed. It writes the current tip, bumps the current path's re-anchor counter once, and appends the rows, each carrying that count. `binding_changed` names the old path's anchor, or none when the record was unreadable. The new binding is stored last. It takes the audit writer's exclusive lock. While an MCP server holds that profile's writer, repair refuses with `audit.writer_locked`. Stop that server before a rollback repair. A binding change needs no stop: a server running the edited profile refuses before it opens the new path, so it holds no lock there. A server still running the old profile refuses after the acknowledgement until it restarts.

Queued consent rows follow the repair rows and are counted in `outbox_drained`. A drain refusal leaves the repair in force and exits `0`. It omits `outbox_drained`, since every queued row stays queued, and lists the refusal under `warnings`: `audit.outbox_unusable`, `audit.outbox_busy`, or the condition an append refused on, such as `audit.io_error`.

```bash
stellar-agent audit reanchor --profile default --acknowledge-rollback
stellar-agent audit reanchor --profile default --acknowledge-binding-change
```

```json
{"ok":true,"data":{"profile":"default","previous_anchor":"42:18104","current_anchor":"39:16820","reanchor_count":1,"acknowledged":["rollback"],"recorded_binding":"equal","previous_binding_anchor":null,"outbox_drained":0},"request_id":"..."}
```

### Governance loop

1. The agent surface evaluates an action against the policy engine; an action needing consent records a pending approval and returns its nonce instead of executing.
2. The wallet owner runs `approve --id <NONCE> --profile <name>`, reads the wallet-controlled summary, and consents. The command writes an HMAC attestation (or toolset grant) bound to the profile name, chain id, nonce, envelope digest, and local user.
3. The agent surface verifies the attestation and executes; the commit writes its transaction audit events to the hash-chained log.
4. The operator periodically runs `audit verify --profile <NAME>` to confirm the chain, the chain-root HMAC sidecars, and the tip anchor are intact.

---

## tx

Settles the submission records the value verbs write. Every value-moving verb records a transaction before it is sent, so a submission whose confirmation never arrived leaves a receipt and a spending-window reservation behind; both hold the operator's caps and the wallet's duplicate check until something settles them.

### `tx status <HASH> [flags]`

Asks the endpoint what became of `<HASH>` and settles the wallet's record of it. This is the way out of `submission.tx_timeout`.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<HASH>` (positional) | Transaction hash, 64 lowercase hex — `error.details.tx_hash` from the timed-out submission | — |
| `--profile <NAME>` | Profile whose records and spending window are settled | `STELLAR_AGENT_PROFILE`, else `default` |
| `--output <FORMAT>` | `json` or `table` | `json` |

Returns `{tx_hash, chain_status, ledger, record}`. `SUCCESS` records the spend and writes the value-action row the submission never got to write; `FAILED` releases the reservation; `NOT_FOUND` releases it only when the transaction can no longer apply (its sequence has been consumed, or its time bound has passed) and otherwise leaves the record standing. The verb is repeatable: a submission already accounted for gets no second row.

Writing the settled row needs the audit writer's exclusive lock, so while a `stellar-agent-mcp` server holds that writer the verb refuses with `audit.writer_locked`. Stop the server, reconcile, start it again.

### `tx receipt clear <ENVELOPE_HASH> --acknowledge [flags]`

Releases a submission record reconciliation cannot settle. Two record states qualify: `pending`, whether or not the submission was sent, and `ambiguous`. A record the network has answered for is refused with `submission.not_clearable`.

The verb asks the endpoint what became of the transaction before it accepts. A `SUCCESS` or `FAILED` answer is refused, and so is an endpoint that cannot answer at all: a transaction still in flight is the case an operator would be wrong about. The record state is checked first, so a clear the verb refuses releases nothing and writes no row.

`--acknowledge` is required: releasing the reservation states that the transaction did not move value, which the wallet cannot establish. Without the flag nothing is written and the exit code is 1. The receipt is marked `cleared_by_operator`, not removed, and an audit row names the state the clear replaced.

---

## toolsets

Install, list, run, and uninstall agent toolsets with cryptographic provenance verification. Uses the standard `{ok, data|error, request_id}` envelope; failures carry a `toolsets.*` (directory/install/uninstall) or `toolset.*` (enforcement, shared with the MCP `stellar_toolset_invoke` tool) wire code. JSON by default. All four accept `--toolsets-dir <PATH>` to override the OS-conventional toolsets root. The binary subcommand is `toolsets` (plural).

### `toolsets install <PKG@VERSION> [flags]`

Installs a toolset from a signed local `.tar.gz`. The publisher key must be in the configured publisher trust set. Toolsets that declare a key-touching capability (e.g. `sign-payment`) additionally require a valid auditor attestation unless `--override-attestation`.

| Flag / arg | Meaning |
|---|---|
| `<PKG@VERSION>` (positional, required) | `<name>@<version>`, e.g. `my-toolset@1.0.0` |
| `--file <PATH>` (required) | Path to the `.tar.gz` package |
| `--shasum <HEX>` (required) | Expected SHA-256 of the package (64 lowercase hex) |
| `--signature <HEX>` (required) | Publisher ed25519 signature over the canonical preimage (128 hex = 64 bytes) |
| `--publisher <G-STRKEY>` (required) | Publisher ed25519 public key as a Stellar G-strkey |
| `--trust-set <PATH>` | Publisher trust-set file (default `<toolsets_dir>/trust.txt`) |
| `--attestation-file <PATH>` | JSON `ToolsetAttestation` from the auditor tool; required for key-touching toolsets unless overridden |
| `--auditor-trust-set <PATH>` | Auditor trust-set file (default `<toolsets_dir>/auditor-trust.txt`); distinct from the publisher set; an absent/empty set fails closed for key-touching toolsets |
| `--override-attestation` | Bypass the attestation gate for a key-touching toolset (the only sanctioned bypass); installs with the key-touching capability inert; reports `"attestation":"overridden"` |
| `--force` | Reinstall even if already installed |
| `--allow-downgrade` | Allow installing an older version over a newer one (only with `--force`) |
| `--toolsets-dir <PATH>` | Override toolsets root |

On success `data` carries `package`, `version`, and `attestation` (`"attested"` / `"overridden"` / `"not-required"` — the actual gate decision, not an inference from flags). Refusals (attestation-required, auditor-untrusted — no partial install — or any other install failure) carry `error.code` `toolsets.install_failed`, with the distinguishing detail in `error.message`.

```bash
stellar-agent toolsets install my-toolset@1.0.0 --file ./my-toolset-1.0.0.tar.gz \
  --shasum <sha256hex> --signature <128hex> --publisher GPUB...WXYZ
```

### `toolsets list [--toolsets-dir PATH]`

Read-only. The canonical scriptable enumeration of installed toolsets and their capability-derived action lists (not parsed from `--help`). Reports `data.toolsets`.

### `toolsets run <TOOLSET-NAME> <ACTION> [--toolsets-dir PATH]`

Runs the four-part capability enforcement check for an installed toolset action and reports the resolved trusted tool name. It does **not** execute the routed tool — use the MCP surface tool `stellar_toolset_invoke` for execution.

- `<TOOLSET-NAME>` (positional, required) — installed toolset package name.
- `<ACTION>` (positional, required) — must be an exact registry tool name the toolset's capabilities grant, e.g. `stellar_balances`.

On success, exit `0` with `data` carrying `toolset`, `action`, `routed_to`, and a `note` clarifying that enforcement passed but the tool was not run. On failure, exit `1` with `error.code`: `toolset.not_installed`, `toolset.unknown_action`, `toolset.capability_not_declared`, `toolset.tool_not_allowed`, `toolset.io_error`, or `toolset.error`. The toolset gate is additive: the routed tool's operator policy and chain gates still apply at execution time.

```bash
stellar-agent toolsets run balance-reporter stellar_balances
```

### `toolsets uninstall <PACKAGE> [--toolsets-dir PATH]`

Removes the toolset directory and pin record; refuses if not installed (`toolsets.uninstall_failed`). `<PACKAGE>` (positional, required) is the package name (`[a-z0-9-]`). On success `data` carries `package`.

```bash
stellar-agent toolsets uninstall my-toolset
```
