# CLI reference

See [Mainnet configurations and scope](https://github.com/Soneso/stellar-agent-wallet/blob/main/docs/getting-started.md#mainnet-configurations-and-scope)
for build configuration, admitted operations, and exclusions.

Use MCP tools for agent payments, account creation, trustlines, and claims.
Their paired commit tools carry the pending-store approval loop; see
[MCP tools](mcp-tools.md). The CLI serves reads, setup, and operator ceremonies.
The CLI itself is operator authority. Delegated execution runs through it
under the on-chain rules of the agent's key.

## Signing and approval coverage

On testnet, CLI payment and claim commands evaluate policy and refuse approval
decisions with `policy.approval_required`, directing callers to MCP. Sponsored
account creation, trustline, trade, and vault commands use the same refusal.
On testnet these commands create no pending policy approval. On mainnet, trade
and vault commands refuse with `network.mainnet_write_forbidden`. Full-mode
payment, claim, sponsored creation, and trustline commands insert a pending
entry and ask for passkey confirmation in the local browser, for `Allow` and
`RequireApproval` alike. Use their MCP tools for agent
actions; DeFi tools also refuse policy approval decisions without a pending loop.

Other CLI signing paths have these checks:

| Signing action | Wallet policy behavior |
|---|---|
| Smart-account multicall | Requires V1. Only Allow proceeds; approval refuses with public code `sa.multicall_failed` and audit code `multicall.approval_required`. |
| Delegated smart-account execution | It is sized as an unvalued contract call before signing. A matching value rule without `allow_opaque_signing` refuses it, and count limits charge it. On-chain context rules authorize the invocation. |
| Smart-account administration | Rule and signer mutations, verifier migration, and timelock `cancel` count against matching V1 rate limits before signing. Timelock `schedule` and `execute` are sized as unvalued contract calls. Each requires its on-chain authority. |
| Contract deployment | Account, verifier, and policy deployment bypass wallet policy and require a deployer signer. |
| Channel-pool initialization | Bypasses wallet policy; uses the agent's enrolled MCP signer and derived channel keys to create accounts with sponsored reserves and zero starting balances. |

Rule creation also has an MCP proposal-and-commit pair requiring operator approval.
DeFi actions have MCP tools; SEP signing and x402 authorization are MCP-only
signing surfaces. MPP has both CLI and MCP flows.

CLI MPP authorization creates pending approval when its prepare policy requires
it, returning `mpp.approval_required`. After operator approval, it resumes the
stored authorization and verifies consent before signing. When only the commit
rule requires approval, CLI MPP refuses with `mpp.approval_invalid` and creates
no pending approval entry. MCP prepare records pending approval for either rule.
CLI trustline clawback opt-in creates separate pending consent after policy
allows the action.
Passkey registration creates a pending ceremony entry too.
Every transaction-signing or submitting verb retains the halt check.
Smart-account governance, deployment, and `pool init` also keep the mainnet
refusal.
Reads, key, policy, and approval ceremonies, and CLI state recording and
reconciliation stay usable while halted.

On testnet, CLI approval checks the local OS identity; it reads consent from
standard input or `--yes` and does not establish that a human confirmed. On
mainnet it refuses `--yes` and terminal input and requires a verified passkey
assertion from an approval credential in the owner-signed policy.
A process running as the operator's OS user holds the operator's authority.
MCP alone offers no operator approval tool. See [the safety model](../SKILL.md#9-safety-model).

## Mainnet profile selection

A mainnet profile loads only through `--profile <name>`. `STELLAR_AGENT_PROFILE` never selects one, and a mainnet `default.toml` needs `--profile default`. Keep the filename: its identity is bound to its keyring entries.

Unset the `STELLAR_AGENT_*` variable the refusal names. On every chain that covers `STELLAR_AGENT_CHAIN_ID`, `STELLAR_AGENT_AUDIT_LOG_PATH`, every `*_KEY_ID` variable, and every other key outside the overlay classes. On mainnet it also covers `STELLAR_AGENT_RPC_URL`, `STELLAR_AGENT_SECONDARY_RPC_URL`, `STELLAR_AGENT_ORACLE_PROVIDER_URL`, `STELLAR_AGENT_MCP_SIGNER_DEFAULT`, and the other testnet-only keys. Remove refused keys from programmatic overlays too, and set needed values in the profile file. Then run `stellar-agent profile show --profile <name>` to confirm the file's chain and endpoint. Correct the profile file if either value differs from the intended configuration.

| Wire code | Meaning |
|---|---|
| `profile.non_overlayable_field` | An overlay named a key outside its class, or set `mcp_disabled` to anything but `true`, including an equal value. Overlays may set `submit_timeout_seconds` on every chain, the testnet-only endpoint, signer, fee, threshold, and scan-bound keys on testnet, and `mcp_disabled = true`; every other key comes from the file. Remove that environment value, overlay, or flag, and set the value in the profile file. |
| `profile.network_flag_mismatch` | `--network` differs from the loaded chain. Remove the flag or select a profile on that chain. |
| `auth.enrolled_signer_unpinned` | Mainnet enrollment is a placeholder or malformed. Correct a malformed `mcp_signer_default.account`, then run `stellar-agent profile enroll-signer --profile <name>`. |
| `auth.enrolled_signer_mismatch` | The derived key differs from the enrolled identity. Use the enrolled seed, Ledger account, or keyring entry. |
| `profile.mainnet_requires_explicit_profile` | A mainnet profile was selected by the environment or the default source. Supply `--profile <name>`. |

## Invocation and global model

The binary is `stellar-agent` on `PATH`. When `stellar` is installed it is also reachable as a plugin: `stellar agent <command> ...`. Examples below use the direct form.

The top-level command accepts `-h`/`--help` and `-V`/`--version`. Network, profile, RPC URLs, and signer source are declared per subcommand. Run `stellar-agent --help` for the live subcommand list and `stellar-agent <command> --help` for a group's flags.

### Output envelope and exit codes

Every command prints one JSON object on stdout by default. A command that accepts `--output table` prints a table instead when that format is selected. Exit code `0` means success; exit code `1` means any error. The standard envelope is:

```json
{"ok": true, "data": { ... }, "request_id": "..."}
{"ok": false, "error": {"code": "...", "message": "..."}, "request_id": "..."}
```

The `credentials` and `toolsets` groups use this same envelope; a `credentials.*` or `toolsets.*` / `toolset.*` wire code identifies the specific refusal.

### Value formats

- Amounts are decimal strings with an explicit unit, e.g. `"10 XLM"`, `"10.5 USDC"`, `"5 XLM"`. Bare numbers and raw stroop strings are rejected on user-facing amount flags. The DeFi commands `vault` and `trade` take raw integer base-unit amounts (`i128`, through `--amount`, `--shares`, and related flags) with no unit.
- Assets are `native`, `XLM`, or `CODE:ISSUER_GSTRKEY` (e.g. `USDC:GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN`). Contract addresses are C-strkeys; classic accounts are G-strkeys; secret keys are S-strkeys.
- `--fee <STROOPS|auto[:pNN]>`: an integer sets explicit stroops; `auto` selects the p95 percentile from `getFeeStats`; `auto:pNN` selects an explicit percentile (`p50`, `p75`, `p95`, `p99`). Absent uses the profile default (100 stroops). Soroban resource fees are added by simulation. (`smart-account multicall` accepts only an integer `--fee`; `auto` is rejected there.)

### Shared flags

These recur with the same meaning across groups:

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Selects the per-environment TOML profile (binds CAIP-2 chain, RPC, keyring entry references, thresholds, policy engine). Holds no keys; an endpoint URL can still embed a credential. | resolves `--profile` → `STELLAR_AGENT_PROFILE` → `"default"` on every command that loads a profile (`fees stats` loads only with `--profile`; `accounts deploy-c` opens its writer only with that flag) |
| `--network <NETWORK>` | Optional assertion; must match the profile chain | profile chain |
| `--rpc-url <URL>` | Testnet override; refused on mainnet; credentials refused; gets the keyring credential only when it equals the profile's `rpc_url` | profile endpoint |
| `--secondary-rpc-url <URL>` | Testnet override; refused on mainnet; credentials refused; sends no keyring credential | profile secondary |
| `--timeout-seconds <SECONDS>` | Bounds submission and simulation | `60` |
| `--output <FORMAT>` | `json` (default) or `table`; not accepted on every command | `json` |

### Signer source

Signing commands take a mutually exclusive signer-source group (exactly one):

- The secret-env flag: the **name of an environment variable** holding the source-account S-strkey. The operator sets the variable as [Pass a secret seed](https://github.com/Soneso/stellar-agent-wallet/blob/main/docs/getting-started.md#pass-a-secret-seed) shows; pass the variable name, never the secret. Spelled `--secret-env` on `pay` / `accounts create`, `--deployer-secret-env` on `accounts deploy-c` and the `smart-account deploy-*` verbs (`deploy-webauthn-verifier`, `deploy-ed25519-verifier`, `deploy-spending-limit-policy`), `--signer-secret-env` on the `smart-account` commands.
- `--sign-with-ledger`: sign with a connected Ledger hardware device.
- `--account-index <INDEX>`: BIP-44 account index for the Ledger derivation path. Default `0`.

In the operator's terminal, run this line on its own, paste the source-account seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'WALLET_SK seed: ' && read -rs WALLET_SK && echo && export WALLET_SK
```

```bash
stellar-agent pay GDEST...WXYZ "10 XLM" --source GSRC...WXYZ --secret-env WALLET_SK
unset WALLET_SK
```

### Mainnet write behavior

Builds from this repository and releases from v0.1.0-alpha.14 on carry
`mainnet-write`. These builds admit full-mode `pay`, `claim`, sponsored
`accounts create`, and `trustline` after installation setup and consent for
each action. Build-only, sign-only, submit-only,
Friendbot creation, generated-account creation, and relayer paths remain excluded.

Select an explicit nondefault mainnet profile with matching stored configuration.
Enroll signer and owner identities, enable the installation, and sign a v2 policy.
Valid pin and audit state, required witnesses, and per-action authorization remain
necessary. [The policy guide](profiles-and-keys.md#mainnet-policy-body) lists the fields.

Mainnet consent requires a fresh WebAuthn assertion, with user presence and
user verification, from an approval credential listed in the owner-signed
policy ([approval credentials](profiles-and-keys.md#approval-credentials)). Terminal input, a
pseudo-terminal, `--yes`, and the local process identity supply no mainnet
consent.

Mainnet approve, the local inbox, and direct CLI confirmation open a localhost
passkey page. The operator reviews the authoritative transaction and approves
with an owner-pinned credential. Headless consent, `--yes`, `--no-open` on the
mainnet inbox, and remote mainnet approval refuse. Ledger signing also requires
this passkey ceremony.

An MCP mainnet commit accepts only a version 5 approval with its verified
presence receipt. An invalid proof refuses with `policy.approval_required`.
Each challenge lasts at most 120 seconds. The command waits until pending
expiry. A canceled authenticator prompt ends the ceremony; retry the command
for a fresh challenge.
Testnet approvals retain version 4 and their terminal and remote paths.

`approval.presence_required`: `Mainnet consent requires a verified assertion from an approval credential in the owner-signed policy; use the local passkey approval page.`

`approve.yes_refused_on_mainnet`: `approve --yes is refused on a mainnet profile; approve with a pinned passkey in the local browser.`

`network.mainnet_write_forbidden` means the build, operation, or selected context
has no admitted path. Missing CLI engine, verified policy, or enablement is an
entry refusal with the prerequisite named. Resolver refusal uses
`network.mainnet_authorization_refused`. Its core message is
`the mainnet write was refused before submission; nothing was sent`.

`network.mainnet_keyring_backend_unsupported` means the process uses a
headless keyring backend (`STELLAR_AGENT_KEYRING_BACKEND` is set). Mainnet
readiness and `profile enable-mainnet` refuse it before any keyring entry is
read; mainnet needs the platform keyring. Testnet is unaffected.

CLI messages distinguish the withheld result:

- Signature: `the mainnet write was refused; the signature was withheld and nothing was sent`.
- Submission: `the mainnet write was refused; the submission was refused after signing and nothing was sent`.

Other signature-stage errors append `The signature was withheld and nothing was sent.`
Other post-signing errors retain their own outcome semantics. A signer can run
before signature verification rejects its result. Submission refusal can follow
signing. Classic MCP renders the core message without these stage replacements.

Read-only inspection remains available. `tx` signs nothing. Smart-account writes,
DeFi, and pool submission remain excluded. `smart-account rules verify-pins`,
`signers list`, and `signers refresh` retain local audit writes without signing.
A persisted profile therefore needs its audit key initialized.
Friendbot reports `network.friendbot_mainnet_forbidden`; MPP reports
`mpp.network_forbidden`. `--network mainnet` on a testnet profile reports
`profile.network_flag_mismatch` before write admission.

The wallet's own signing paths sign mainnet payloads only under mainnet
authorization. The library signers enforce it too: every `Signer`, the public
keyring handle included, signs a mainnet transaction or Soroban authorization
payload only under a mainnet authorization. Code running as the same OS user
with access to a keyring entry can read its seed directly. The keyring entry
is the custody boundary.

Ordinary submission refuses the declared mainnet passphrase or known mainnet host before RPC.
Authorized signing and submission independently check sealed authorization.

All four full-mode verbs include numeric `total_fee_stroops`, equal to unsigned
`tx.fee`, in policy arguments on both networks. `pay --build-only` and
`claim --build-only` include it too, so `minimum_reserve` counts the fee of the
envelope they return. Mainnet action checks use the
effective signed/profile fee cap and thresholds; the resolver reevaluates them.

### Submit-layer network binding

The submit layer does not take the declared network on trust. Before sending, it asks the endpoint which network it serves and which protocol it runs, on the client that sends. That answer is authoritative. `pay`, `claim`, sponsored `accounts create`, `trustline`, and `pool init` ask the same question earlier, on that same client, before the first read whose answer they sign or gate on. That read is the fee, the sequence, the claim entry, a policy view, or the reservation reconcile. Ordinary submission refuses a mainnet endpoint with `network.mainnet_write_forbidden`. Authorized submission verifies its bound context. One reporting a different network than declared is refused with `network.endpoint_network_mismatch`. One whose identity cannot be established within the timeout is refused with `network.endpoint_identity_unavailable`. One that answers the identity request with HTTP 401 or 403 is refused with `network.rpc_credential_refused`. The check is retried with bounded backoff inside the caller's timeout and never falls back to the declaration. An answer that does not parse, and a 401 or 403 answer, is not retried.

An endpoint refusal precedes every refusal that follows a read: a missing account or claim entry, a policy denial, the audit pre-flight, and the amount, asset, and fee checks. `pool init` runs its audit pre-flight before the check. The full payment pipeline validates the asset and amount before endpoint identity and reservation reconciliation. Fee validation follows reconciliation. A `claim` or `trustline` refused at the early check carries no preview. Each check gets a budget of its own: `--timeout-seconds` on `pay`, `claim`, `accounts create`, and `pool init`, and the profile's `submit_timeout_seconds` on `trustline`. `--build-only` checks before its reads. `--sign-only` checks before the account reads of an envelope it decodes and signs an envelope it cannot decode without any request.

This release supports protocol versions 29 and 30. On testnet and other networks, a version outside that range is logged as a warning and the submission continues. On mainnet the same version is refused with `network.unsupported_protocol_version`. Ordinary submission refuses mainnet before this protocol rule.

It verifies every decorated signature against the endpoint network id. Verification uses the ed25519 signer sets of the transaction source and each operation source. An account absent from the ledger reports `network.account_not_found`. A signature that fails under the endpoint network but verifies under mainnet uses `network.envelope_signed_for_mainnet`. Verification under neither uses `network.envelope_signature_unverifiable`. Missing signatures use `network.envelope_unsigned`, including either fee-bump signature set. Every signature must pass and each signature set must have at least one, so an envelope signed for one network cannot be submitted under another network's passphrase.

---

## accounts

Account-management group. Subcommands: `create`, `deploy-c`.

### `accounts create [NEW_G_STRKEY] [flags]`

Creates a new account in one of two mutually exclusive modes: sponsored `CreateAccount`, or Friendbot funding. Sponsored mode signs with the sponsor key; Friendbot mode signs nothing. Configured sponsored mainnet creation requires feature-enabled authorization. Friendbot refuses mainnet with `network.friendbot_mainnet_forbidden`. Mainnet requires an existing destination G-strkey. Feature-on `--generate` uses `accounts.create.generate_refused_on_mainnet`; feature-off context construction refuses earlier with `network.mainnet_write_forbidden`.

Argument groups (parser-enforced): mode (exactly one) `--sponsor` xor `--fund-with-friendbot`; account (exactly one) positional `<NEW_G_STRKEY>` xor `--generate`; signer (sponsored) `--secret-env` xor `--sign-with-ledger`.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<NEW_G_STRKEY>` (positional) | G-strkey of the account to create | — |
| `--generate` | Mint a fresh ed25519 keypair in-process; returns G- and S-strkey in JSON (`data.secret_key`, never in `table`, never logged) | `false` |
| `--sponsor <G_STRKEY>` | Sponsor/source for `CreateAccount` | — |
| `--starting-balance <AMOUNT>` | Starting balance with units, e.g. `"5 XLM"` (sponsored mode) | — |
| `--secret-env <VAR>` | Env-var name holding sponsor S-strkey; refused on a mainnet profile, which signs with the enrolled seed in the keyring | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger signer / BIP index | `false` / `0` |
| `--fund-with-friendbot` | Fund via Friendbot (testnet only) | `false` |
| `--friendbot-url <URL>` | Friendbot endpoint (Friendbot mode) | `https://friendbot.stellar.org` |
| `--network` / `--fee` / `--timeout-seconds` / `--rpc-url` / `--output` | shared (sponsored mode) | as above |

The sponsor public key must match the public key derived from the signer. `--generate` prints the new account's seed in `data.secret_key`; the command output holds the seed, so do not write it to a log or a shared terminal.

In the operator's terminal, run this line on its own, paste the sponsor seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'SPONSOR_SK seed: ' && read -rs SPONSOR_SK && echo && export SPONSOR_SK
```

```bash
stellar-agent accounts create --generate --sponsor GABC...WXYZ \
  --secret-env SPONSOR_SK --starting-balance "5 XLM"
unset SPONSOR_SK
```

Sponsored creation checks its selected fee against
`classic_max_fee_per_op_stroops` before the witness. The default is the command's
100 stroops; an explicit or automatic fee keeps its own source in a cap refusal.
One sponsor observation on the primary feeds policy, the witness, and the
envelope sequence. The submission separately reads the sponsor's signer set to
verify the signature binding. The starting balance determines whether the
witness is required, with a native floor of 1000 XLM.

The result includes `cross_check` with `passed`, `skipped`, or `not_required`.
Table output prints its witness line. Friendbot results omit the field.
The pending audit row carries a passed witness.
A sponsored confirmation timeout reports `error.details.envelope_hash` from the
signed envelope, without returning the envelope. A failure before signing has
no envelope hash.

### `accounts deploy-c [flags]`

Deploys a new OpenZeppelin smart-account (C-account) contract via `CreateContractV2`; the genesis signer is installed through the contract `__constructor`. Signs source-account credentials with the deployer key (except `--dry-run`, which derives the C-strkey deterministically with no signing or RPC). `mainnet` parses but is structurally refused for writes.

Argument groups: deployer (exactly one) `--deployer-secret-env` xor `--sign-with-ledger`; salt (at most one) `--salt-hex` xor `--salt-random` (random when neither given); genesis signer source (exactly one) `--initial-signer` xor `--signer-webauthn` xor `--signer-ed25519` xor `--signer-external` (with `--signer-key-data`). `__constructor` takes a single-element signer vec, so exactly one genesis signer is ever installed.

| Flag | Meaning | Default |
|---|---|---|
| `--initial-signer <G_STRKEY>` | Delegated (native) genesis signer | — |
| `--signer-webauthn <CRED_NAME>` | Genesis signer = an already-registered passkey, resolved from the local passkeys registry; needs a WebAuthn verifier already deployed (`deploy-webauthn-verifier`) | — |
| `--signer-ed25519 <HEX_PUBKEY_64>` (optional `--verifier <C_STRKEY>` override) | Genesis signer = raw 32-byte ed25519 pubkey, verified by the Ed25519 verifier resolved from `--verifier` when supplied, else the verifier registry | — |
| `--signer-external <C_STRKEY>` + `--signer-key-data <HEX>` | Genesis signer = verified by this verifier contract with this key data | — |
| `--accept-no-delegated-fallback` | Required with any non-`--initial-signer` genesis source: acknowledges NO G-key fallback exists at genesis (`validation.passkey_only_rule_no_delegated_fallback` otherwise) | `false` |
| `--deployer-secret-env <VAR>` | Env-var name holding deployer S-strkey | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger deployer / BIP-44 index | `false` / `0` |
| `--salt-hex <HEX64>` | 32-byte salt as 64-char lowercase hex (re-deploy a known C-strkey) | — |
| `--salt-random` | Fresh random 32-byte salt | random default |
| `--profile <NAME>` | Profile whose audit writer receives deploy entries | none |
| `--network` / `--rpc-url` / `--fee` / `--timeout-seconds` / `--output` | shared | as above |
| `--dry-run` | Derive C-strkey only; no signing, no RPC | `false` |

A non-Delegated genesis signer cannot itself authorize any further rule mutation (`smart-account rules`/`signers` authorize only via a Delegated signer); follow up with `smart-account signers add` to attach a Delegated co-signer once a policy is attached to the target rule.

In the operator's terminal, run this line on its own, paste the deployer seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'DEPLOYER_SK seed: ' && read -rs DEPLOYER_SK && echo && export DEPLOYER_SK
```

```bash
stellar-agent accounts deploy-c --initial-signer GABC...WXYZ \
  --deployer-secret-env DEPLOYER_SK --salt-random
unset DEPLOYER_SK
```

---

## pay

`pay <DESTINATION> <AMOUNT> [ASSET] [flags]`: sends a classic payment, enforcing SEP-29 memo-required before signing. By default builds, signs, and submits atomically. Configured mainnet full mode requires feature-enabled authorization. Staged modes remain excluded. `--use-oz-relayer` is not implemented and declines.

Staged pipeline (mutually exclusive): `--build-only` emits unsigned envelope XDR and exits; `--sign-only <XDR>` signs a prebuilt envelope and emits signed XDR; `--submit-only <XDR>` submits a pre-signed envelope.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<DESTINATION>` (positional) | Destination G-strkey | — |
| `<AMOUNT>` (positional) | Use `"10 XLM"` for native or the exact, case-sensitive asset code for issued assets, such as `"10.5 USDC"` with `USDC:<issuer>` (raw stroop strings rejected). | — |
| `[ASSET]` (positional) | `native`, `XLM`, or `CODE:ISSUER` | `native` |
| `--source <G_STRKEY>` | Source account; required for signing | — |
| `--memo-text <STRING>` | Memo text (UTF-8, up to 28 bytes; control characters, Unicode format characters, and line or paragraph separators are refused with `validation.memo_control_character`) | — |
| `--memo-id <U64>` | Memo ID (u64 decimal) | — |
| `--memo-hash <64_HEX>` / `--memo-return <64_HEX>` | Memo hash / return hash (32 bytes) | — |
| `--secret-env <VAR>` | Env-var name holding source S-strkey; refused on a mainnet profile, which signs with the enrolled seed in the keyring | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger signer / BIP index | `false` / `0` |
| `--build-only` / `--sign-only <XDR>` / `--submit-only <XDR>` | Stage selection (at most one) | — |
| `--profile <NAME>` | Profile whose policy engine, keys, and audit writer to use | `STELLAR_AGENT_PROFILE`, else `default` |
| `--fee` / `--network` / `--timeout-seconds` / `--rpc-url` / `--output` | shared | as above |

Memo flags are a mutually exclusive group (at most one).

Under `policy.engine = "v1"` `pay` evaluates operator policy before signing. The staged `--sign-only` / `--submit-only` stages gate too: they decode the supplied envelope and match rules under the `stellar_pay_commit` tool name, and deny `policy.deny.unsizable_value_effect` on an envelope the decoder cannot size unless the matched rule sets `allow_opaque_signing = true`.

`--submit-only` runs the endpoint identity check before the policy gate and before the audit-key pre-flight, on the client that later reconciles, reads the gate's account views, and sends. An `--rpc-url` pointing at a different network than `--network` is therefore refused early. The check reads the endpoint's protocol version too and applies the same protocol rule as the submit layer, under its own `--timeout-seconds` deadline; the submission then starts a fresh one. It also requires an already-signed envelope: handing it the unsigned XDR that `--build-only` emitted is refused with `network.envelope_unsigned` before anything is sent. `claim --submit-only` behaves the same way.

After the policy gate every `pay` stage checks the per-operation fee against the
effective signed/profile `classic_max_fee_per_op_stroops`: the selected fee in the full
pipeline and `--build-only`, the decoded envelope fee in `--sign-only` and
`--submit-only`. A fee above the cap exits 1 with `fees.percentile_exceeds_cap`,
and the message names the fee's source and the remedy. A mainnet action without
an effective cap refuses with `validation.mainnet_fee_cap_required`.

The full pipeline, `--sign-only`, and `--submit-only` then obtain the
cross-check witness before the audit pre-flight, the signer, and the send. The
oracle re-reads the source account, the destination, the SEP-29 flag when it was
read, and the source trustline of an issued send asset, valued on the source
debit leg. A disagreement exits 1 with `simulation.divergence`, or
`network.rpc_divergence` for the SEP-29 flag; an oracle fault refuses with
`network.witness_unavailable`. Sponsored create, trustline, and sending pool
initialization also use `simulation.divergence` and `network.witness_unavailable`.
A credential refusal keeps
`network.rpc_credential_refused`. The result carries `cross_check` (`passed`,
`skipped`, or `not_required`), and `--output table` prints a `Cross-check:`
line. `--build-only` has no witness and no `cross_check`. `--sign-only` and
`--submit-only` read the destination's SEP-29 flag when the decoded transaction
carries no memo and pays a plain G account. A destination that requires a memo
refuses with `validation.memo_required` before signing or sending.

Before the transaction is sent, `pay` records it as submitted with an unknown outcome: a submission receipt, a spending-window reservation under a policy with a stateful criterion, and a `value_action_pending` audit row. A submission that ends without a confirmed outcome (the deadline passed, the endpoint reported an unexpected status, or a transport failure struck during or after the send) exits 1 with `submission.tx_timeout`, keeps that record, and carries the full transaction hash in `error.details`. The transaction may still apply. Resolve it with `tx status <HASH>`, never by rebuilding and re-sending: a second submission for the same source account and sequence is refused with `submission.tx_already_submitted` while the first stands, and so is a resend of the same signed bytes the spending window already holds. The same applies to `claim`, `accounts create`, `trustline`, `trade` and `vault`.

In the operator's terminal, run this line on its own, paste the source-account seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'WALLET_SK seed: ' && read -rs WALLET_SK && echo && export WALLET_SK
```

```bash
stellar-agent pay GDEST...WXYZ "10 XLM" --source GSRC...WXYZ \
  --secret-env WALLET_SK --memo-text "invoice-42"
unset WALLET_SK
```

---

## mpp

Testnet-only sponsored MPP charge authorization for the profile's classic
G-account signer. The wallet returns a credential; it does not send the paid
request or submit the server-sponsored transaction.

```bash
stellar-agent mpp charge authorize --profile default --input-file challenge.json
stellar-agent mpp charge authorize --profile default --input-stdin < challenge.json
stellar-agent mpp charge authorize --profile default --approval-id <approval-id>
stellar-agent mpp authorization status --profile default --authorization-id <id>
stellar-agent mpp receipt record --profile default --authorization-id <id> \
  --transport http --receipt-file receipt.txt
stellar-agent mpp settlement reconcile --profile default --authorization-id <id> \
  --reference-file transaction-hash.txt
stellar-agent mpp state prune --profile default --reason-file reason.txt
```

Each input operation requires exactly one stdin/file source; files must be
bounded regular non-symlinks. `authorize` returns `mpp.approval_required` when
its prepare rule requires approval. The operator approves the returned ID
through an approval surface. Resume the stored authorization with `--approval-id`;
no challenge may be supplied on resume. Approval is verified before signing.
A commit-only approval requirement refuses with `mpp.approval_invalid` and
creates no pending approval entry.
Credential output is one-shot and sensitive. Agents use the paired MPP tools
described in [MCP tools](mcp-tools.md).

Receipt observation does not prove settlement. Reconcile requires the lowercase
transaction hash and verifies the exact envelope and payer authorization through
RPC. Prune is audited, requires a bounded reason, retains indeterminate records,
and removes only terminal markers older than 30 days.

---

## balances

`balances [flags]` — reads native XLM balance and trustlines via RPC `getLedgerEntries`. Read-only; no mainnet gate. `--account` is required; omitting it exits `1` with `validation.usage_error`.

| Flag | Meaning | Default |
|---|---|---|
| `--account <G_STRKEY>` (required) | Account to query | — |
| `--asset <CODE:ISSUER>` | Trustline asset; repeatable (untrusted assets omitted) | none |
| `--rpc-url` / `--output` | shared | as above |

```bash
stellar-agent balances --account GABC...WXYZ \
  --asset USDC:GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN
```

---

## trustline

`trustline [flags]` — creates or removes a classic trustline (`ChangeTrust`) behind an ordered trust gate (operator policy, denomination resolution with USDT hard-refusal plus a known-lookalike denylist and pinned-issuer checks, live issuer-flag fetch that fail-closes, clawback gate, typed preview). Builds, signs, submits, waits atomically — no staged pipeline. Network derives from the profile; there is no `--network` flag. USDT cannot be trusted.

After the preview gate proceeds, the command resolves and caps the fee, then
obtains an unvalued witness of the source and issuer flags before loading the
signer. Its default fee comes from `classic_fee_per_op_stroops`, or 100 when
unset. Cap refusals identify that profile default.
Only an absent issuer produces `trustline.gate_refused`; other issuer read
errors retain their own codes and scrubbed messages.
The JSON result includes `cross_check`; the pending row carries a passed
witness.
Fee-cap and witness refusals carry `error.details.preview` after preview approval.

| Flag | Meaning | Default |
|---|---|---|
| `--from <G_STRKEY>` (required) | Account that will hold the trustline | — |
| `--asset <ASSET>` (required) | `USDC` (bare, pin table), `CODE:ISSUER`, or a `C...` SAC address (deferred, typed error) | — |
| `--limit-stroops <I64>` | Explicit limit; `0` removes the trustline | unlimited (`i64::MAX`) |
| `--profile <NAME>` | Profile to load | `STELLAR_AGENT_PROFILE`, else `default` |
| `--fee` | shared | profile `classic_fee_per_op_stroops` |

One JSON envelope: once the clawback gate passes, the typed preview is in `data.preview` on success and in `error.details.preview` when a later step (fee, envelope build, signing, submission) fails.

The submission runs under the profile's `submit_timeout_seconds`, 60 seconds when the field is unset; there is no `--timeout-seconds` flag.

```bash
stellar-agent trustline --from GABC...WXYZ --asset USDC --profile default
```

---

## claim

`claim <BALANCE_ID> [flags]`: claims a Stellar `ClaimClaimableBalance` operation for a balance the agent already holds the id of. Enforces the claim guards (claimant membership, predicate satisfaction, non-native trustline state, native-XLM fee affordability) before signing. Configured mainnet full mode requires feature-enabled authorization. Staged modes remain excluded. Same three-stage pipeline as `pay`: `--build-only` emits unsigned envelope XDR and exits; `--sign-only <XDR>` signs a prebuilt envelope; `--submit-only <XDR>` submits a pre-signed envelope; the default runs all three atomically.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<BALANCE_ID>` (positional) | A `B...` strkey, canonical 72-hex id, or bare 64-hex hash | — |
| `--source <G_STRKEY>` (required) | Claiming account; also the transaction source | — |
| `--fee <STROOPS\|auto[:pNN]>` | Classic fee selector | profile default |
| `--secret-env <VAR>` | Env-var name holding source S-strkey; refused on a mainnet profile, which signs with the enrolled seed in the keyring | — |
| `--sign-with-ledger` / `--account-index <INDEX>` | Ledger signer / BIP index | `false` / `0` |
| `--build-only` / `--sign-only <XDR>` / `--submit-only <XDR>` | Stage selection (at most one) | — |
| `--profile <NAME>` | Profile whose policy engine, keys, and audit writer to use | `STELLAR_AGENT_PROFILE`, else `default` |
| `--network <NETWORK>` | Optional assertion; must match the profile chain (mainnet requires configured full mode) | profile chain |
| `--timeout-seconds` / `--rpc-url` / `--output` | shared | as above |

Under `policy.engine = "v1"` `claim` evaluates operator policy before signing. The staged `--sign-only` / `--submit-only` stages gate too: they decode the supplied envelope and match rules under the `stellar_claim_commit` tool name, and deny `policy.deny.unsizable_value_effect` on an envelope the decoder cannot size unless the matched rule sets `allow_opaque_signing = true`.

`claim` applies the same fee cap as `pay` in every stage. The full pipeline,
`--sign-only`, and `--submit-only` obtain an unvalued cross-check witness before
the audit pre-flight, the signer, and the send. The full pipeline compares the
source account, the complete claimable-balance record, and the trustline of an
issued asset. The staged stages compare the source account. The refusal codes
and the `cross_check` field are those of `pay`.

The build stage computes a typed preview (balance id, asset, amount, claimants, `is_claimant`, predicate verdict) before the guards run. The command prints one JSON envelope: the preview is in `data.preview` on success and in `error.details.preview` when a guard or any later step refuses, so the operator sees the balance disclosure either way. `--sign-only` and `--submit-only` build no preview.

In the operator's terminal, run this line on its own, paste the claiming account's seed when prompted, and press Enter. The line reads the seed from the terminal, so the operator runs it, not the agent.

```bash
printf 'WALLET_SK seed: ' && read -rs WALLET_SK && echo && export WALLET_SK
```

```bash
stellar-agent claim BAAD...WXYZ --source GSRC...WXYZ --secret-env WALLET_SK
unset WALLET_SK
```

---

## friendbot

`friendbot [flags]`: funds a testnet or futurenet account via the Friendbot HTTP endpoint. No local signing. `--network` accepts `testnet`/`futurenet`/`mainnet` at the parser but `mainnet` is refused at dispatch (`network.friendbot_mainnet_forbidden`). The endpoint is allow-list validated (`friendbot.stellar.org`, `friendbot-futurenet.stellar.org`) unless `--friendbot-url-unchecked`. An account at or above the Friendbot starting balance (10,000 XLM on the SDF testnet) exits `1` with `network.friendbot_account_already_funded` and is usable as it is. An existing account below it receives the starting balance.

| Flag | Meaning | Default |
|---|---|---|
| `--account <G_STRKEY>` (required) | Account to fund | — |
| `--network <NETWORK>` | `testnet`, `futurenet`, or `mainnet` (mainnet refused at dispatch); reads no profile | `testnet` |
| `--friendbot-url <URL>` | Endpoint override; otherwise resolves to the SDF testnet URL regardless of `--network`, so `futurenet` needs an explicit override | `https://friendbot.stellar.org` |
| `--friendbot-url-unchecked` | Bypass URL allow-list (dev/test escape hatch) | `false` |
| `--output` | shared | `json` |

```bash
stellar-agent friendbot --account GABC...WXYZ --network testnet
```

---

## fees

Fee-statistics group. Subcommand: `stats`.

### `fees stats [flags]`

Fetches RPC fee statistics for classic fee selection. Read-only; no mainnet gate. With `--profile`, the profile loads first and mainnet refuses `--rpc-url`. Without it, use `--rpc-url`, else the testnet endpoint.

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Profile whose RPC URL to use | none |
| `--rpc-url <URL>` | Allowlisted testnet override; refused with a mainnet profile | profile endpoint, or testnet without `--profile` |
| `--output` | shared | `json` |

```bash
stellar-agent fees stats --output table
```

---

## counterparty

Manages the per-profile cache of `stellar.toml` bindings backing the counterparty allowlist policy. None of these sign a transaction; entries are HMAC-protected and skipped on read if verification fails. Subcommands: `list`, `refresh`, `evict`, `warm-up`, `rotate-hmac-key`.

| Subcommand | Form | Notes |
|---|---|---|
| `list` | `counterparty list [--profile NAME] [--json]` | Lists only live cached bindings (home domain, fetched/expiry timestamps). `--json` is a no-op; JSON is the only shape. Read-only. |
| `refresh` | `counterparty refresh <HOME_DOMAIN> [--profile NAME]` | Force-fetches `https://<domain>/.well-known/stellar.toml`, HMAC-protects, writes atomically. Domain must be strict ASCII, 1–32 chars (IDN/homoglyph rejected). |
| `evict` | `counterparty evict <HOME_DOMAIN> [--profile NAME]` | Deletes one cached binding; exits `0` even if already absent. |
| `warm-up` | `counterparty warm-up [--profile NAME]` | Refreshes domain candidates from allowlist criteria containing `HOME_DOMAIN`. Skips strkeys and `CODE:ISSUER` values; exits `1` if any remaining candidate fails. |
| `rotate-hmac-key` | `counterparty rotate-hmac-key [--profile NAME]` | Rotates the per-profile cache HMAC key; existing files then fail verification and need refresh. |

A `HOME_DOMAIN` binding is evidence for one hour from its fetch. An entry
whose fetch time lies more than five minutes in the future counts as expired.
Expired entries satisfy neither the `HOME_DOMAIN` kind of
`counterparty_allowlist` nor `home_domain_resolved`. A policy that relies on
the `HOME_DOMAIN` kind needs `counterparty warm-up` on a schedule shorter than
one hour. Warm-up refreshes only the domains named in `counterparty_allowlist`
criteria that contain `HOME_DOMAIN`. A policy that uses `home_domain_resolved`
keeps each domain it relies on live with a scheduled
`stellar-agent counterparty refresh <domain>` per domain.

`--profile` resolves `--profile` → `STELLAR_AGENT_PROFILE` → `default` for this group.

```bash
stellar-agent counterparty refresh circle.com --profile default
```

---

## smart-account

Invoke as `stellar-agent smart-account <verb>` or via the shorter `sa` alias. Administration of an on-chain OpenZeppelin smart-account: context rules, signer sets and thresholds, policy contracts, supporting infrastructure (verifier registry, multicall router registry, upgrade timelock), and multicall submission. Context-rule-authorized operations sign the smart-account auth digest, binding the authorizing rule ids. Timelock writes use direct G-key Soroban authorization. Signing verbs take a signer source (exactly one of `--signer-secret-env <VAR>` or `--sign-with-ledger`, plus `--account-index <INDEX>`, default `0`). Most on-chain signing verbs structurally refuse `mainnet`. `--output` is available on `rules`, `execute`, `list-rules`, `list-verifiers`, `list-intents`, `deploy-webauthn-verifier`, `deploy-ed25519-verifier`, `deploy-spending-limit-policy`, and `deploy-policy` (`json` default, `table` where offered). The `signers`, `timelock`, `migrate-verifier`, `multicall`, `register-multicall`, and `unregister-multicall` verbs do not accept it.

Every verb's exact flags, the mainnet-refusal matrix, signer-kind discriminators, WASM-hash pinning and override flags, and worked examples live in [`smart-accounts.md`](smart-accounts.md). Per-verb index:

| Verb | Purpose |
|---|---|
| `rules create` | Install a context rule; returns the minted `rule_id`. At least one signer required; `--signer-delegated` takes a G-strkey or a C-strkey. The confirmed rule is recorded as its signer-set baseline, or the command exits `sa.install_state_mismatch` / `sa.baseline_write_failed` with the rule on chain |
| `rules get` | Read one rule (read-only, mainnet OK) |
| `rules set-name` | Rename a rule |
| `rules set-valid-until` | Change a rule's expiry ledger |
| `rules delete` | Remove a rule |
| `rules verify-pins` | Verify pinned verifier/policy WASM hashes vs on-chain in all 32 bytes (drift; read-only, exit `1` on drift); reports `pinned_*_hashes` / `observed_*_hashes` as full hex and names pinned and observed external-reference executables; a pin record of eight-byte prefixes reports `unavailable` with `sa.wasm_pin_incomplete` |
| `rules add-policy` | Attach a policy (`--kind raw`/`spending-limit`/`simple-threshold`/`weighted-threshold`); cap 5. Needs a matching version-2 baseline of the rule for any policy, compared under the rule's lock. On a pinned rule the new policy is probed and pinned (`--accept-mutable-verifier` / `--accept-unknown-verifier`). The simple-threshold policy records `SaThresholdChangedV2` |
| `rules remove-policy` | Detach a policy by id; needs a matching version-2 baseline of the rule for any policy, compared under the rule's lock; on a pinned rule its pin is dropped. The simple-threshold policy records its cleared threshold; removing one of two simple-threshold policies repairs the rule, and removing a third policy from such a rule refuses with `sa.threshold_policy_identification_failed` |
| `rules list` / `list-rules` | Enumerate active rules by on-chain scan (read-only, mainnet OK); each rule's `baseline` (`none`, `v1`, `v2`, `unreadable`, `unknown`) is its signer-set baseline in the audit log, and a rule reporting `none` refuses signing until `signers list --rule-id N` |
| `rules get-spending-limit` | Read an installed spending-limit policy's rolling-window budget (read-only; amounts are decimal strings) |
| `rules set-spending-limit` | Retune a spending-limit cap without resetting history. `--auth-rule-id` default 0: the retuned CallContract rule cannot authorize its own retune: name an admin-capable rule. Period is immutable |
| `signers list` | Read the on-chain signer set; baselines if none, otherwise reports `baseline` (`matched`, `diverged`, `not_comparable`) |
| `signers refresh` | Compare with the signer-set baseline and re-anchor it; run it once on a rule reporting `v1` (`sa.signer_set_baseline_legacy`); a changed set needs `--accept-divergence`. Pins a live verifier when the record pins none (`sa.pinned_verifier_absent`). Probes as `rules create` does (`--accept-mutable-verifier` / `--accept-unknown-verifier`), and refuses to pin a verifier the allowlist marks revoked or retired (`sa.verifier_wasm_revoked` / `sa.verifier_wasm_retired`); repair such a rule with `migrate-verifier` to an allowed verifier, or remove the rule. With no `External` signer, drops the sole verifier pin. Reports `verifier_pinned` |
| `signers add` | Add one signer (cap 15). `--signer-ed25519` is the recommended agent-key shape. On a pinned rule, writes `SaContextRulePinsUpdatedV2` for an External signer, one pin per distinct full hash and executable reference; `--accept-mutable-verifier` / `--accept-unknown-verifier` apply to a new verifier. A simulated return value that is not the new signer id refuses before signing (`sa.deployment_failed`). Completes a `migrate-verifier` pair from its `pending_add.recovery_command` |
| `signers remove` | Remove a signer; refuses if it would drop below threshold, and on a rule whose policies include no simple-threshold policy (`sa.threshold_policy_identification_failed`) |
| `signers set-threshold` | Change a simple-threshold policy's threshold (authorizer is `--rule-id`) |
| `signers set-weighted-threshold` | Change a weighted-threshold policy's threshold (use an admin `--auth-rule-id` when `--rule-id` is scoped) |
| `signers set-signer-weight` | Change one signer's weight in a weighted-threshold policy |
| `signers batch-add` | Add multiple signers in one transaction (cap 15). A rule without a simple-threshold policy accepts a batch. Pin-record update and override flags as `signers add` |
| `execute` | Submit one `CallContract` invocation authorized by a rule and signed by an External-Ed25519 rule signer (the delegation verb); `--auth-rule-id` has NO default; no MCP equivalent. Refuses before signing with `sa.signer_set_missing_baseline` when a rule has no signer-set baseline, and `sa.audit_log` on an audit-log integrity error. It refuses with `sa.verifier_hash_drift` / `sa.policy_hash_drift` when a rule's verifier or policy differs from its pin, and `sa.pin_check_unavailable` when the drift check cannot run. `sa.pinned_policy_absent` refuses a rule whose record holds policy pins while the rule has no policy on chain. `sa.pinned_verifier_absent` refuses a rule holding an `External` signer while its record pins no verifier. `sa.verifier_wasm_revoked` / `sa.verifier_wasm_retired` refuses a rule whose pin record pins a verifier hash the allowlist marks revoked or retired. `sa.signer_set_diverged` refuses a rule whose signers differ from its baseline |
| `multicall` | Submit an atomic bundle of 1 to 50 invocations through the registered router; requires `--secondary-rpc-url` (flag or profile, else `smart_account.ledger_witness_unavailable`). Requires `policy.engine = "v1"`: the bundle is evaluated as `wallet_multicall` against the profile's signed policy, a Noop profile refuses with `policy.engine_required`, and a policy that cannot load refuses with `policy.engine_unavailable`. A policy refusal or a refused pre-submission check of a `--rule-id` other than `0` is `sa.multicall_failed` at phase `policy_gate` |
| `deploy-webauthn-verifier` | Deploy the OZ WebAuthn-verifier WASM; idempotent; testnet only |
| `deploy-ed25519-verifier` | Deploy the OZ Ed25519-verifier WASM (backs `--signer-ed25519`); testnet only |
| `deploy-spending-limit-policy` | Deploy the OZ spending-limit-policy WASM (per-network singleton); testnet only |
| `deploy-policy` | Deploy any of the three OZ policy contracts via one `--kind`; recommended; testnet only |
| `migrate-verifier` | Move all External signers from one verifier to another across rules; mainnet submit refused, mainnet dry-run allowed. Each remove/add pair runs under the rule's lock against its version-2 state and records `SaSignerRemovedV2`, `SaContextRulePinsUpdatedV2` (pinned rule, names the destination's full hash), `SaSignerAddedV2`, `SaVerifierMigrated`; checks each migrating rule's policies before signing. A failure after a removal was sent returns `pending_add` and prints the `signers add` (or refresh then add) that completes the pair |
| `list-verifiers` | Enumerate the compile-time verifier allowlist and audit-status taxonomy (read-only, no network) |
| `list-intents` | List the profile's signed smart-account intents from the verified window state (read-only, mainnet OK, writes nothing) |
| `register-multicall` / `unregister-multicall` | Edit the local multicall-router registry |
| `timelock schedule` / `cancel` / `execute` / `list-pending` | OpenZeppelin upgrade-timelock lifecycle; write verbs refuse `mainnet`, `list-pending` is read-only |

Flags for every verb: see [`smart-accounts.md`](smart-accounts.md).

---

## DeFi: vault, trade

`vault deposit`, `vault withdraw`, and `trade` are signing commands. Before signing, each loads the profile and refuses a mainnet profile with `network.mainnet_write_forbidden` before signer access and any RPC call. It then pins the target contract by WASM hash, evaluates the operator policy engine, and signs and submits. The pin uses a two-RPC cross-check when `--secondary-rpc-url` or the profile sets a secondary RPC. A `Deny` refuses `policy.deny.<code>`. A `RequireApproval` refuses `policy.approval_required`, because neither the CLI nor the MCP server has an approval path for these verbs. The MCP tools refuse the same decision with `policy.approval_required_unsupported`. An unbuildable engine refuses `policy.engine_unavailable` (fail closed). These commands do not accept `--output`; they always emit JSON. Per-network contract pins constrain them as well. DeFi amounts are raw integer base units (no decimal/unit string).

Every venue's flags, trust gate, refusal codes, and examples live in [`defi.md`](defi.md). Per-verb index:

| Verb | Venue | Purpose |
|---|---|---|
| `vault deposit` | DeFindex | Deposit into a DeFindex vault; `--amounts-min` required; upgradable-vault refusal |
| `vault withdraw` | DeFindex | Redeem shares from a DeFindex vault; `--min-amounts-out` required |
| `trade` | Soroswap | Swap via the Soroswap router; price discovery is inside `trade` (no separate `quote`) |

Flags for every verb: see [`defi.md`](defi.md).

---

## pool

The channel pool is a set of channel accounts derived from a single pool master seed at `m/44'/148'/<index>'`, used to submit transactions concurrently (not a DeFi venue). The master seed lives only in the OS keyring; channel private keys are re-derived on demand. Subcommands: `init`, `list`, `status`. All accept `--profile` (resolves `--profile` → `STELLAR_AGENT_PROFILE` → `default`) and `--output` (`json` default or `table`).

| Verb | Purpose | Extra flags |
|---|---|---|
| `init` | Fund `N` channels via one CAP-33 sponsored-reserve sandwich; signing. The master seed and a public `[pool_initialization]` checkpoint are persisted before the transaction is sent; `--resume` completes a pending initialization with the same keys. Refuses if a master exists (message `pool.already_initialised:`, fail-closed on ambiguous probe) unless `--force` (which orphans prior channels); `--force` refuses while initialization is pending. | `--size <N>` (required unless `--resume`, `1..=19`); `--force`; `--resume`; `--timeout-seconds` (default `120`) |
| `list` | List channels (BIP-44 index, public G-strkey, live sequence). Read-only; requires an initialised pool (else `internal.unexpected_state` with `pool.not_initialised:`). | — |
| `status` | Report `initialised`, `pool_size`, `free`, `in_flight`. Read-only, no network (reads persisted `PoolConfig`). While initialization is pending, reports `resume_with`, and `clear_with` for an ambiguous or failed receipt. `in_flight:0` is not "safe to flood"; it reflects a stateless process. | (none) |

Pool refusals surface as `error.code` `internal.unexpected_state` with the specific reason (e.g. `pool.size_out_of_range:`, `pool.already_initialised:`) in `error.message`.

```bash
stellar-agent pool init --size 5 --profile default
```

---

## profile

Creates, lists, shows, and migrates profiles, manages their keyring references,
and halts and resumes a profile's agent actions.
A profile is a per-environment TOML config with schema version 2.
Keyring references hold no keys, though endpoint URLs can embed credentials.
These commands use the `{ok, data, request_id}` envelope.

`init`, enrollment, and `sign-policy` accept `--profile <NAME>`.
Selection resolves through `--profile`, `STELLAR_AGENT_PROFILE`, then `default`.
Mainnet selection requires an explicit flag.
`show`, `migrate`, rotation, `reset-window-state`, `reset-mpp-state`, `halt`, and
`resume` accept exactly one selector:
a positional name or `--profile`, without a default.
`list` takes none. `enable-mainnet` requires an explicit nondefault profile.
`reset-mpp-state` requires `--acknowledge`; `enable-mainnet` offers `--check` and
`--rotate`. These commands operate on local configuration and keyring state.

| Verb | Form | Notes |
|---|---|---|
| `init` | `profile init --profile default --network testnet` | Writes a profile; see below. |
| `list` | `profile list` | Read-only. Returns known profile names sorted as a JSON array. Takes no profile selector. |
| `show <NAME>` | `profile show default` | Read-only. URL fields (`rpc_url`, `secondary_rpc_url`, `oracle_provider_url`) show scheme, host, and port only. Resolved config; keyring refs appear as opaque `{service, account}`, secrets never read. Exits `1` with `validation.profile_not_found` when the profile does not exist. A mainnet file without `rpc_url` exits with `validation.mainnet_rpc_url_required`. An invalid provider attestation exits with `validation.provider_attestation_invalid`; correct the named field in the profile file. An endpoint URL that breaks the endpoint rule, an unsupported schema version, or another unreadable file exits with `validation.config_invalid`. Also reports `halted`, `halted_at`, and `halt_reason`; an unreadable halt marker shows `halted: true` and `halt_marker_error`. |
| `migrate <NAME>` | `profile migrate default` | State-changing (atomic temp+rename). No-op if already current (`status:"no_op"`); else `status:"migrated"` with `from_version`/`to_version`/`path`. A refused migration exits `1`, writes nothing, and leaves the v1 file unchanged. A missing profile file: `validation.profile_not_found`. A v1 mainnet file without `rpc_url`: `validation.mainnet_rpc_url_required`, because mainnet has no default endpoint; add `rpc_url` to the v1 file and run the command again. An endpoint URL that breaks the endpoint rule, or a file that cannot be read: `validation.config_invalid`. |
| `enroll-signer` | `profile enroll-signer --profile default --secret-env WALLET_SK` | State-changing (keyring, and the profile TOML when the account is still a placeholder). Imports the operator's `S...` ed25519 seed from the named env var and stores it verbatim at the profile's `mcp_signer_default` coordinate (the signer every MCP fund-movement tool and keyring-signing CLI verb resolves). Classification uses the raw on-disk value: the literal placeholder `"default"` is pinned to the derived G-strkey (only that key is patched); a pinned G-strkey mismatch refuses; any other value refuses as malformed (`enroll_signer.account_malformed`). `--secret-env <VAR>` (required, the variable name), `--profile <NAME>` (resolves `--profile` → `STELLAR_AGENT_PROFILE` → `default`), `--expected-address <G_STRKEY>`, `--force`. |
| `enroll-rpc-credential` | `profile enroll-rpc-credential --profile default --role primary --header X-API-Key` | State-changing (keyring, and the profile TOML when the record names no reference). Stores an RPC provider key at the keyring entry the role's provider record names, or at the default `stellar-agent-rpc-<profile>` / `<role>`, and adds `credential` and `placement` to a record without them. Reads the key from a hidden prompt, or from standard input with `--stdin`; the key is never printed. The role's URL and record must exist; the loader's credential checks run on the record before anything is written. `--role <primary\|secondary\|oracle>` (required), `--header <NAME>` \| `--query <NAME>` \| `--path` (required when the record names no placement), `--stdin`, `--force`. Refusals: `enroll_rpc_credential.record_missing`, `.placement_required`, `.placement_mismatch`, `.entry_exists`, `.terminal_required`, `.input_unreadable`, `validation.provider_attestation_invalid`, `network.rpc_credential_refused`. See [Provider credentials](profiles-and-keys.md#provider-credentials). |
| `enroll-owner-key` | `profile enroll-owner-key --profile default --secret-env WALLET_OWNER_SK` | State-changing (keyring). Derives the owner ed25519 PUBLIC key from an operator `S...` seed and stores it at `policy_owner_key_id` (the key the V1 engine verifies against) as its G-strkey, a form no 32-byte symmetric-key loader accepts. Owner readers refuse older base64 entries; enroll the owner public key again after upgrading. The seed is never stored. `--expected-address`, `--force`. When an enablement nonce or a policy pin exists at the profile's window-state entry, or an enablement nonce exists at its default entry, whatever chain the profile file names, a key other than the pinned owner requires an installed policy carrying a valid previous-owner rotation statement; re-enrolling the pinned owner's key needs none. |
| `halt <NAME>` | `profile halt default --reason "agent sent unexpected payments"` | State-changing (writes the halt marker and one audit row). Operator-only. See [Profile halt and resume](#profile-halt-and-resume). |
| `resume <NAME>` | `profile resume default` | State-changing (writes one audit row and removes the halt marker). Operator-only. |
| `sign-policy` | `profile sign-policy --profile default --secret-env WALLET_OWNER_SK` | State-changing (writes the policy file, atomic). Signs `<state_dir>/policies/<profile>.toml` (or `--file`) with the owner seed and writes the `[signature]` table. Older base64 entries refuse with `sign_policy.owner_key_older_form`; enroll the owner public key again. Mismatch errors identify enrolled bytes by fingerprint. Requires the enrolled seed, or `--previous-owner-secret-env VAR` to authorize the new owner with the previous seed, which must match the pinned owner, or the enrolled owner when no pin exists. |

`profile init` writes a new profile TOML with per-profile keyring references.
The signer and nonce accounts start as `"default"` placeholders. It reports
enrollment next steps, mints no key material, and emits no audit row.

`--profile <NAME>` resolves through `STELLAR_AGENT_PROFILE`, then `default`.
`--network <testnet|mainnet>` defaults to `testnet`. `--rpc-url <URL>` is optional
on testnet and required on mainnet, which has no default endpoint.
`--engine <v1|noop>` defaults to `v1`. Mainnet profiles receive
`classic_max_fee_per_op_stroops = 10000`.

On V1, the MCP server starts once the owner key is enrolled and the
owner-signed policy loads. The rest of the
[V1 setup](profiles-and-keys.md#opt-in-to-v1) gates approvals and signing.
A testnet `noop` profile supports server startup and read access immediately.
Mint the audit key with `profile rotate-audit-key` before
`profile enroll-signer` so enrollment writes its audit row. Then run
`profile rotate-nonce-key` before MCP payment simulation.

The flag parser refuses a malformed or credential-bearing `--rpc-url` with
exit `1` and `validation.usage_error`. Later refusals also exit `1` and write
nothing. In order, these are an unsafe profile name
(`validation.config_invalid`), a missing mainnet endpoint
(`validation.mainnet_rpc_url_required`), and an existing profile
(`validation.profile_already_exists`). An endpoint that breaks the URL rule
then refuses with `validation.config_invalid`. The rule requires `http` or
`https`, and on mainnet `https` with no username or password. A failed write
exits `1` with an internal error.

`enroll-signer` reads the signer seed from the shell environment. `enroll-owner-key`, `sign-policy`, and `bind-signer` read the owner seed from that environment. The operator supplies each seed as [Pass a secret seed](https://github.com/Soneso/stellar-agent-wallet/blob/main/docs/getting-started.md#pass-a-secret-seed) shows, only for those commands, and unsets it afterward. Of the policy owner key, the MCP server holds only the enrolled public key. It reads no seed from its environment.

### `profile bind-signer`

```bash
stellar-agent profile bind-signer --profile operator --owner-secret-env WALLET_OWNER_SK
unset WALLET_OWNER_SK
```

Binds an enrolled mainnet signer to its profile, chain, seed coordinate and
established owner. Both flags are required: `--profile <NAME>` selects the
profile and `--owner-secret-env <VAR>` names the environment variable holding
the owner's S-strkey. The owner signs the binding through the protected seed
ceremony. The agent seed is never read. A valid binding to this owner stays
unchanged and returns `bound: false`; a write returns `bound: true`.

The signer service must be `stellar-agent-signer-<NAME>` and its account must
pin a G-strkey. The record must name that key, and any v2 binding must name
this profile and chain. The owner seed must match the policy pin's owner when
a pin exists, otherwise the enrolled owner public key. A profile rename or
copy cannot adopt the signer's binding.

The five binding refusals are:

- `profile.bind_signer_mainnet_required`: the profile is not mainnet.
- `profile.bind_signer_coordinate_not_canonical`: the signer service is not canonical.
- `profile.bind_signer_record_conflict`: the account is not a G-strkey pin, the record is absent or malformed, or it names another key, profile or chain.
- `profile.bind_signer_owner_mismatch`: the owner seed differs from the established owner.
- `profile.bind_signer_owner_is_signer`: the owner key equals the agent key.

Seed-loading errors also refuse. A keyring failure keeps its `auth.keyring_*`
code; a window-state lock, policy pin or owner-entry content failure refuses
with `profile.bind_signer_storage`. After an owner rotation advances
the policy pin through the verified rotation statement, run this verb with
the new owner's seed to rebind. The old owner's seed refuses. The
`signer_identity_enrolled` audit row uses tool `profile_bind_signer`.

Mainnet setup runs `enroll-signer`, `enroll-owner-key`, `sign-policy`,
`bind-signer`, then `enable-mainnet`. Existing mainnet enrollments need
`bind-signer` once before signing or starting an enabled MCP server.

### `profile enable-mainnet`

```bash
stellar-agent profile enable-mainnet --profile operator
stellar-agent profile enable-mainnet --profile operator --check
stellar-agent profile enable-mainnet --profile operator --rotate
```

Requires an explicit, nondefault mainnet profile, matching stored and merged
chain and RPC URL, engine v1, an enrolled owner key and signer identity, an
oracle, and no key-scope findings. A profile without `oracle_provider_url` is
refused with `profile.mainnet_oracle_required` before any keyring entry is
read, and no nonce, pin, policy change, or audit row is written. A profile
that sets `oracle_provider_url` without its `providers.oracle` record does not
load, and the ceremony refuses it with `profile.enable_mainnet_precondition`
and the loader's message.
An enabled profile whose oracle is removed refuses every CLI mainnet write
with `profile.mainnet_oracle_required` before any signature, until the oracle
is set again. A running MCP server checks the profile it loaded at startup,
and its freshness check does not read the oracle fields. It refuses mainnet
writes for a removed oracle from its next start. Before the first nonce is written, a signed v2 policy
establishes the pin with its verified sequence, digest, and owner.
Create and sign that policy before running the ceremony; it may omit `[mainnet]`.
A v1 policy refuses with `profile.enable_mainnet_precondition` and
`sign a v2 policy before enabling mainnet`; an unsigned policy refuses with
`policy.policy_file_parse_failed`. Neither writes a nonce, pin, or audit row.
An existing pin stays in place, including during nonce rotation.
The ceremony records `mainnet_enablement_minted` through the
strict audit writer, stores an installation nonce, then atomically rewrites
the policy with the profile, normalized endpoint host, and nonce digest.
The operator supplies the fee cap, optional authorization
TTL, and thresholds, then signs the policy as the output's `next` list directs.

See [the policy schema and minimum](profiles-and-keys.md#mainnet-policy-body) for
required signed fields and rules. After enablement, complete and sign the
policy, run `--check`, and restart the MCP server.

Binding failures name `mainnet_table`, `profile`, `source`, `default`, `on_disk`,
`chain_id`, `on_disk_host`, `merged_host`, or `nonce_digest`. The signed policy
field remains `endpoint_host`. Unreadable stored `chain_id` or `rpc_url`
reports `profile chain and endpoint unreadable` with the path and cause.

`--rotate` replaces the nonce and changes only the policy's nonce digest.
The old nonce is gone; sign the updated policy before using its binding.
On a policy without a `[mainnet]` table, `--rotate` binds in full, as the
first run does. This recovers a run that stored the nonce but could not
rewrite the policy. In a build without `mainnet-write`, the `next` list adds
that writes require such a build.

An installation that holds a nonce but no pin refuses every mainnet write,
and the ceremony refuses it with `policy.pin_absent`, with and without
`--rotate`, before writing anything: no wallet command establishes the pin of
an enabled installation. To recover, the operator removes the keyring entry
with service `stellar-agent-policy-window-<NAME>` and account
`default-mainnet-enablement` with the platform keyring tool, such as Keychain
Access on macOS, Seahorse on Linux, or Credential Manager on Windows. Then
`profile enable-mainnet --profile <NAME>` pins the installed signed policy and
stores a new nonce, and the owner signs the rebound policy at a higher
sequence; mainnet writes stay refused until then. That enablement trusts the
installed signed policy and its owner, as the first enablement of a new
installation does.
When only the policy-state lock file is missing and the pin entry exists,
the refusal names the lock file instead: a command that builds the V1 policy
engine, such as starting the MCP server, recreates it, and the nonce stays.

`--check` reports every check with the status `passed`, `failed`, or
`not_evaluated` and a detail, and exits `1` when any check failed. The checks
are the preconditions, `verified_policy`, `pin`, `enablement`, every minimum
restriction in either build, and `oracle_provider_url`. The last fails when
the profile names no oracle, and its detail names what is missing. `--check`
reads the prerequisite state, keyring entries included, and writes no nonce,
pin, policy change, or audit row.
The restrictions are evaluated on the
document the verified load read. Without a `[mainnet]` table the fee cap and
every table restriction fail. When the policy does not verify, the
restrictions and `enablement` are `not_evaluated`. The `enablement` check
fails with `profile.mainnet_enablement_invalid` and the name of the binding
that does not match, such as `on_disk_host` or `nonce_digest`. The `pin`
check passes with the pinned sequence, or with `absent (first use)` when no
pin or window-state lock file exists and no enablement nonce exists.
An enablement nonce with no pin refuses with `policy.pin_absent`.
It fails when the pin cannot be read or
the comparison refuses, with `policy.sequence_rollback`,
`policy.sequence_fork`, `policy.owner_rotation_required`,
`policy.owner_rotation_invalid`, or the lock or pin error in its detail.
`--check` creates and changes nothing: no window-state directory or lock
file, and no policy, owner key, nonce, pin, or audit row.

Exits `1` on refusal:

- `profile.enable_mainnet_profile_flag_required`: supply `--profile`.
- `profile.enable_mainnet_default_refused`: select a dedicated profile.
- `profile.enable_mainnet_not_mainnet`: the selected chain is testnet.
- `profile.enable_mainnet_precondition`: a named precondition or effect failed.
- `profile.enable_mainnet_nonce_exists`: rerun with `--rotate` to replace the nonce.
- `policy.pin_absent`: the installation holds a nonce but no pin; see the recovery above.
- Strict audit errors retain their own codes.

### `profile sign-policy`

Sign the policy with the enrolled owner identity:

```bash
stellar-agent profile sign-policy --profile operator --secret-env WALLET_OWNER_SK
```

V2 signing assigns `max(pin, body) + 1`, returning `sequence` and
`previous_sequence`. Signing does not advance the pin; a verified load can.
It creates no window-state directory or lock file. V1 warns about mainnet v2
requirements and pin rollback. A refusal names the policy file and leaves it
unwritten. Pin and lock errors retain their `policy.*` codes. Signing does
not check owner continuity: `policy.pin_absent`,
`policy.owner_rotation_required`, and `policy.owner_rotation_invalid` are
refusals of the verified load that follows.

To change the owner of a profile with a policy pin, follow
[Rotate the policy owner](profiles-and-keys.md#rotate-the-policy-owner).
An owner change advances the pin only through the verified load of a policy
that carries the previous owner's statement.
`--previous-owner-secret-env` supplies the previous seed, which must match the
pinned owner, or the enrolled owner when no pin exists.

`profile enroll-signer --repair-identity` repairs the seed-free identity record.
It requires the stored public-key pin and verifies the existing seed against it.
A version 1 record refuses because repair does not prove ownership. On testnet
it needs a new enrollment with `--force`; on mainnet it needs
`profile bind-signer`. A record that names another key or role, or holds
malformed data, refuses and the repair writes nothing. Remove that entry, then
run the repair again. Enrollment refuses a foreign binding even with `--force`
(`enroll_signer.identity_bound_elsewhere`) and a noncanonical mainnet signer
service (`enroll_signer.coordinate_not_canonical`).
Incomplete identity uses `profile.enroll_signer_identity_incomplete`.
Missing pin uses `enroll_signer.repair_unpinned`; conflicts use
`enroll_signer.identity_conflict`. Enrollment and repair record
`signer_identity_enrolled`.

### Profile halt and resume

`profile halt <NAME> [--reason <REASON>]` is the operator's emergency stop. It loads the profile, then writes `profiles/<name>.halt` in the data directory with `halted_at` and the reason, and records a `profile_halted` audit row. A profile that does not load is refused with the profile's load or reconciliation code and gets no marker; the reason is examined only after the profile loads. The marker is written before the row, so the halt holds even when the row cannot be written; `audit_row` in the result reports `written`, `queued`, or `not_written`. Halting again rewrites the marker. A blank `--reason` refuses with `validation.reason_empty`; one over 128 characters or with a control character refuses with `validation.reason_invalid`. A marker write or removal failure refuses with `io.halt_marker`.

While the profile is halted, these refuse with `profile.halted` (exit `1`), before reading a signer or sending a request: `pay` and `claim` (each except `--build-only`), `accounts create` in both modes, `accounts deploy-c`, `trustline`, `trade`, `vault deposit` and `withdraw`, `mpp charge authorize`, `pool init`, `smart-account multicall` and `execute`, the `rules` and `signers` write verbs, `migrate-verifier` (except `--dry-run`), the four `deploy-*` commands, and `timelock schedule`, `cancel`, and `execute`. The MCP server refuses every tool that is not read-only from its next call. Read-only commands, `profile show`, `audit verify`, `profile sign-policy`, the `enroll-*` and `rotate-*` subcommands, `approve`, and the verbs that only record or reconcile local state (`mpp receipt record`, `mpp settlement reconcile`, `mpp state prune`, `tx status`) keep working. An unreadable marker refuses the same actions with `profile.halt_unreadable`.

`profile resume <NAME>` loads the profile, reads the marker, appends a `profile_resumed` row, and removes the marker only after the row is committed. On a halted profile a marker that cannot be read, such as a directory at its path, refuses with `profile.halt_unreadable` and writes no row; the operator repairs the file or removes the path by hand. A row that cannot be appended refuses with its audit code and keeps the marker. A marker that cannot be removed after the row refuses with `io.halt_marker` and keeps the halt; fix the file and run `profile resume` again. A `profile_resumed` row records that the command ran; the marker file decides the state, and exit `1` means the profile is still halted. Resuming a profile that is not halted exits `0` with `halted: false` and `was_halted: false`.

```text
profile "default" is halted since 2026-10-31T12:00:00Z: agent sent unexpected payments; run "stellar-agent profile resume --profile default" to lift it
```

An agent that meets `profile.halted` stops and reports the message to the operator. It never runs `profile resume` itself.

### Key-rotation subcommands

Each generates a fresh 32-byte CSPRNG secret, atomically replaces one named keyring entry, and is not reversible. Each takes the profile as either a positional `<NAME>` or a `--profile <NAME>` flag (exactly one) and returns `profile` + `rotated`; some add `key_kind`.

The policy-file owner key is NOT rotated here — it is an ed25519 key enrolled with `enroll-owner-key` (public key stored) and used by `sign-policy` (seed supplied at sign time). All rotation subcommands below mint 32-byte HMAC keys.

| Subcommand | Keyring entry | Effect |
|---|---|---|
| `rotate-attestation-key` | approval-spine attestation HMAC (`attestation_key_id`) | Invalidates all pending approvals; the simulate-and-approve round trip must be re-run. `key_kind:"hmac_32_bytes"`. |
| `rotate-audit-key` | audit-log chain-root HMAC (`audit_log_hash_chain_key_id`) | Before any key write, checks the log's entry tags under the old key and refuses with that check's code (`audit.entry_tag_invalid` among them). Once entry tags are in force it appends `audit_entry_tags_rekeyed` (cause `rotation`) under the new key before its `keyring_key_written` row; an interrupted rotation is repaired at the next keyed open. Re-signs every existing per-file chain-root sidecar with the new key, so `audit verify <LOG_PATH> --profile <NAME>` stays green and the old key stops verifying. Adds `key_kind:"hmac_32_bytes"` and `sidecars_resigned`. Takes the audit writer's exclusive lock, so it refuses while an MCP server holds the writer. A changed audit binding refuses with `audit.log_binding_changed` before the writer opens. |
| `rotate-nonce-key` | HMAC nonce key (`mcp_nonce_key_alias`) | Invalidates outstanding nonces. Returns only `profile` + `rotated`. |
| `rotate-counterparty-key` | `stellar.toml` cache-integrity HMAC (`counterparty_cache_key_id`) | Invalidates cached bindings. `counterparty refresh <domain>` rewrites one binding, and `counterparty warm-up` refreshes only the `HOME_DOMAIN` entries of the policy allowlist. Adds `key_kind:"hmac_32_bytes"` and `cache_invalidated:true`. |
| `rotate-policy-state-key` | policy-window-state HMAC (`policy_window_state_key_id`) | Re-signs the persisted window-state store under the new key, so accumulated `per_period_cap` / `rate_limit` history is preserved, not invalidated. Rotation refuses if the store does not verify under the current key. Integrity failures and missing authenticated network provenance have no recovery verb in this release; create a profile under a new name. Before rotation, file I/O failures refuse without changing state; retry after access is restored. Adds `key_kind:"hmac_32_bytes"`. |

```bash
stellar-agent profile rotate-attestation-key default
```

`profile reset-window-state` clears verified persisted policy-window history.
Stop the MCP server and repair the audit log first. The command requires a usable keyed audit writer on every network,
including testnet. It acquires that writer before the window-store lock and
writes the reset row before minting a key, advancing the generation or replacing
the store. A reset whose row cannot be written does not happen.

An installation with a mainnet enablement nonce requires `--owner-secret-env <VAR>`
in every build, whatever chain the profile file names. The variable holds the
pinned policy owner's `S...` strkey; the flag takes its name, never the secret.
The seed is unlocked before audit acquisition. The store reads the nonce and pin
under its lock and verifies the owner's signature over the reset statement, so
the requirement holds for every caller of the store. A pin alone does not
require the flag.
When supplied, the seed must match the pin even without an enablement nonce.

Missing owner authorization refuses with `profile.reset_window_state_owner_required`.
A different seed refuses with `profile.reset_window_state_owner_mismatch`.
A supplied seed without a pin refuses with `policy.pin_absent`; an unreadable
pin refuses with `policy.pin_unusable`. A signature that does not verify over
the reset statement refuses with `profile.reset_window_state_signature_invalid`.
These refusals write no reset row and change no store, generation or key.
Owed accounting events the command delivers before the reset keep their rows
and acknowledgements when the reset refuses. Seed input errors report
`validation.secret_env_not_set`, `validation.secret_env_invalid` or
`wallet_state.unlock_failed` before acquiring either writer or store lock.

With the flag, the row adds `owner_authorization`: a redacted owner,
`store_sha256` (lowercase hex, or null for a missing file), `challenge` (64
lowercase hex characters) and a signature of 128 lowercase hex characters. The
pinned owner signs `window_reset_digest` over the profile, chain, store digest,
generation pair, bounded recorded reason, request id and challenge. The store
draws a new challenge of 32 bytes under its lock for every reset, so a
signature authorizes one reset of one store. The recorded reason is bounded to
50 Unicode characters before signing, and the signed and recorded bytes are
identical.
A reset without the nonce or flag omits this field.

The reset requires a current tip anchor before and after its row. If repair
fails, `audit.chain_key_unavailable` carries `audit.tip_anchor_unavailable`,
and the window state and generation remain unchanged. A reset row can therefore
describe an attempted reset that did not take effect.

The `policy_window_state_reset` row carries the profile's chain, reason and
`wiped` record. The JSON result carries the same record. A verified store reports
live confirmed and pending counts and totals, scope specificity, bucket and
window, plus generations before and after. Pending records count regardless of
age. At most eight buckets appear, with bounded identifiers and a truncation flag;
the entry count covers all live records. An absent file with no protected
generation establishes a new empty store and reports no totals.

The successor keeps every authorization record whose approval can still be
presented on the store clock. A reset preserves nonce reuse checks and prevents
a completed continuation from being repeated. A kept record holds no window
capacity, and a record that holds capacity becomes expired.
`wiped.retained_authorizations` counts the kept records and is absent when the
reset keeps none.

A missing file with protected history, an unusable key, an integrity failure,
or a generation mismatch refuses before the reset row and changes no file, key,
or generation. No verb recovers such state in this release; create a profile
under a new name. A different authenticated network refuses with
`policy.window_chain_mismatch`. Restore the profile's network, or create a
profile under a new name. Incomplete authenticated network provenance
refuses with `policy.window_chain_unverifiable`, including decoded versions 1 to 4.
No verb recovers missing provenance in this release; create a profile under a new name.
File I/O failures refuse without changing state; retry after access is restored.
An authenticated newer format version refuses on every chain with
`profile.reset_window_state_newer_version` and changes nothing; use the build
that wrote it. The reset releases expired authorizations in memory before it
writes the row.

An MCP server acquires the profile's audit writer at the first operation that
needs it, such as a commit preflight. It normally holds the writer until the
server exits. While a server holds it, reset refuses with
`audit.chain_key_unavailable` and the message sub-code `audit.writer_locked`.
An append failure also refuses with its audit code, leaving the window file,
key and generation untouched. A first-use key mint is recorded through the held
writer after the reset row, including when the later store write fails.

A failure after the row but before the generation write leaves the old store
readable; the row's `generation_after` exceeds the keyring generation. Run reset
again. Once the generation is written, the successor is committed, even when
the file still carries the old body beside it. A first reset, with no store file,
writes the generation before the file. A failure between those two writes leaves
a missing file with a committed generation. Reset refuses that state.
No verb recovers such state in this release; create a profile under a new name.
The reset is complete when the next command that opens the window store loads
the successor at `generation_after`. On a V1 profile, a value-moving command
and the MCP server's start open it. Generation equality alone does not establish
completion.
A blank `--reason` refuses with `validation.reason_empty` before anything changes.

A reset row without `wiped` or `owner_authorization` retains its serialized form
and verifies unchanged. A row with either field verifies with this release or
later. An older binary drops both fields when computing the row hash. It refuses
a log once a checked root HMAC, successor row or tip anchor covers the new row.
An uncovered tail can still be read by that binary with both fields dropped.
If it then appends a row, this release refuses the extended log at that row.
A `wiped` record without `retained_authorizations` keeps its serialized form.
An older binary drops that field when computing the row hash, with the same
consequences.

The counterparty cache reads and mints its HMAC key at
`counterparty_cache_key_id`, the entry `profile rotate-counterparty-key` writes.
With an explicit reference, previously cached entries read as absent until
a refresh rewrites them. `counterparty refresh <domain>` rewrites the entry
for that domain. `counterparty warm-up` refreshes only the `HOME_DOMAIN`
entries of the policy allowlist.

---

## credentials

WebAuthn passkey lifecycle for a profile. The registry holds only public metadata (credential name, redacted credential ID, RP-ID, transports, registration timestamp); the private key never leaves the authenticator. `credential_id` is redacted to first-five-last-five base64url. Uses the standard `{ok, data|error, request_id}` envelope; failures carry a `credentials.*` wire code.

Two common flags: `--profile <NAME>` (resolves `--profile` → `STELLAR_AGENT_PROFILE` → `"default"`), `--rp-id <DOMAIN>` (default `localhost`; set the deployment domain for a self-hosted deployment; IP literals rejected; changing it after registration breaks existing passkeys).

Closed set of `error.code` values across the group: the verb-specific codes in the table below, plus `credentials.invalid_profile_name` (any subcommand, malformed `--profile`), plus these codes shared from the underlying `CredentialsError`: `credentials.not_found`, `.duplicate_name`, `.invalid_name`, `.io_error`, `.registry_parse_failed`, `.registry_serialise_failed`, `.state_dir_unavailable`, `.approval_store_error`, `.approval_store_unavailable`, `.bridge_start_failed`, `.bridge_shutdown_failed`, `.atomic_write_failed`, `.signing_failed`, `.missing_public_key`, `.malformed_public_key`, `.registration_confirmation_mismatch`, `.registration_confirmation_expired`, `.audit_write_failed`, and a generic `.error` fallback. `add-passkey` additionally emits `.registration_tty_required`, `.registration_confirmation_canceled`, `.approval_store_dir_unavailable`, `.approval_store_open_failed`, and `.unknown_registration_outcome`, plus the audit refusals `audit.chain_key_unavailable`, `audit.log_binding_changed`, `audit.tip_anchor_mismatch`, and `audit.tip_anchor_missing`. Switch on `error.code`, never on `error.message`.

| Verb | Form | Notes |
|---|---|---|
| `add-passkey <NAME>` | `credentials add-passkey laptop-key --rp-id wallet.example.com` | State-changing; requires terminals on stdin and stderr (else `credentials.registration_tty_required`). It also requires the profile's keyed audit writer (else the `audit.*` refusal, before the ceremony). Prints the bridge registration URL to stderr, opens it in the browser through a private redirect file (the launcher never receives the URL), and polls. If the browser does not show the page, open the printed URL. The bridge verifies the browser's response against the challenge it served, the page's exact origin and the relying-party ID. It checks user presence and verification, and matches the posted credential ID and key against the authenticator's response. The page then shows a confirmation code, and the command asks for it at the terminal. Nothing is registered until the typed code matches; the `passkey_registered` row is written before the registry. A wrong code, the deadline at the prompt, and end of input or Ctrl-C at the prompt surface as `credentials.registration_confirmation_mismatch` / `credentials.registration_confirmation_expired` / `credentials.registration_confirmation_canceled`. Anyone with the URL can attempt registration while the bridge accepts it. Registration requires the code from the operator's own page to match the code typed at the terminal. Keep it out of shared logs. Ctrl-C during polling ends with `credentials.registration_user_canceled`. `<NAME>`: 1 to 64 printable ASCII, no `/ \ :`. Extra flags: `--timeout-seconds` (default `300`), `--accept-rp-id-binding-risk`. First registration prompts `[y/N]` with an RP-ID binding warning unless the flag is set. On success `data` carries the registered credential's metadata. Timeout, user cancellation, a missing approval-store entry, or a declined binding warning surface as `ok:false` with `credentials.registration_timeout` / `credentials.registration_user_canceled` / `credentials.registration_entry_missing` / `credentials.rp_id_binding_warning_declined`. |
| `list` | `credentials list` | Read-only. Lists registered passkeys for the profile+RP-ID under `data.credentials`. |
| `show <NAME>` | `credentials show laptop-key` | Read-only. Metadata incl. transports. Exits `1` with `credentials.not_found` when not found. |
| `delete <NAME>` | `credentials delete laptop-key --yes` | State-changing; prompts `[y/N]` (skip with `--yes`/`-y`). Does not remove the on-chain signer. Declining exits `1` with `credentials.delete_canceled`. |

---

## approve

The operator-side half of the approval spine. When a signing-adjacent action needs out-of-band approval, the agent surface records a pending approval and returns an approval nonce. The wallet owner runs `approve --id <NONCE> --profile <name>` in a separate trusted context to inspect a wallet-controlled summary and consent. A payment, claim, or trustline summary is decoded from the authoritative envelope the approval attests, not from anything the agent supplied. Approval is bound to the local user (recorded process uid must match at approve time). Uses the `{ok, data, request_id}` envelope.

### `approve --id <NONCE> --profile <name>`

State-changing (records an HMAC attestation, or for a toolset first-invoke gate mints a toolset grant and consumes the entry).

| Flag | Meaning |
|---|---|
| `--id <NONCE>` (required in this form) | Approval nonce from the agent surface's simulate response |
| `--profile <NAME>` | Profile whose attestation key + pending-approval store to use (resolves `--profile` → env → `default`) |
| `--yes` | Non-interactive auto-approve on a testnet profile; the summary is still printed. A mainnet profile refuses it before store access with `approve.yes_refused_on_mainnet` |

On a mainnet profile the command prints the summary and opens the local passkey page; it reads no terminal input. On a testnet profile it interactively prompts `Approve? [y/N]:`; anything other than `y`/`yes` denies. Exits `1` when the nonce is unknown, expired, already attested, created by a different local user, denied, or on I/O error. For payment-style approvals the response returns `approval_attestation` (the HMAC blob the agent must pass as the `approval_attestation` argument to the matching `*_commit` tool); omitted for kinds whose gate reads recorded consent directly (toolset first-invoke grants, trustline clawback opt-ins).

The `approval_attested` row is written before the approval is persisted. `audit` is `"written"`, or `"queued"` when a running MCP server or `approve serve` inbox holds the audit writer. That process appends the queued row to the log before any process loads a signing key for the approved action. The command exits `1` and persists nothing beside a process that does not drain the outbox (`audit.writer_locked`) and on any other audit failure. After upgrading, restart a running MCP server and `approve serve`: `approve --id` refuses beside an older one.

```bash
stellar-agent approve --id ABCxyzNonce --profile <name>
```

```json
{"ok":true,"data":{"approval_nonce":"ABCxyzNonce","attested":true,"process_uid":"501","expires_at_unix_ms":1717000000000,"approval_attestation":"q83vEjRWeJq83v...","audit":"written"},"request_id":"..."}
```

### `approve gc`

State-changing. Evicts every expired entry from the pending-approval store and reports the count (`evicted_count`). When `gc` is present, `--id` is ignored. Evicting zero is a success. `--profile <NAME>` selects the store.

```bash
stellar-agent approve gc --profile default
```

### `approve list`

Read-only. Enumerates pending approvals from the profile's store: opens it, renders a redacted snapshot, and exits. No keyring access, no network calls.

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Profile whose store to read | `STELLAR_AGENT_PROFILE`, else `default` |
| `--output <FORMAT>` | `json` (default) or `table` | `json` |
| `--include-expired` | Include already-expired entries instead of omitting them | `false` |

`data.profile` is present only when the name resolves to a saved profile, in `approve list` and `approve gc` alike. `data.expired_count` always reports the number of expired entries regardless of `--include-expired`, so the operator can tell whether `approve gc` is due even when expired entries are hidden.

For a consumed x402 approval, the tombstone's `tx_hash` holds the final-envelope digest. It is not a chain transaction hash. The digest hashes the final envelope's base64 text. JSON reports it redacted in `summary.tx_hash_redacted`. Its table row reads `spent (X402Payment), final-envelope digest <redacted digest>, outcome <outcome>`.

```bash
stellar-agent approve list --profile default --output table
```

### `approve serve`

Binds a loopback-only HTTP server with a local web UI for the pending-approval queue. The operator can review and approve or reject entries in a browser. Runs until Ctrl-C.

| Flag | Meaning | Default |
|---|---|---|
| `--profile <NAME>` | Profile whose store and attestation key to use | `STELLAR_AGENT_PROFILE`, else `default` |
| `--port <PORT>` | TCP port to bind on `127.0.0.1`, and on `[::1]` too for a mainnet profile; `0` picks an OS-assigned port | `0` |
| `--no-open` | Print the bootstrap URL instead of opening a browser | `false` |
| `--notify <on\|off>` | Best-effort OS toast notification when the queue grows | `on` |
| `--bell` | Emit a terminal bell alongside each queue-growth notice | `false` |
| `--include-expired` | Load the inbox with expired entries shown by default | `false` |

On start the server mints a single-use bootstrap token and prints a `http://127.0.0.1:<port>/bootstrap/<token>` URL. Opening it exchanges the token for a session cookie and an origin-scoped session proof that the page keeps in the tab, then shows the inbox. Mutating requests require the session cookie, an origin-scoped session proof, and a CSRF value. Another loopback service the browser visits can receive the cookie and read what it authorizes, but cannot approve or reject without the proof. The inbox session expires after 15 minutes without operator activity or 8 hours after bootstrap. Background polling does not extend it. Restart `approve serve` to establish a new session. Unless `--no-open` is passed, the browser opens through a private redirect file that only the current user can read, so the launcher never receives the bootstrap URL. If the browser does not open, use the printed URL. Until its first use or until the server stops, the printed URL grants an inbox session to whoever opens it, so keep it out of shared logs. Must run as the same OS user as the wallet's MCP server process: the attestation binds that user's id.

```bash
stellar-agent approve serve --profile default --port 7823
```

### `approve serve --remote`

Binds a TLS-protected, passkey-authenticated remote-approval surface instead of the loopback inbox, for approving from a device other than the wallet host. Refuses to start unless BOTH the profile has a `[remote_approval]` block with `enabled = true` AND `--confirm-remote-exposure` is also passed — the profile block alone is never sufficient consent. `--port` / `--no-open` / `--notify` / `--bell` / `--include-expired` are ignored in this mode.

| Flag | Meaning |
|---|---|
| `--remote` | Bind the remote surface instead of the loopback inbox |
| `--confirm-remote-exposure` | Required explicit consent, separate from the profile's `enabled` flag |

Every approve or reject on this surface requires a fresh WebAuthn passkey assertion bound to the exact pending entry, in addition to the session login. The remote surface serves testnet profiles only: on a mainnet profile it refuses to start with `approval.mainnet_remote_unsupported`. Approve or reject a mainnet request in the local inbox (`approve serve` without `--remote`). See `docs/remote-approval.md` in the wallet repository for the full setup guide (the `[remote_approval]` profile block, DNS/hosts-file requirements for `rp_id`, and the login/approve walkthrough).

```bash
stellar-agent approve serve --remote --confirm-remote-exposure --profile default
```

### `approve operator enroll`

Enrolls a WebAuthn passkey credential for the remote-approval surface. Runs entirely locally in both modes below — neither touches the network. Enrollment alone never authorizes the credential; its id must also be added to the profile's `[remote_approval] allowed_credentials` list.

A WebAuthn credential is bound to its `rp.id` at creation time, and a loopback origin can only claim `"localhost"` as an effective domain — that binding decides which mode applies:

- **`--interactive`**: for a loopback or SSH-tunnelled `approve serve --remote` listener. Needs a terminal on stdin and stderr (`approve.operator_enroll_tty_required` otherwise). Starts a one-shot local server and prints (and by default opens) an enrollment page. The printed URL carries a single-use bootstrap token. The first visit exchanges it for an HttpOnly session cookie and an origin-scoped session proof kept in the tab. Serving the page requires the cookie; both POSTs of the ceremony require the session cookie, the session proof, and a CSRF value. The page requests the server's single-use registration challenge (valid 300 seconds), the authenticator creates the credential over it, and the server verifies the `clientDataJSON` and the `none`-attestation `attestationObject` against that challenge, the exact origin, `rp.id` `localhost`, user presence and verification, and the posted id and ES256 key. A refused registration answers `registration_invalid`, an expired challenge `registration_expired`, a label that is empty, longer than 64 bytes, or holds a control character `label_invalid`. The verified credential is staged, not written. The command's prompt names the label with any control or format character shown as a visible escape. The page then shows a 16-hex-digit confirmation code in four groups; the command writes the credential only when the operator types that code before the timeout, and never prints the expected code. A wrong code (`approve.operator_enroll_confirmation_mismatch`), no code (`approve.operator_enroll_confirmation_canceled`), or a late one (`approve.operator_enroll_confirmation_expired`) writes nothing. The session expires after 15 minutes without operator activity or 8 hours after bootstrap. The server binds `127.0.0.1` and `[::1]` on one port before it mints the bootstrap token, serves the same session on both, and does not start when either cannot be held. The browser opens through a private redirect file, so the launcher never receives the bootstrap URL; if it does not open, use the printed URL. Until its first use or until the command ends, the printed URL grants an enrollment session to whoever opens it, so keep it out of shared logs. Ctrl-C before the page posts a credential stops the server, removes the redirect file, and exits `1` with `approve.operator_enroll_interactive_interrupted`. Always produces `rp_id: "localhost"`.
- **`--credential-id` / `--public-key` / `--rp-id` / `--label`** (all four together) — for a domain-configured remote listener. Imports the id and public key from a WebAuthn ceremony run elsewhere, normally the remote listener's own `GET /enroll` page (which has to be served from `https://<rp_id>` for the credential to bind to that domain, and displays a ready-to-run copy of this command).

| Flag | Meaning |
|---|---|
| `--profile <NAME>` | Profile whose operator-credential store to write; a name that is not a safe file name (absolute path, separator, `..`) refuses with `validation.config_invalid` |
| `--interactive` | Start the loopback ceremony (mutually exclusive with the three credential-import flags `--credential-id`/`--public-key`/`--rp-id`; `--label` still applies, as a page pre-fill) |
| `--no-open` | Print the enrollment URL instead of opening a browser (interactive mode only) |
| `--timeout-seconds <SECS>` | Interactive-ceremony timeout covering the browser registration and the terminal confirmation (default: 300) |
| `--credential-id <B64URL>` | Base64url WebAuthn credential id (16-64 raw bytes); import mode, requires the other three below |
| `--public-key <B64URL>` | Base64url-encoded 65-byte uncompressed SEC1 P-256 public key (`0x04 \|\| X \|\| Y`); import mode only |
| `--rp-id <HOSTNAME>` | Must match the profile's `[remote_approval] rp_id` exactly; import mode only |
| `--label <LABEL>` | Operator-chosen name for the credential (e.g. `"laptop"`); required in import mode, optional page pre-fill in interactive mode |
| `--sign-count <U32>` | Best-effort sign-counter seed read at enrollment time; import mode only (interactive mode extracts it automatically). Advisory only — never affects authorization |

```bash
# Local or SSH-tunnelled listener
stellar-agent approve operator enroll --interactive --label laptop

# Domain-configured remote listener: import a credential enrolled via its own /enroll page
stellar-agent approve operator enroll --credential-id <B64URL> \
  --public-key <B64URL> --rp-id wallet.example.internal --label laptop --sign-count <N>
```

Every write to the operator-credential store (enrollment, removal, and the sign-count update after a remote login) holds the store's lock file. A writer that cannot take it writes nothing. Interactive enrollment and `remove` refuse with `approval.writer_locked`; argument-mode enrollment refuses with `internal.unexpected_state`, whose message names `approve.operator_enroll_failed`; a remote login answers `400` `webauthn_assertion_invalid`, like every refused login. In each case the operator retries.

### `approve operator remove`

Removes an enrolled operator credential from the profile's operator-credential store. Prints `{"removed": true}` when a record was removed and `{"removed": false}` when none had that id; both exit `0`. Never prints the credential id and never edits the profile. Lock contention refuses with `approval.writer_locked`, any other store failure with `approve.operator_remove_failed`.

| Flag | Meaning |
|---|---|
| `--credential-id <B64URL>` | Required. The credential id to remove; values starting with `-` are accepted |
| `--profile <NAME>` | Profile whose operator-credential store to edit; a name that is not a safe file name (absolute path, separator, `..`) refuses with `validation.config_invalid` |

```bash
stellar-agent approve operator remove --credential-id <B64URL> --profile default
```

To revoke a credential, remove its id from `[remote_approval] allowed_credentials` first, then remove the enrollment. Either step alone revokes it: the running listener reads both at every login and decision. Operator credentials approve remote testnet requests only and do not change the mainnet approval credentials of the signed policy.

### `approve credential enroll`

Enrolls a WebAuthn approval credential for the owner-signed mainnet policy and prints its `mainnet.approval_credentials` entry. Writes nothing: the credential approves mainnet consent only after the owner adds the entry and signs the policy with `profile sign-policy` (see [Approval credentials](profiles-and-keys.md#approval-credentials)). Needs a terminal on stdin and stderr and a local browser; the profile must be a persisted mainnet profile, enabled or not. The page at `http://localhost:<port>` creates a passkey with relying-party ID `localhost`, user presence and user verification, and shows a 16-hex-digit code; type it at the terminal before the deadline. The bearer URL is never printed.

| Flag | Meaning |
|---|---|
| `--profile <NAME>` | Required. The persisted mainnet profile |
| `--label <LABEL>` | Page label pre-fill; absent from the output |
| `--timeout-seconds <SECS>` | Deadline for registration and code, 1 to 600 (default 300) |

```bash
stellar-agent approve credential enroll --profile operator --label laptop
```

```json
{"ok":true,"data":{"profile":"operator","rp_id":"localhost","credential_id_b64url":"<id>","public_key_sec1_b64url":"<key>","credential_fingerprint":"sha256:<hex>","policy_entry_toml":"{ credential_id_b64url = \"<id>\", public_key_sec1_b64url = \"<key>\" }"},"request_id":"..."}
```

Refusals (exit `1`, nothing exported): `approve.credential_enroll_tty_required`, `approve.credential_enroll_profile_required`, `approval.presence_browser_required` (no display or the browser did not open), `approve.credential_enroll_confirmation_mismatch`, `approve.credential_enroll_expired`, `approve.credential_enroll_canceled`, `approve.credential_enroll_unavailable`. This is an operator command: an agent never enrolls a credential or approves its own request. To revoke an approval credential, remove its policy entry and sign the policy at a higher sequence.

---

## audit

Verifies the per-profile audit log, an append-only hash-chained JSONL record of transaction submissions, signed authorizations, approvals, and explicit key-management and lifecycle events, and repairs its tip anchor. MCP balance reads and payment simulations produce no automatic invocation row. Under V1, payment simulations can reconcile overdue reservations and deliver owed accounting events. Raw argument values are never logged; only argument key names. Typed value events retain each leg's amount, asset, and redacted destination. The chain links each entry to the SHA-256 of the prior entry's canonical body. Uses the `{ok, data, request_id}` envelope.

The chain and the per-file chain-root signatures verify a PREFIX, so an older copy of the active log, or a truncated one, passes both. The tip anchor pins the END of the chain: the active file's entry count, last-entry hash, and byte offset, held in the platform keyring per log path.

### `audit verify <LOG_PATH>`

Read-only. Walks the log at `<LOG_PATH>`, following rotation manifests, and verifies the hash chain end to end. With `--profile`, also loads that profile's audit chain-root HMAC key, verifies the chain-root sidecars, and checks the keyed entry tag of every entry from the log's boundary row on; without it, only the hash chain is checked, and `hmac_verified` and `entry_tags_verified` are `false`.

`hmac_verified` covers each walked file's first entry only. `entry_tags_verified` is `true` when entry tags are in force and every entry past the boundary carries a valid tag; `entry_tags_boundary` names the newest `audit_entry_tags_started` or `audit_entry_tags_rekeyed` row with a valid tag as `{file, line, kind}`, or is `null`. A missing or wrong tag exits `1` with `audit.entry_tag_invalid`. Warnings `entry_tags_absorbed`, `entries_quarantined`, and `entry_tags_rekeyed_at_open` report rows the boundary absorbed without a tag check, rows a repair quarantined, and a rekey a keyed open appended.

| Flag / arg | Meaning |
|---|---|
| `<LOG_PATH>` (positional, required) | Path to the audit log file. Default location by OS: Linux `~/.local/share/stellar-agent/audit/<profile>.jsonl`; macOS `~/Library/Application Support/Soneso.stellar-agent/audit/<profile>.jsonl`; Windows `%LOCALAPPDATA%\Soneso\stellar-agent\data\audit\<profile>.jsonl` |
| `--profile <NAME>` | Profile whose chain-root HMAC key verifies sidecars |
| `--output <FORMAT>` | `json` is the default and only stable format |

The tip anchor is checked only when `--profile` is supplied AND `<LOG_PATH>` is the log that profile configures, since the anchor names a path. Every other case reports `anchor.status` as `"not_checked"` with the reason and still verifies the chain in full. The check proves the anchored entry is still at the anchored offset, so a longer internally consistent log that does not contain it refuses rather than passing on length alone. `"verified"` means the anchored entry is intact and the file ends at or past it; entries past the anchor are authenticated only when `entry_tags_verified` is `true`.

When no anchor is stored for the profile's own log, the log must show that it was never anchored. An audit binding recorded for the profile, a chain-root sidecar beside the active file, or an `audit_tip_anchored` row in it shows it was; the command then fails with `audit.tip_anchor_missing`, and the message says `anchor: missing` and names the evidence. A log with none of them reports `anchor.status` as `"not_checked"`.

On Unix, refuses to verify a log whose parent directory is owned by a different user. Exits `0` when the chain is intact, `1` on any integrity violation (broken chain, rotation gap, HMAC mismatch, missing sidecar, invalid entry tag, unparseable line, tip-anchor mismatch, missing tip anchor), path-contract failure, or I/O error.

A `pruned_prefix` warning reports `first_file`, the oldest file walked, and
`pruned_files`, the count in `<log>.pruned`. The marker seeds that file's first
entry and is authenticated when an audit key is supplied. Verification checks
every retained entry and bridge, and the warning leaves the verdict successful.

`outbox_pending` counts complete queued consent, halt, and resume lines. With `--profile` and the profile's log path, verification checks the keyring commitment under the outbox lock after the chain walk. A missing or changed committed prefix, or a complete line past it, fails with `audit.outbox_rows_missing`; a held lock fails with `audit.outbox_busy`. The outbox lock is taken through the carrier record, so the check also fails with `audit.carrier_replaced`, `audit.carriers_unbound` or `audit.carrier_identity_unavailable` at the head of the detail, and with `audit.outbox_rows_missing` when the retired generation's commitment changed. Without a profile, no commitment is checked. The separate count inspection can report `outbox_torn_tail`, `outbox_unparseable`, or `outbox_unreadable` warnings.

An `outbox_loss_acknowledged` warning names each loss acknowledgement's file, line, `expected_rows`, and `found_rows`. It leaves the chain verdict unchanged.

```bash
stellar-agent audit verify ~/.local/share/stellar-agent/audit/default.jsonl --profile default
```

```json
{"ok":true,"data":{"entries_verified":42,"files_walked":2,"hmac_verified":true,"entry_tags_verified":true,"entry_tags_boundary":{"file":"default.jsonl","line":3,"kind":"audit_entry_tags_started"},"per_file":[],"warnings":[],"audit_writer_degraded":false,"anchor":{"status":"verified","reason":null},"outbox_pending":0},"request_id":"..."}
```

### `audit reanchor --profile <NAME> --acknowledge-rollback`

State-changing (writes the keyring anchor, appends one to three audit rows, then drains the audit outbox; no network). The only way out of an `audit.tip_anchor_mismatch`, `audit.tip_anchor_missing`, or `audit.log_binding_changed` refusal. Operator-only: an agent must never run it on its own initiative, because it accepts a log or a profile change that may have been tampered with.

| Flag / arg | Meaning |
|---|---|
| `--profile <NAME>` (required) | Profile whose configured `audit_log_path` and audit keyring coordinate identify the anchor |
| `--acknowledge-rollback` (required to act on a rolled-back log) | Accept the log's current tip as authoritative |
| `--acknowledge-binding-change` (required to act on a changed binding) | Accept a log path or audit key that differs from the recorded audit binding |
| `--acknowledge-unauthenticated-tail` (required with an unauthenticated tail) | Keep the entries past the last authenticated entry and quarantine them |

| Recorded binding | Current path's anchor | Flags required | Rows appended |
|---|---|---|---|
| Equal or absent | Any | `--acknowledge-rollback` | `rollback_acknowledged` |
| Changed or unreadable | Agrees, or absent without prior anchoring evidence | `--acknowledge-binding-change` | `binding_changed` |
| Changed or unreadable | Disagrees, cannot be parsed, or absent with prior anchoring evidence | Both | `rollback_acknowledged`, then `binding_changed` |

In every row, an active file that ends in entries without a valid entry tag, on a log whose tags are in force, also requires `--acknowledge-unauthenticated-tail`: the command appends `audit_entries_quarantined` directly after those entries, before its other rows, lists `unauthenticated_tail` first in `acknowledged`, and reports `quarantined_rows`. Readers skip quarantined entries. Without such a tail the flag is ignored. A tail ending on a rotation handoff without a valid tag refuses with `audit.reanchor_failed` and names the line to remove.

The first row covers both anchor refusals: an anchor that disagrees with the log (`audit.tip_anchor_mismatch`), and an absent anchor on a log that shows it was anchored before (`audit.tip_anchor_missing`). In the binding-changed rows an absent anchor disagrees when a chain-root sidecar or an `audit_tip_anchored` row shows prior anchoring. Without evidence it agrees.

A flag the matrix does not require is ignored. A missing flag changes nothing and exits `1` with `validation.acknowledgement_required`, naming the flag. With the required flags it replays the whole log, so a broken chain is refused rather than blessed. It writes the current tip, bumps the current path's re-anchor counter once, and appends the rows, each carrying that count. `binding_changed` names the old path's anchor, or none when the record was unreadable. The new binding is stored last. Recovery takes all three audit carriers with immediate try-locks and refuses with `audit.carriers_busy` when any is held. Stop an MCP server that holds that profile's writer before a rollback repair. A binding change needs no stop: a server running the edited profile refuses before it opens the new path, so it holds no lock there. A server still running the old profile refuses after the acknowledgement until it restarts.

Queued consent, halt, and resume rows follow the repair rows and are counted in `outbox_drained`. A drain refusal leaves the repair in force and exits `0`. It omits `outbox_drained`, since every queued row stays queued, and lists the refusal under `warnings`: `audit.outbox_unusable`, `audit.outbox_busy`, `audit.outbox_rows_missing`, or the condition an append refused on, such as `audit.io_error`.

```bash
stellar-agent audit reanchor --profile default --acknowledge-rollback
stellar-agent audit reanchor --profile default --acknowledge-binding-change
```

```json
{"ok":true,"data":{"profile":"default","previous_anchor":"42:18104","current_anchor":"39:16820","reanchor_count":1,"acknowledged":["rollback"],"quarantined_rows":0,"recorded_binding":"equal","previous_binding_anchor":null,"outbox_drained":0},"request_id":"..."}
```

### `audit acknowledge-outbox-loss --profile <NAME> --reason <TEXT>`

Operator-only recovery for `audit.outbox_rows_missing`; an agent must not run it on its own initiative.
Stop the process holding the profile's writer and inspect the queued rows first.
`--reason` is required, non-empty, and recorded with the audit string bound.

The command checks the tip anchor, checks that the loss holds and, when the committed prefix is intact, that every committed row parses and is an operator row, and then revokes every decided, unexpired, unconsumed approval and every toolset grant.
Mainnet confirmations and recorded passkey assertions count as decided approvals.
It records `audit_outbox_loss_acknowledged`, appends the committed prefix when it is intact and nothing otherwise, resets the commitment, and empties the outbox, discarding every other line.
Approve affected actions again to record fresh consent.

The result contains `profile`, `expected_rows`, `found_rows`, `drained`, `discarded`, `revoked_approvals`, and `revoked_grants`; `discarded` counts the complete lines dropped without being appended.
A changed commitment of the outbox generation the last `audit bind-carriers` retired is a loss too, reported after any loss in the active queue: `expected_rows` is the rows that commitment held at retirement and `found_rows` the rows it holds now, and the acknowledgement resets the retired watch to the commitment it observed.
No loss returns `audit.outbox_loss_not_found` without an acknowledgement, and a log rolled back behind its tip anchor returns `audit.tip_anchor_mismatch`. Recovery takes all three audit carriers with immediate try-locks and refuses with `audit.carriers_busy` when any is held.
An intact committed row that does not parse, or that is not an operator row, returns `audit.outbox_unusable` before anything is revoked or written.
A row that cannot append leaves the queue and commitment in place for inspection and retry.

```bash
stellar-agent audit acknowledge-outbox-loss --profile default --reason "Queue inspected; fresh approval required"
```

### `audit bind-carriers`

```bash
stellar-agent audit bind-carriers --profile <NAME>
```

Stop every wallet process before this operator-only command. It takes all
three audit lock files with one try-lock each and refuses with
`audit.carriers_busy` when any is held. It verifies the committed operator
rows, copies them into a new outbox generation, appends `audit_carriers_bound`,
records all three carrier identities in the keyring, and renames the old outbox
to `<log>.outbox.retired-g<G>`, or to `<log>.outbox.retired-g<G>.<n>` when an
earlier binding already used that name.
The result contains `profile`, `generation`, `carried_rows` and `retired_file`.
`retired_file` is the retired file's name, or `null` when the log had no outbox
file. When a retired file exists, keep it while investigating stale holders.
A log with keyed history refuses keyed use with `audit.carriers_unbound` until
this command runs once; a log without keyed evidence enrolls at its first keyed
open. Replaced carriers refuse with `audit.carrier_replaced`. A staged
generation refuses with `audit.carrier_binding_incomplete`; rerun this command
to finish it.

### Governance loop

1. The agent surface evaluates an action against the policy engine; an action needing consent records a pending approval and returns its nonce instead of executing.
2. The wallet owner runs `approve --id <NONCE> --profile <name>`, reads the wallet-controlled summary, and consents. The command writes an HMAC attestation (or toolset grant) bound to the profile name, chain id, nonce, envelope digest, and local user.
3. The agent surface verifies the attestation and executes; the commit writes its transaction audit events to the hash-chained log.
4. The operator periodically runs `audit verify <LOG_PATH> --profile <NAME>` to confirm the chain, the chain-root HMAC sidecars, and the tip anchor are intact.

---

## tx

Reconciles and clears the submission records the value verbs write. Every value-moving verb records a transaction before it is sent, so a submission whose confirmation never arrived leaves a receipt behind. It also leaves a spending-window reservation when the policy produced window entries for the submission. The reservation holds the operator's caps through its accounting horizon or, without a time bound, until an operator clears it. A pending receipt holds the wallet's duplicate check.

### `tx status <HASH> [flags]`

Asks the endpoint what became of `<HASH>` and records a reported success on the wallet's record of it. This is the way out of `submission.tx_timeout`.

| Flag / arg | Meaning | Default |
|---|---|---|
| `<HASH>` (positional) | Transaction hash, 64 lowercase hex: `error.details.tx_hash` from the timed-out submission | none |
| `--profile <NAME>` | Profile whose records and spending window are reconciled | `STELLAR_AGENT_PROFILE`, else `default` |
| `--output <FORMAT>` | `json` or `table` | `json` |

Returns `{tx_hash, chain_status, ledger, record, reservation}`, omitting absent fields. `record` is the wallet's receipt: `envelope_hash`, `status`, `failure_code`, `release_code`, `ledger`, `source_redacted`, `sequence`, `submitted`, `reservation_open`, `settlement_evidence` and `settlement_decision_id`. Receipt output includes `settlement_evidence: unavailable` and an optional `settlement_decision_id`; these display fields do not authenticate settlement. `reservation` is a hold that remains after reconciliation, `{envelope_hash, operator_required}`; `operator_required: true` marks a reservation whose receipt is missing beyond the endpoint's retention window. A time-bounded one still ends at its accounting horizon. Once its execution bound has passed, `tx receipt clear --acknowledge` clears an eligible receipt, and the bounded spend stays charged through the horizon. An untimed hold clears with `--acknowledge --acknowledge-unbounded`.

A reported failure or missing transaction does not release possible spending. Bounded uncertainty counts through the later of the signed deadline and the first local success observation, plus each affected spending window.

A reported success time does not backdate accounting. Untimed pending transactions remain reserved until an explicit acknowledgement clears their unbounded exposure.

Classic mainnet envelopes carry a deadline 120 seconds after construction,
covered by consent. Deadline expiry ends future execution. Accounting expiry
uses `submission.accounting_expired` and leaves the chain outcome unknown.
No failure row follows from an endpoint's failure, absence, or time claim.
The authenticated reservation controls the bound and chain; editing a receipt
cannot shorten either. A checked independent witness supplies anchor provenance.

Accounting audit delivery needs the audit writer's exclusive lock. While a `stellar-agent-mcp` server holds that writer, the verb still reconciles and reports. The event stays owed and the refusal is logged at WARN. Stop the server and run the verb again to deliver it.

### `tx receipt clear <ENVELOPE_HASH> --acknowledge [flags]`

| Flag | Meaning |
|---|---|
| `--acknowledge` | Record the operator's decision and reconcile before clearing. Clearing establishes no chain outcome. |
| `--acknowledge-unbounded` | Accept that this untimed transaction can still apply and that its spend is then not counted. Required beside `--acknowledge` on every network for an authenticated hold without a time bound, whatever its receipt records or the endpoint reports. Also required on mainnet for a sent `pending`, `ambiguous` or `failed` receipt without one when no hold exists. Both acknowledgement flags are also required to finish a recorded unbounded clear. |

Closes a submission record after reconciling it against the chain. `--acknowledge` records the operator's decision; clearing establishes no chain outcome. A reported failure or missing transaction does not release possible spending.

An authenticated hold without a time bound is cleared with `--acknowledge` and `--acknowledge-unbounded` on every network, whatever its receipt records and whatever the endpoint or the oracle reported before or during the clear. With `--acknowledge` alone it is refused with `submission.unbounded_exposure`. The clear row records `unbounded_exposure: true` before capacity changes, and the clear releases the hold: the output and the row carry `reservation_released: true`. An endpoint or oracle that cannot answer still refuses. A receipt that records `success`, `failed` or `reorged` keeps that record through the reconciliation. When the endpoint now reports `SUCCESS` for a receipt that records another answer, or `NOT_FOUND` below its retention floor, the clear row's `evidence` records that answer: `submission.reported_success` or `submission.retention_expired`.

For every other submission, a record recorded as `success`, `reorged` or `cleared_by_operator`, or as `failed` under a held reservation, is refused with `submission.not_clearable`. So is an endpoint answer of `SUCCESS`, an answer of `FAILED` for a held reservation, and an endpoint that cannot answer at all. With `--acknowledge`, a terminal receipt without a hold first acquires the audit writer to look for an interrupted clear; the acquisition can drain queued rows or return an audit error. Without a matching row a `success` or `reorged` receipt is refused without reconciliation, release or marking. A `failed` receipt without a hold proceeds to the endpoint check. A reservation with a time bound whose receipt is missing is cleared only when the endpoint reports `NOT_FOUND` below its retention floor. On a mainnet profile with an oracle, the oracle is asked as well and refuses the clear the same way, and so does an oracle that does not report the mainnet passphrase. Without an oracle nothing confirms the endpoint's `FAILED`, so it does not refuse the clear and the acknowledgement decides; the endpoint's `SUCCESS` still refuses.

Without `--acknowledge` nothing is reconciled or written: the exit code is 1 with `submission.acknowledgement_required`, and the message names the next step. An authenticated hold without a time bound requires `--acknowledge-unbounded` beside `--acknowledge` on every network, and so does, on mainnet, a sent `pending`, `ambiguous` or `failed` receipt without one when no hold exists. The flag states that the bytes can still apply and their spend stops counting against the window. Otherwise, while a sent `pending` receipt's time bound is open, the next step is to wait or run `tx status`. Every other record gets `--acknowledge`. With the required flags the verb reconciles the submission the way `tx status` does, then:

- The reconciled outcome could not be recorded on its receipt: refused with `submission.record_unavailable`, naming the receipt-store error. Run `stellar-agent tx status` again.
- The receipt disagrees with its reconciliation or with the verified accounting decision: refused with `submission.record_unavailable`. Run `stellar-agent tx status` again.
- An authenticated accounting expiry (the verified window state holds the expiry decision, and the receipt carries its projection): the clear row records that disposition. A `release_code` on the receipt alone is display data and no evidence. Neither observations nor accounting expiry establish a failed chain outcome. An audit write failure leaves the record clearable.
- An authenticated hold without a time bound, whatever its receipt records, without `--acknowledge-unbounded`: refused with `submission.unbounded_exposure`. Both flags clear it, release the hold and record `unbounded_exposure: true`. On mainnet a sent `pending`, `ambiguous` or `failed` receipt without a time bound and with no hold is refused the same way.
- `ambiguous` without evidence or with a `release_code` the spending window does not bear out, `pending` with a passed time bound, or `pending`, never sent and with no held reservation, each with the required acknowledgement flags: it clears the receipt. A bounded hold remains charged through its horizon, so the clear reports `reservation_released: false`.
- `pending` or `ambiguous`, sent or held, or a sent `failed` receipt with no held reservation, with an open time bound on this host's clock: refused with `submission.still_pending`, naming the time bound.
- During reconciliation, `SUCCESS` on a bounded hold prevents operator clear, and `FAILED` retains exposure. A passed execution bound does not lift the refusal of an endpoint or oracle `FAILED` for a held reservation. An eligible clear after the bound preserves the accounting horizon.
- A mainnet profile without an oracle: a `pending`, sent record whose time bound has not passed on this host's clock is refused with `submission.still_pending`; any other `pending` record is cleared with the required acknowledgement flags. Without an oracle, passing the deadline permits an acknowledged clear; it does not establish chain evidence.
- A ledger-time read failed for a sent submission whose hold or receipt carries a time bound, or another reconciliation read of the endpoint or the oracle failed: refused with `network.rpc_unreachable`.
- A reconciliation read of the oracle was still open at the verb's oracle deadline: refused with `network.rpc_unreachable`. Every oracle read of the verb ends by one deadline, the profile's `submit_timeout_seconds` counted from the oracle's identity read, so a stalled oracle cannot hold the audit writer past it. Reconciliation asks the oracle the verb already found serving mainnet and does not read its identity again, so an oracle identity failure refuses before the acknowledgement with `submission.not_clearable`, never during reconciliation.

Where the profile has an audit writer, the check for an earlier clear row reads the retained audit history. An unreadable history refuses with the verifier's code, such as `audit.chain_broken` for a broken chain, before the clear row is written, and keeps the receipt. The row is written before the accounting transition and the mark, and a re-run after a failure part-way writes no second row. A clear of an untimed hold stopped after the release leaves no hold: the re-run with both acknowledgement flags finds the row with `unbounded_exposure: true` and `reservation_released: true`, marks the receipt and reports `reservation_released: true`. A synthesized profile with no audit writer skips the history lookup and marks the receipt cleared without writing audit rows.

`--acknowledge` records the operator's decision. The receipt becomes `cleared_by_operator` and owes no settlement row. For untimed exposure, `--acknowledge-unbounded` also records indefinite possible execution and uncounted spend before capacity clears. Clearing establishes no chain outcome and does not revoke signed bytes.

---

## toolsets

Install, list, run, and uninstall agent toolsets with cryptographic provenance verification. Uses the standard `{ok, data|error, request_id}` envelope; failures carry a `toolsets.*` (directory/install/uninstall) or `toolset.*` (enforcement, shared with the MCP `stellar_toolset_invoke` tool) wire code. JSON by default. All four accept `--toolsets-dir <PATH>` to override the OS-conventional toolsets root. The binary subcommand is `toolsets` (plural).

### `toolsets install <PKG@VERSION> [flags]`

Installs a toolset from a signed local `.tar.gz`. The publisher key must be in the configured publisher trust set. Toolsets that declare a key-touching capability (e.g. `sign-payment`) additionally require a valid auditor attestation unless `--override-attestation`. The install holds the toolsets directory lock, reads the installation's pin key from the platform keyring (the first install mints it), and writes an install record authenticated under that key. The trust sets are plain operator-held files, read at install time only.

| Flag / arg | Meaning |
|---|---|
| `<PKG@VERSION>` (positional, required) | `<name>@<version>`, e.g. `my-toolset@1.0.0` |
| `--file <PATH>` (required) | Path to the `.tar.gz` package |
| `--shasum <HEX>` (required) | Expected SHA-256 of the package (64 lowercase hex) |
| `--signature <HEX>` (required) | Publisher ed25519 signature over the canonical preimage (128 hex = 64 bytes) |
| `--publisher <G-STRKEY>` (required) | Publisher ed25519 public key as a Stellar G-strkey |
| `--trust-set <PATH>` | Publisher trust-set file (default `<toolsets_dir>/trust.txt`) |
| `--attestation-file <PATH>` | JSON `ToolsetAttestation` from the auditor tool; required for key-touching toolsets unless overridden |
| `--auditor-trust-set <PATH>` | Auditor trust-set file (default `<toolsets_dir>/auditor-trust.txt`); distinct from the publisher set; an absent/empty set fails closed for key-touching toolsets |
| `--override-attestation` | Bypass the attestation gate for a key-touching toolset (the only sanctioned bypass); installs with the key-touching capability inert; reports `"attestation":"overridden"` |
| `--force` | Reinstall even if already installed |
| `--allow-downgrade` | Allow installing an older version over a newer one (only with `--force`) |
| `--toolsets-dir <PATH>` | Override toolsets root |

On success `data` carries `package`, `version`, and `attestation` (`"attested"` / `"overridden"` / `"not-required"`: the actual gate decision, not an inference from flags). Refusals (attestation-required, auditor-untrusted with no partial install, or any other install failure) carry `error.code` `toolsets.install_failed`, with the distinguishing detail in `error.message`; a keyring failure carries its keyring code. `--force` over a record that does not verify also needs `--allow-downgrade`, because the recorded version cannot be trusted for the downgrade check; uninstalling first is the plain path.

```bash
stellar-agent toolsets install my-toolset@1.0.0 --file ./my-toolset-1.0.0.tar.gz \
  --shasum <sha256hex> --signature <128hex> --publisher GPUB...WXYZ
```

### `toolsets list [--toolsets-dir PATH]`

Read-only. The canonical scriptable enumeration of installed toolsets and their capability-derived action lists (not parsed from `--help`). Reports `data.toolsets`. A toolset whose install record does not verify under the installation's pin key is skipped with a warning; before the first install the list is empty.

### `toolsets run <TOOLSET-NAME> <ACTION> [--toolsets-dir PATH]`

Runs the four-part capability enforcement check for an installed toolset action and reports the resolved trusted tool name. It does **not** execute the routed tool — use the MCP surface tool `stellar_toolset_invoke` for execution.

- `<TOOLSET-NAME>` (positional, required) — installed toolset package name.
- `<ACTION>` (positional, required) — must be an exact registry tool name the toolset's capabilities grant, e.g. `stellar_balances`.

On success, exit `0` with `data` carrying `toolset`, `action`, `routed_to`, and a `note` clarifying that enforcement passed but the tool was not run. On failure, exit `1` with `error.code`: `toolset.not_installed`, `toolset.pin_unverifiable`, `toolset.content_digest_mismatch`, `toolset.unknown_action`, `toolset.capability_not_declared`, `toolset.tool_not_allowed`, `toolset.io_error`, or `toolset.error`. The toolset gate is additive: the routed tool's operator policy and chain gates still apply at execution time.

```bash
stellar-agent toolsets run balance-reporter stellar_balances
```

### `toolsets uninstall <PACKAGE> [--toolsets-dir PATH]`

Removes the toolset directory and pin record; refuses if not installed (`toolsets.uninstall_failed`). It holds the toolsets directory lock and reads no install record, so it also removes a toolset whose record does not verify (`toolset.pin_unverifiable`), the first step of reinstalling it. `<PACKAGE>` (positional, required) is the package name (`[a-z0-9-]`). On success `data` carries `package`.

```bash
stellar-agent toolsets uninstall my-toolset
```

## Retained smart-account charges

A bounded invocation charge closes when a later policy check or admission witnesses both profile endpoints above every authorization and envelope bound.

The intent view reports the accounting horizon, retention boundary, operation purpose, and schedule terminal state without changing state.

`accounting_horizon` is `open` for executable or unclassified authority. Otherwise it is the admitted accounting horizon in milliseconds. `retained_until_ms` is the separate inclusive retention boundary.

Reset refuses while an intent remains open or retained. A closed and pruned intent does not block reset.

An open intent without an authenticated purpose permanently blocks reset for this profile. Continue with a new profile.

Retained intents close only through the profile's stored secondary endpoint. Add one to the profile.

The profile's stored endpoint configuration is unreadable. Retained intents close only through stored endpoints that load.
