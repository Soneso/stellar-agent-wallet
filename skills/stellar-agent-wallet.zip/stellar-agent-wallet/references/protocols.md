# Protocols (SEP and x402)

See [Mainnet configurations and scope](https://github.com/Soneso/stellar-agent-wallet/blob/main/docs/getting-started.md#mainnet-configurations-and-scope)
for build configuration, admitted operations, and exclusions.

The supported Stellar ecosystem protocols, the wallet surface for each, and the deliberate refusals that keep an autonomous agent safe. Every SEP/x402 capability listed here is exposed as an MCP tool on the `stellar-agent-mcp` stdio server. For the wider tool catalog see `./mcp-tools.md`; for keys, signers, and profiles see `./profiles-and-keys.md`.

## Three invariants

- **Privacy-first.** No SEP-9 KYC field is ever transmitted. The audit log records argument key names only, never argument values. Interactive flows are handed back to the operator, never scraped.
- **Fail-closed.** Validation refuses on any failed check rather than guessing. Unknown discriminants, ambiguous tokens, missing floors, and stale reads are refused before signing.
- **Never auto-submit untrusted requests.** Inbound requests (a SEP-7 URI, a contract invocation) are parsed into a preview for the operator and policy engine. The wallet does not sign or submit on a dApp's behalf without the policy engine and approval flow.

The scope table defines mainnet operation admission. Public SEP-43 signing,
generic SEP-45/53 signing, and MPP remain excluded in every build.
Wallet entry guards use `network.mainnet_write_forbidden`; library refusals
retain their namespaced codes. Read-only classification grants no signing
or transaction-write authority.

## Result envelope and conventions

- MCP result envelope: `{ ok, data | error, request_id }`. On success `ok` is true and the payload is in `data`; on failure `error` carries a stable wire code. `stellar_toolset_list` and four DeFi tools return a bare success payload. Every tool on this page uses the envelope for business errors; invalid arguments and a `chain_id` mismatch use the JSON-RPC error channel.
- `chain_id` is the CAIP-2 chain id (`"stellar:testnet"` or `"stellar:mainnet"`) and is **required** by most tools. SEP-43 `get_address`/`get_network` accept it as optional and fall back to the active profile's chain; the WalletConnect host passes `{}`. (Note: x402 uses the distinct wire-network string `stellar:pubnet` for mainnet in its `network` field; that is not a `chain_id` value.)
- Asset format: `"native"`/`"XLM"`, or `"CODE:GISSUER"`. Amounts are strings, never JSON numbers, encoded per protocol. Classic payment amounts carry a unit, e.g. `"10 XLM"`. An x402 requirement `amount` is an atomic-unit integer string. The SEP-24 `deposit_hint` is a unitless decimal string such as `"100.50"`.
- A `chain_id` that does not match the active profile is rejected by the dispatch gate as a JSON-RPC-level error before any signing. The x402 payment tools decode and validate `payment_required` first, so an `x402.*` requirement error comes before a chain mismatch.
- The generic signing tools (the SEP-43 sign verbs and SEP-53 `sign_message`) are single-shot. If the policy engine returns `RequireApproval`, the tool is fail-closed with wire code `policy.approval_required_unsupported` (message mentions "single-shot") and **no signature is produced**. Two-phase approval is not supported on these single-shot signing tools. On testnet, the x402 payment tools answer `RequireApproval` the same way. In a feature-enabled build, mainnet x402 payments use two calls with mandatory approval.

## SEP support matrix

| SEP | Spec version | Capability | Tool(s) | Read-only |
|---|---|---|---|---|
| SEP-7 | 0007 | Parse `web+stellar:` URI into a preview; optional fresh-`stellar.toml` origin-signature verify | `stellar_sep7_parse_uri` | yes |
| SEP-10 | 3.4.1 | Client Web Auth (fetch, 13-point validate, submit) → JWT; ephemeral-key flow; authorized mainnet completion for bound x402 identity authentication | used by the x402 identity gate | n/a |
| SEP-6 | 0006 | Discovery only, `GET /info` capability set | `stellar_sep6_deposit_info` | yes |
| SEP-24 | 0024 | Interactive deposit/withdraw URL via `POST .../interactive`; returned for browser hand-off | `stellar_sep24_interactive_url` | no (uses JWT) |
| SEP-43 | 1.2.1 | Wallet signing: address/network/sign tx/sign auth entry/sign message/sign+submit | six tools (below) | mixed |
| SEP-45 | 0.1.1 | Client Web Auth for contract (C-) accounts (steps 1 to 12); ephemeral + persistent-signer | no workspace consumer; refuses mainnet signing | n/a |
| SEP-47 | 0047 | Discover SEPs a contract claims via `contractmetav0` `sep` meta | `stellar_sep47_discover` | yes |
| SEP-48 | 0048 | Typed-argument preview of an `InvokeHostFunction` (display only) | `stellar_sep48_preview_invocation` | yes |
| SEP-53 | 0053 | Sign and verify prefixed off-chain messages | `stellar_sep53_sign_message`, `stellar_sep53_verify_message` | mixed |

## SEP-7: `web+stellar:` URI parsing

Parses an inbound `web+stellar:tx?...` or `web+stellar:pay?...` URI from an untrusted dApp into a structured preview, and optionally verifies the dApp's origin-domain signature.

Tool `stellar_sep7_parse_uri`:

| Arg | Type | Required | Notes |
|---|---|---|---|
| `chain_id` | string | yes | CAIP-2; e.g. `"stellar:testnet"` |
| `uri` | string | yes | the `web+stellar:` URI |
| `verify_origin` | bool | no (default `true`) | when `true`, fresh `stellar.toml` fetch + ed25519 verify if `origin_domain`+`signature` present; `false` = structural parse, no network I/O |

Preview fields: `operation` (`"tx"`/`"pay"`), parsed operation fields, `callback` (authority host for SSRF inspection), `origin_domain`, `origin_verified`, `signature_status` (`verified`/`failed`/`missing_required`/`absent`), `will_auto_submit` (always `false`), `will_auto_post_callback` (always `false`).

A URI with any parameter after `signature`, a trailing `&` included, or with a percent-encoded `signature` name, refuses with `sep7.invalid_param_value`; the verified payload therefore covers every parameter the preview shows.

Does NOT: sign a URI; auto-POST to a `callback`; auto-submit. Origin-domain verification always fetches a fresh `stellar.toml` (never cached). SEP-7 carries no nonce/timestamp, so replay protection is the host's responsibility. Parse and verify failures are business errors under the standard envelope with `sep7.*` wire codes (e.g. `sep7.malformed_uri`, `sep7.missing_required_param`, `sep7.invalid_param_value`, `sep7.msg_too_long` [`msg` max 300 chars], `sep7.too_many_chain_levels` [max 7], `sep7.toml_fetch_failed` [URL redacted], `sep7.signing_key_not_in_toml`, `sep7.signature_verification_failed`, `sep7.signature_missing_with_origin_domain`).

## SEP-10: Stellar Web Authentication

Client-side Web Auth: fetch the challenge transaction, run the 13-point challenge validation, submit the signed challenge to obtain a JWT session. A per-request ephemeral ed25519 key flow is provided. There is no standalone SEP-10 MCP tool; it is consumed internally by the x402 identity gate. The anchor tools take a caller-supplied JWT.

Does NOT: verify the server-issued JWT signature (the JWT is trusted via TLS). Challenge validation is fail-closed on every check. Ephemeral keys are generated fresh per call from the OS RNG and zeroized on drop.

Ordinary ephemeral authentication refuses a mainnet passphrase before key generation. Mainnet challenge signing requires the authorized completion used by bound x402 identity authentication.

- `auth_with_ephemeral_key` refuses mainnet before generating an ephemeral key with `sep10.mainnet_signing_forbidden`, the ordinary signing entry's refusal of a mainnet passphrase.
- `sign_challenge_for_test` exists only with the `test-helpers` feature and signs with a caller-supplied key. It refuses mainnet before signing.
- `prepare_ephemeral_auth` generates the ephemeral key, fetches and validates the challenge, and seals its digest and validated network before authorization. It does not sign.
- `web_auth_domain_for_endpoint` derives the web-auth domain from the endpoint's host.
- In the authorized flow, the challenge must name the ephemeral account before message authorization and again before signing.
- `complete_ephemeral_auth_authorized` consumes the prepared challenge and checks it against the message-use receipt before signing and submitting it. It exists only in builds with the `mainnet-write` feature. `sep10.mainnet_authorization_refused` reports that this completion refused before submitting a signed challenge.
- The identity gate's ordinary entries, `resolve_and_verify_counterparty` and its `test-helpers` transport seam, refuse mainnet before fetching `stellar.toml` with `identity.mainnet_signing_forbidden`.
- `resolve_and_verify_counterparty_authorized` takes `MainnetIdentityInputs` and returns `MainnetCounterpartySession`. Its `into_parts` method transfers the session and receipt to the payment caller. `identity.mainnet_authorization_refused` reports that the bound identity authentication refused before submitting a signed challenge.
- The authorized gate, `MainnetIdentityInputs`, and `MainnetCounterpartySession` exist only in builds with the `mainnet-write` feature.

## SEP-6 and SEP-24: anchor deposit/withdraw

SEP-6 discovery is `GET {transfer_server}/info` only. SEP-24 obtains the anchor's interactive URL via `POST .../transactions/{op}/interactive` using a caller-supplied JWT and returns that URL for browser hand-off.

Tool `stellar_sep6_deposit_info` (read-only):

| Arg | Type | Required | Notes |
|---|---|---|---|
| `chain_id` | string | yes | CAIP-2 |
| `anchor_domain` | string | one of these two | resolve `TRANSFER_SERVER` from `stellar.toml`; takes precedence if both given |
| `transfer_server` | string | one of these two | direct URL; HTTPS + public FQDN required |
| `asset_code` | string | no | passed as `?asset_code=` |
| `lang` | string | no | RFC 4646; default `"en"` |

Tool `stellar_sep24_interactive_url`:

| Arg | Type | Required | Notes |
|---|---|---|---|
| `chain_id` | string | yes | CAIP-2 |
| `anchor_domain` | string | one of these two | resolve `TRANSFER_SERVER_SEP0024`; mutually exclusive with the direct URL |
| `transfer_server_sep0024` | string | one of these two | direct URL; HTTPS required |
| `operation` | string | yes | `"deposit"` or `"withdraw"` |
| `asset_code` | string | yes | Stellar asset code |
| `asset_issuer` | string | no | issuer G-strkey |
| `account` | string | no | classic, contract, or muxed account id |
| `deposit_hint` | decimal string | no | maps to the wire param `amount`; positive decimal in `asset_code` units (e.g. `"100.50"`); rejects negatives, scientific notation, multiple/leading/trailing dots, zero, over-precision |
| `lang` | string | no | RFC 4646 |
| `claimable_balances_ok` | bool | no | sent on the wire as `claimable_balance_supported` |
| `jwt` | string | yes | SEP-10 or SEP-45 Bearer JWT from web-auth; never logged |

Returns: `interactive_url` (HTTPS, anchor-hosted), `transaction_id`, `handoff_note`.

Both tools do NOT transmit any SEP-9 KYC field. The arg structs have none by design. SEP-6 is structurally incapable of calling `/deposit`, `/withdraw`, `/deposit-exchange`, `/withdraw-exchange`, `/customer` (SEP-12), `/fee`, or `/transaction(s)`. The wallet does not perform SEP-10/45 itself (the caller supplies the opaque JWT) and never opens, scrapes, or follows the interactive URL. Same-domain SSRF bind: the resolved transfer-server host must equal the operator-typed anchor domain or be a subdomain of it; the anchor domain is validated as a public FQDN first.

## SEP-43: Wallet Protocol (signing)

Agent-side `ModuleInterface` dispatch. Results use the standard `{ ok, data | error, request_id }` envelope; the SEP-43 raw protocol payload (`{ address }`, `{ signedTxXdr, signerAddress }`, etc.) is carried inside `data` on success.

| Tool | Method | Read-only | Submits | Returns |
|---|---|---|---|---|
| `stellar_sep43_get_address` | `getAddress` | yes | no | `{ address }` |
| `stellar_sep43_get_network` | `getNetwork` | yes | no | `{ network, networkPassphrase }` |
| `stellar_sep43_sign_transaction` | `signTransaction` | no | no | `{ signedTxXdr, signerAddress }` |
| `stellar_sep43_sign_auth_entry` | `signAuthEntry` | no | no | `{ signedAuthEntry, signerAddress }` |
| `stellar_sep43_sign_message` | `signMessage` | no | no | `{ signedMessage (base64), signerAddress }` |
| `stellar_sep43_sign_and_submit_transaction` | sign + submit | no | yes (destructive) | `{ signedTxXdr, txHash, status }` |

Common signing args: `chain_id` (required), the payload field, optional `network_passphrase` (if provided must equal the profile passphrase exactly; mismatch → `sep43.invalid_network_passphrase`), optional `address` G-strkey (if provided must match the active signer; mismatch → `sep43.invalid_address`).

- `get_address` / `get_network`: `chain_id` is optional (chain-agnostic per spec); when omitted, the profile's chain is used. No keyring access.
- `sign_transaction`: arg `transaction_xdr` (base64 `TransactionEnvelope`). Signs only; the optional SEP-43 `submit`/`submitUrl` opts are NOT implemented here.
- `sign_auth_entry`: arg `auth_entry_xdr` (the base64 `HashIdPreimage` of the authorization entry, envelope type 9 `SorobanAuthorization` or type 10 `SorobanAuthorizationWithAddress`). Signs the SHA-256 of the received preimage with one ed25519 G-key and returns the raw signature; the requester assembles it into the entry. A type 10 preimage must be bound to the signing key's account; other addresses refuse with `sep43.invalid_address`; other preimage cases refuse with `sep43.malformed_auth_entry`. The preimage does not carry the credential arm, so the address binding is the check whichever credential type the entry uses. No multi-signer quorum.
- `sign_message`: arg `message` (non-empty UTF-8). Signs the SEP-53 digest `sha256("Stellar Signed Message:\n" || message_bytes)`; result `signedMessage` is standard base64. Optional `network_passphrase` is a caller-intent gate only: it is not mixed into the signed bytes (message signing is network-independent).
- `sign_and_submit_transaction`: arg `transaction_xdr`. Signs, submits via Stellar RPC, and polls until ledger confirmation. `status` is `"success"` (confirmed; `txHash` is a hex64) or `"pending"` (the submission ended without a confirmed outcome: the polling deadline passed, the endpoint reported an unexpected status, or a transport failure struck during or after the send; `txHash` is the hex64 the wallet computed before the send, and the tx may still apply). For a pending transaction, settle it by passing `txHash` to `stellar_transaction_status`, and never resubmit. RPC endpoint/timeout errors strip the URL before surfacing.

SEP-43 wire codes (`error.code` under the standard envelope, from `Sep43Error::wire_code()`):

| Code | Meaning |
|---|---|
| `sep43.wallet_unlock_failed`, `sep43.signer_unavailable`, `sep43.xdr_serialization_failed`, `sep43.keyring_error` | Internal wallet error |
| `sep43.horizon_error`, `sep43.rpc_error` | External service error |
| `sep43.invalid_xdr`, `sep43.invalid_address`, `sep43.invalid_network_passphrase`, `sep43.missing_address`, `sep43.malformed_auth_entry`, `sep43.invalid_message` | Client-invalid request |
| `sep43.user_rejected` | User rejected |

The structural mainnet refusal (sign-only tools, before any key access) carries the canonical `network.mainnet_write_forbidden` code shared with every other signing surface, not a `sep43.*` code.

`sign_message` refusals before key load (an overlaid or out-of-scope signer, an unavailable audit writer) carry `profile.*` and `audit.*` codes, not `sep43.*` codes.

SEP-43 opens no HTTP/HTTPS connections of its own (interop is stdio via MCP); `sign_and_submit` is the only path that submits, via the profile-configured RPC.

## SEP-45: Web Authentication for Contract Accounts

Client-side Web Auth for contract (C-) accounts: fetch the challenge, validate the authorization entries, submit the signed challenge to obtain a JWT. Both an ephemeral-key flow and a persistent-signer flow exist. No workspace crate depends on it. It refuses mainnet signing in every build with `sep45.mainnet_signing_forbidden`. The anchor tools take a caller-supplied JWT.

Steps 1 through 12 of the 13-point validation are enforced; step 13 (footprint `read_write` keys) is deferred because it requires simulation results unavailable at challenge-fetch time. Fail-closed on any step. The JWT signature is not verified (trusted via TLS). HTTPS-only at the transport layer. Does not access the keyring or wallet seed (pure decode and validate); the ephemeral path suits only contracts that accept the ephemeral public key or need no client signature.

## SEP-47: Contract Interface Discovery

Discovers the SEPs a contract claims to implement by reading the `sep` entry of its `contractmetav0` metadata (comma-separated, leading zeros stripped, e.g. `"41,40"`).

Tool `stellar_sep47_discover` (read-only): args `contract_id` (C-strkey, required), `chain_id` (required, resolves the RPC endpoint). Returns `{ supported_seps: ["41", "40"] }`; returns `{ supported_seps: [] }` (not an error) when the contract has no `contractmetav0` section or no `sep` entry. Errors on invalid C-strkey, unreachable RPC, or unfetchable WASM. Submits nothing; modifies no chain state.

## SEP-48: Contract Interface Specification

Renders a typed-argument preview of an `InvokeHostFunction` against the on-chain contract spec (`contractspecv0`).

Tool `stellar_sep48_preview_invocation` (read-only):

| Arg | Type | Notes |
|---|---|---|
| `transaction_xdr` | string, optional | Mode A: base64 `TransactionEnvelope` with an invoke op; contract/function/args decoded automatically |
| `contract_id` | string, optional | Mode B: C-strkey, used when `transaction_xdr` absent |
| `function` | string, optional | Mode B: function name |
| `chain_id` | string, required | resolves the RPC endpoint |

At least one of `transaction_xdr` or (`contract_id` + `function`) must be supplied; if both, `transaction_xdr` wins. Does NOT submit or modify chain state. Does not validate spec semantics beyond a bounded XDR parse; upstream specs are treated as trusted. The typed preview is non-authoritative display only and does not gate signing.

## SEP-53: signed messages

Canonical prefixed message sign and verify. Signing computes `SHA-256("Stellar Signed Message:\n" ‖ message)` and ed25519-signs the 32-byte digest, producing a 64-byte signature; verification recomputes the digest and ed25519-verifies it.

Tool `stellar_sep53_sign_message`:

| Arg | Type | Notes |
|---|---|---|
| `chain_id` | string, required | CAIP-2 |
| `message` | string, required | UTF-8 string, or standard base64 when `message_encoding="base64"` |
| `message_encoding` | string, optional | `"utf8"` (default) or `"base64"` |

Returns `{ signature (base64), signer_public_key (G...), message_encoding }`.

Tool `stellar_sep53_verify_message` (read-only): args `chain_id` (required, dispatch-gate compat, verification is chain-agnostic), `message`, `message_encoding` (`"utf8"`/`"base64"`, must match signing), `signature` (standard base64, 64-byte ed25519), `public_key` (G-strkey). Returns `{ valid: true }` or an error envelope on failure.

SEP-43 `signMessage` signs the same prefixed digest, so both tools return the same signature bytes for the same message and key. SEP-53 is a pure off-chain scheme; it submits no transaction, does not base64-encode the message for you, and caps message length at 64 KiB (65,536 bytes).

## x402 v2 Exact Stellar: agent payments

Payer-side construction and signing of a `PAYMENT-SIGNATURE` payload for the x402 v2 Exact Stellar scheme, wire-compatible with the published `@x402/stellar` package. The wallet is the **payer**; the MCP host performs the actual HTTP request/retry to the facilitator.

`payment_required` may be a base64-encoded `PAYMENT-REQUIRED` header value or a raw JSON `PaymentRequirements` object (the tool tries base64-decode first, then raw JSON). Pass ONE selected `accepts[]` element, not a full 402 envelope. RPC URL and network passphrase always come from the active profile, never from the input.

### `stellar_x402_create_payment`

| Arg | Type | Required | Notes |
|---|---|---|---|
| `payment_required` | string | yes | base64 `PAYMENT-REQUIRED` or raw JSON `PaymentRequirements` |
| `chain_id` | string | yes | CAIP-2 `stellar:testnet` or `stellar:mainnet`; validated against the profile after the requirements |
| `address` | string | no | signer G-strkey; must match the active signer if given |
| `approval_nonce` | string | no | optional in the schema; omit it with `approval_attestation` for mainnet call 1, supply both for call 2 |
| `approval_attestation` | string | no | optional in the schema; mainnet call 2 requires the CLI-issued attestation alongside its approval nonce |

Testnet flow: validate the requirements, then admit the payment through the policy and the spending window. Before the signer load, the cross-check rule decides whether the payment needs the witness. It uses the amount in the asset's atomic units and the profile's thresholds and oracle. A required witness builds the oracle client without a request. Check the endpoint identity with `getNetwork`, the first request on the payment's primary client. Build the SAC transfer, simulate, and check restoration, fees, exactly one result, and the simulated authorization. When the witness is required, the oracle simulates the same unsigned transfer and the answers are compared. Read `getHealth` and check the ledger bounds. Sign the auth entry and write the `x402_payment_authorized` audit row. Re-simulate, check restoration, fees, the re-simulated authorization, and the ledger bounds, then serialize. The re-simulation sends the signed authorization to the profile's RPC, so the row is written first; if it cannot be written, the tool answers the `audit.*` code and the signature never leaves the wallet. A failure after the row adds an `x402_authorization_withheld` row with the same request id. Returns `{ paymentSignature, payer, asset, amount, payTo, network, cross_check }`. The `paymentSignature` is the standard-base64 `PAYMENT-SIGNATURE` header value, and `asset` is the SAC C-strkey. The `amount` is the atomic-unit string from `PaymentRequirements`, and `cross_check` is the witness outcome. The `x402_payment_authorized` row carries a passed witness when the payment required one. Errors carry per-variant codes `x402.<reason>` (for example `x402.invalid_payment_required`, `x402.unsupported_scheme`, `x402.rpc_simulate_failed`, `x402.unexpected_auth_entries`, `x402.transmit_gate_refused`) in the standard `{ok:false, error:{code, message}, request_id}` envelope with `is_error` set. A witness refusal keeps its own code: `simulation.divergence`, `network.witness_unavailable`, `network.rpc_credential_refused`, or the oracle credential read's keyring code (`auth.keyring_*`). Header fields named in an error are escaped and cut at 200 characters. A header that does not decode reports the JSON error class and position, not its values.

Mainnet calls, on an admitted server: call 1 omits both approval arguments. Supplying only one returns `policy.approval_required`. Call 1 validates the requirements and `chain_id`, loads the enrolled signer, and evaluates local policy without an account-reserve view. A matching `minimum_reserve` criterion fails closed with `policy.engine_required`. Both x402 payment tools require approval on an admitted mainnet server, including under an Allow rule. Call 1 reads enrollment and local policy state. It sends no payment RPC or SEP-10 request and performs no signing. It returns `data.approval` without a payment payload, with `approval_nonce`, `profile`, `chain_id`, `expires_at_unix_ms`, `reason`, `endpoint_host`, `signer`, `summary` (`payTo`, `amount`, `asset`), and `instructions`.

On mainnet, approve x402 payments through `stellar-agent approve --id <nonce> --profile <name>` in a terminal. Approval-ui and remote approval do not attest this approval kind. Call 2 repeats the request with both approval arguments. It rechecks startup freshness, verifies the attestation, and runs the payment build: endpoint check, simulation, witness, health, intent mint, signing, audit row, intent consumption, and signed re-simulation. The tool then encodes the payload, consumes the release authorization, and consumes the pending approval before returning `{ paymentSignature, payer, asset, amount, payTo, network, cross_check }`. Authorization refusals use `network.mainnet_authorization_refused`. Policy denials keep `policy.deny.*`. Other payment errors keep their own codes.

The `x402_authorization_withheld` stages are `anchor_unavailable`,
`resimulation`, `response_processing`, `encoding`, `payload_release`, and
`terminal_approval`. The transmit gate checks the anchor before and after its
authorization row. At `anchor_unavailable`, the signature stays in the wallet.
On testnet, the spend that policy admitted earlier in the call remains. Mainnet retains the debit
after intent consumption. Refusal before consumption invalidates the open intent.

### `stellar_x402_authenticated_payment`

Runs the SEP-10 counterparty-identity gate BEFORE building the payment. Any identity-gate failure aborts before the payment build runs: no `PaymentPayload`, no SAC auth entry, no nonce is generated.

| Arg | Type | Required | Notes |
|---|---|---|---|
| `payment_required` | string | yes | as above |
| `chain_id` | string | yes | CAIP-2, as above |
| `home_domain` | string | yes | operator-supplied domain for SEP-10 identity verification (e.g. `"testanchor.stellar.org"`); the gate resolves its `stellar.toml`, extracts `WEB_AUTH_ENDPOINT` + `SIGNING_KEY`, verifies the SSRF bind, and runs the SEP-10 ephemeral challenge/response |
| `address` | string | no | signer G-strkey; must match the active signer if given |
| `approval_nonce` | string | no | as for `stellar_x402_create_payment` |
| `approval_attestation` | string | no | as for `stellar_x402_create_payment` |

Returns `{ paymentSignature, authorization, payer, asset, amount, payTo, home_domain, network, payto_anchored, cross_check }`. A witness refusal answers its own code, as for `stellar_x402_create_payment`; every other build failure answers `x402.payment_build_failed`. `authorization` is the `Bearer <jwt>` value for the HTTP `Authorization:` header. The JWT is an HTTP-layer companion only: the Soroban transaction XDR, the SAC auth entry, and the payment memo are NEVER mutated to carry it. The SEP-10 ephemeral key is unfunded, fresh per call, not persisted, and not the payment funding signer. `payto_anchored` is a display signal (`"anchored"`/`"not_anchored"`/`"unknown"`) of whether `payTo` appears in the verified domain's `stellar.toml` `ACCOUNTS` list; the tool does NOT hard-deny on `"not_anchored"`.

On an admitted mainnet server, the tool runs the same two calls as `stellar_x402_create_payment`. Call 1 validates `home_domain` as a lowercase LDH name before the approval names it; another value refuses with `identity.home_domain_invalid`. The authenticated approval subject binds the payment intent digest and home domain. Changing the home domain requires a matching approval, so keep the approved home domain unchanged. Call 2 verifies approval before the identity exchange. It prepares and validates the SEP-10 challenge, consumes its message authorization, and signs and submits the challenge. The returned message-use receipt continues into the payment, which then runs the endpoint check, witness, and payer signature. Authorization refusals identify the withheld payment payload. Policy, endpoint, and witness errors keep their codes. Other payment-build failures use `x402.payment_build_failed`. The tool maps `identity.mainnet_signing_forbidden` and `identity.mainnet_authorization_refused` to `network.mainnet_write_forbidden` and `network.mainnet_authorization_refused`, respectively.

A refused challenge or token answer reports the HTTP method, the status, and the web-auth endpoint's host; the wallet does not read the answer body. A stellar.toml syntax error reports its line and column. The token must be a compact JWT of at most 8192 bytes with base64url characters in every segment; any other token refuses.

### `stellar_x402_parse_receipt`

Read-only. Arg `payment_response` (base64 `PAYMENT-RESPONSE` header value or raw JSON `SettleResponse`). Returns `{ success, transaction, payer, network, errorReason }` (`payer` and `errorReason` are `null` when absent). Text fields are escaped and cut at 200 characters. No keyring or network access.

### x402 constraints

- Payer/client only, no payee or facilitator logic.
- Stellar only, no EVM or other chains.
- `exact` scheme only, no `upto`.
- Targets x402 v2, not v3.x.
- No HTTP retry loop; the host orchestrates the HTTP exchange. The wallet produces the signed payload (and, for the authenticated variant, the Bearer token); it does not submit.
- Validation runs before the dispatch gate and consumes no spending window on a refusal. The ordinary entry `validate_requirements` also refuses a mainnet passphrase or a mainnet-pattern endpoint; the authorized path validates the same fields without refusing the mainnet network itself. It refuses when `scheme != "exact"`, `network` is not `"stellar:pubnet"`/`"stellar:testnet"`, or the x402 `network` passphrase mismatches the profile. It also refuses an asset that is not a C-strkey, `extra.areFeesSponsored != true`, and an `amount` that is not a positive `i128`. A `payTo` that is not a G-, C-, or M-strkey and a `maxTimeoutSeconds` of zero refuse too.
- The endpoint identity check is the first request. On the ordinary path, an endpoint serving another network, reporting mainnet, or not identified before `submit_timeout_seconds` refuses with its `network.*` code before any simulation. On testnet, admission comes first, so the refusal keeps the admitted spend. The authorized mainnet path checks that the endpoint serves mainnet before its first simulation. Mainnet intent minting follows the endpoint, simulation, witness, and health checks.
- `maxTimeoutSeconds` is clamped to 300 seconds as input; the requirement names a maximum, and a shorter validity meets it. With the five-second ledger estimate this gives a window of `ceil(min(t, 300) / 5)` ledgers, 1 to 60. The window counts ledger advances, not a guaranteed wall-clock lifetime.
- A `getHealth` read on the same endpoint must report `healthy`. The unsigned simulation's ledger is above zero and at most one ledger ahead of the health ledger, and the re-simulation's ledger at most one behind it. The health and re-simulation ledgers lie before the expiration ledger. These checks compare answers of the primary endpoint. When the witness is required, the oracle's simulation ledger trails the primary's by at most two and lies before the expiration ledger. This shows the primary's ledger is current. The nonce, the resource data, and the fee still come from the primary.
- Both simulations' `minResourceFee` lies between 1 and 10,000,000 stroops, and the embedded resource fee lies between zero and that minimum. The ceiling is a local sanity bound, separate from facilitator fee policy.
- A restore preamble, or archived entries in the transaction data, in either simulation refuses. On this path they come from an archived asset contract instance or the archived balance of a contract-address recipient. The wallet has no restore path; a restoration made elsewhere unblocks the payment. The reference client checks only the preamble.
- Before signing, `create_payment` refuses a simulation whose authorization is not one unsigned legacy `Address` entry for the payer, with a root invocation equal to the built SAC `transfer` and no nested calls. After the signed re-simulation, it refuses authorization entries other than the signed entry, and a missing or undecodable result.

## MPP sponsored Stellar charges

MPP is a separate Payment challenge/credential protocol, validated against the
released `@stellar/mpp` 0.7.1 behavior. The wallet supports only
`method="stellar"`, `intent="charge"`, a classic G-account payer, testnet, and
sponsored pull settlement. It uses one SEP-41 transfer authorization and SEP-43
Ed25519 signing.

Flow: prepare with the exact HTTP or native MCP request context, wait for
operator approval when required, commit once, then give the returned credential
to the trusted host. The host sends the exact bound paid request over TLS and the
server sponsors/submits. Record its receipt separately and reconcile the final
transaction for ledger proof.

Unsupported: mainnet, unsponsored, push, smart-account payer, automatic
transport/retry, channels, and toolset routing. The wallet never sends the paid
request or submits the server-sponsored transaction. The configured RPC sees
the signed authorization during mandatory re-simulation.
